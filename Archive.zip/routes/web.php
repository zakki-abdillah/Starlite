<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\SalesController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\TechnicianController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\SopController;
use App\Http\Controllers\SalesActivityController;
use App\Http\Controllers\CustomerController;
use App\Http\Middleware\PreventBackHistory;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\InstallationController;
use App\Http\Controllers\WaspangController;
use App\Http\Controllers\Waspang\ReportController;


Route::group([], function () {
    Route::get('/', [AuthController::class, 'showLoginForm']);
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::middleware(['auth', PreventBackHistory::class])->group(function () {
        Route::get('/admin', [AdminController::class, 'dashboard'])->name('admin.dashboard');
        Route::get('/teknisi', [TechnicianController::class, 'index'])->name('teknisi.dashboard');
        Route::get('/sales', [SalesController::class, 'index'])->name('sales.dashboard');
        Route::get('/waspang', [WaspangController::class, 'index'])->name('waspang.dashboard');

        Route::get('/attendance', [AttendanceController::class, 'create'])->name('attendance.create');
        Route::post('/attendance', [AttendanceController::class, 'store'])->name('attendance.store');
        Route::get('/attendance/history', [AttendanceController::class, 'history'])->name('attendance.history');
        Route::get('/sop', [SopController::class, 'showForUser'])->name('sop.index');
        
        Route::get('/admin/activity', function () {
            return 'User Activity';
        })->name('admin.activity.index');
        Route::get('/admin/storage', function () {
            return 'File Storage';
        })->name('admin.storage.index');

        Route::get('/dashboard', [AuthController::class, 'redirectDashboard'])->name('dashboard');
        Route::prefix('admin/kelola-pengguna')->name('admin.users.')->group(function () {
            Route::get('/', [UserController::class, 'index'])->name('index');
            Route::get('/create', [UserController::class, 'create'])->name('create');
            Route::post('/', [UserController::class, 'store'])->name('store');
            Route::get('/{user}/edit', [UserController::class, 'edit'])->name('edit');
            Route::put('/{user}', [UserController::class, 'update'])->name('update');
            Route::delete('/{user}', [UserController::class, 'destroy'])->name('destroy');
        });

        Route::get('/admin/attendance', [AttendanceController::class, 'index'])->name('admin.attendance.index');
        Route::resource('sales-activities', SalesActivityController::class);
        Route::get('/admin/customer-data', [CustomerController::class, 'index'])->name('admin.customers.index');
        Route::get('/customers/create', [CustomerController::class, 'create'])->name('customers.create');
        Route::post('/customers', [CustomerController::class, 'store'])->name('customers.store');
        Route::resource('customers', CustomerController::class)->except(['create', 'store']);
        Route::resource('admin/schedules', \App\Http\Controllers\ScheduleController::class)->names('admin.schedules');
        Route::resource('admin/installations', InstallationController::class)->names('admin.installations');
        Route::post('admin/installations/item/{itemId}', [InstallationController::class, 'updateItem'])->name('admin.installations.updateItem');
        Route::get('/technician/schedules/{schedule}', [TechnicianController::class, 'show'])->name('technician.schedules.show');
        Route::get('/waspang/installations/{installation}', [WaspangController::class, 'show'])->name('waspang.installations.show');
        Route::post('/waspang/installation-tasks/{task}', [WaspangController::class, 'updateTask'])->name('waspang.tasks.update');

        Route::put('/technician/schedules/{schedule}', [TechnicianController::class, 'update'])->name('technician.schedules.update');
        Route::resource('admin/sop', SopController::class)->except(['show'])->names('admin.sop');
        Route::get('/admin/reports', [ExportController::class, 'reportCenter'])->name('admin.reports.index');

        ##### TAMBAHAN REPORT #########
       
   # Route::get('/waspang/report-installation', [ReportController::class, 'index'])->name('waspang.report.index');
    Route::prefix('waspang')->name('waspang.')->group(function () {

        Route::get('/report', [ReportController::class, 'index'])
            ->name('report.index');

        Route::get('/report/export', [ReportController::class, 'export'])
            ->name('report.export');
        // 🔥 AJAX API
    Route::get('/report/data', [ReportController::class, 'getData'])
        ->name('report.data');

    });

    });

    Route::middleware('auth')->group(function () {
        Route::get('/admin/export/{type}/{format}', [ExportController::class, 'export'])->name('admin.export');
        Route::get('/admin/reports/generate', [ExportController::class, 'generateReport'])->name('admin.reports.generate');
    });
});