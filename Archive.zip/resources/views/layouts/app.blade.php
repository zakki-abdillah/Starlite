<!DOCTYPE html>
<html lang="en" translate="no">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google" content="notranslate">
    <meta http-equiv="Content-Language" content="en">
    <meta name="robots" content="noindex, nofollow">
    <meta http-equiv="X-Download-Options" content="noopen">
    <title>@yield('title', 'Starlite')</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('starlite.png') }}?v={{ time() }}">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="min-h-screen bg-gray-100 text-gray-900 flex flex-col notranslate" x-data="{ sidebarOpen: true }">

    @include('layouts.partials.topbar')

    <div class="flex flex-1 min-h-0">
        @include('layouts.partials.sidebar')

        <main class="flex-1 p-6 overflow-auto">
            <div class="container mx-auto max-w-7xl">
                @yield('content')
            </div>
        </main>
    </div>
    @include('components.success-modal')

    @if (session('success'))
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                showSuccessModal();
            });
        </script>
    @endif


</body>

</html>
