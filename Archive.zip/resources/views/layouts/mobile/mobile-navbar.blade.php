<nav class="fixed bottom-0 left-0 right-0 bg-[#171a21]/95 backdrop-blur-md border-t border-gray-800 z-50 h-20">
    <div class="grid grid-cols-5 h-full items-center max-w-lg mx-auto">
 <!--$dashboardRoute = auth()->user()->role === 'teknisi' ? 'teknisi.dashboard' : (auth()->user()->role === 'sales' ? 'sales.dashboard' : '') : auth()->user()->role === 'waspang' ? 'waspang.dashboard' : ''  ;-->
           
        @php
            $dashboardRoute = auth()->user()->role === 'teknisi' ? 'teknisi.dashboard' : (auth()->user()->role === 'sales' ? 'sales.dashboard' : (auth()->user()->role === 'waspang' ? 'waspang.dashboard' : 'default.route'));
            $isDashboard = request()->routeIs($dashboardRoute);
        @endphp
        <div class="flex justify-center">
            <a href="{{ $dashboardRoute ? route($dashboardRoute) : '#' }}"
                class="flex flex-col items-center justify-center group relative transition-all {{ $isDashboard ? 'text-blue-400' : 'text-gray-400 hover:text-white' }}">
                <svg class="w-7 h-7 {{ $isDashboard ? 'fill-current' : '' }}" fill="{{ $isDashboard ? 'currentColor' : 'none' }}" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                </svg>
                @if($isDashboard)
                    <div class="absolute -bottom-2 w-8 h-1 bg-blue-500 rounded-t-md shadow-[0_-2px_10px_rgba(59,130,246,0.5)]"></div>
                @endif
            </a>
        </div>

        @php $isSop = request()->routeIs('sop.*'); @endphp
        <div class="flex justify-center">
            <a href="{{ route('sop.index') }}"
                class="flex flex-col items-center justify-center relative transition-all {{ $isSop ? 'text-blue-400' : 'text-gray-400 hover:text-white' }} active:scale-90">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                </svg>
                @if($isSop)
                    <div class="absolute -bottom-2 w-8 h-1 bg-blue-500 rounded-t-md shadow-[0_-2px_10px_rgba(59,130,246,0.5)]"></div>
                @endif
            </a>
        </div>

        <div class="flex justify-center relative">
            <div class="absolute -top-8"> 
                <a href="{{ route('attendance.create') }}"
                    class="flex items-center justify-center w-16 h-16 {{ request()->routeIs('attendance.*') ? 'bg-blue-500 shadow-blue-500/50' : 'bg-blue-600' }} rounded-full border-[6px] border-[#171a21] shadow-xl text-white active:scale-90 transition-all">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    </svg>
                </a>
            </div>
        </div>

        <div class="flex justify-center"></div>

        @php 
            $role = auth()->user()->role;
            $isActivity = request()->routeIs('activity.*') || request()->routeIs('schedule.*') || request()->routeIs('technician.schedules.*'); 
        @endphp
        <div class="flex justify-center">
            <a href="#"
                class="flex flex-col items-center justify-center relative transition-all {{ $isActivity ? 'text-blue-400' : 'text-gray-400 hover:text-white' }} active:scale-90">
                @if ($role === 'teknisi')
                    <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    </svg>
                @elseif($role === 'sales')
                    <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                    </svg>
                 @elseif($role === 'waspang')
                    <!--svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                    </svg-->
                @else
                    <svg class="w-7 h-7" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M4 6h16M4 12h16m-7 6h7"></path>
                    </svg>
                @endif
                
                @if($isActivity)
                    <div class="absolute -bottom-2 w-8 h-1 bg-blue-500 rounded-t-md shadow-[0_-2px_10px_rgba(59,130,246,0.5)]"></div>
                @endif
            </a>
        </div>

    </div>
</nav>