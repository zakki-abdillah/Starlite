<nav class="sticky top-0 z-50 bg-[#171a21] px-4 py-3 flex items-center gap-3 shadow-lg">
    <div class="flex-1 relative">
        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
            </svg>
        </div>
        <input type="text" 
               class="block w-full bg-[#25282e] border-none text-sm text-gray-200 rounded-md py-2 pl-10 pr-3 focus:ring-1 focus:ring-blue-500 placeholder-gray-500" 
               placeholder="Cari tugas atau teknisi...">
    </div>

    <div class="flex items-center gap-3">
        <button class="text-gray-400 hover:text-white transition-colors">
            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"></path>
            </svg>
        </button>

        <div class="relative" x-data="{ open: false }">
            <button @click="open = !open" @click.away="open = false" type="button" class="relative block w-9 h-9 focus:outline-none">
                <img src="https://ui-avatars.com/api/?name=Admin+Teknisi&background=2563eb&color=fff" 
                     alt="Profile" 
                     class="rounded-md object-cover border-b-2 border-blue-500 w-full h-full">
                <span class="absolute -top-1 -right-1 block h-3 w-3 rounded-full bg-green-500 border-2 border-[#171a21]"></span>
            </button>

            <div x-show="open" 
                 x-transition:enter="transition ease-out duration-100"
                 x-transition:enter-start="transform opacity-0 scale-95"
                 x-transition:enter-end="transform opacity-100 scale-100"
                 class="absolute right-0 mt-3 w-40 bg-[#1b2838] border border-gray-700 rounded-lg shadow-2xl z-[60] overflow-hidden"
                 style="display: none;">
                
                <div class="px-4 py-2 border-b border-gray-700 bg-[#171a21]">
                    <p class="text-[10px] text-gray-500 uppercase font-bold tracking-tighter">User Role</p>
                    <p class="text-xs text-blue-300 truncate font-medium">
                        {{ Auth::user()->role ?? 'Technician' }}
                    </p>
                </div>

                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" 
                            class="w-full text-left px-4 py-3 text-sm text-red-400 hover:bg-red-600 hover:text-white transition-all flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                        </svg>
                        Logout
                    </button>
                </form>
            </div>
        </div>
    </div>
</nav>