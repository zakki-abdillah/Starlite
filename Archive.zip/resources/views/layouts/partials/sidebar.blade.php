@php
    $menu = [];
    $userRole = Auth::user()->role;
    if ($userRole === 'admin') {
        $menu = [
            ['href' => route('admin.dashboard'), 'icon' => 'bi-speedometer2', 'label' => 'Dashboard'],
            ['href' => route('admin.users.index'), 'icon' => 'bi-people', 'label' => 'Manage Users'],
            ['href' => route('admin.sop.index'), 'icon' => 'bi-journal-text', 'label' => 'Manage SOP'],
            ['href' => route('admin.attendance.index'), 'icon' => 'bi-activity', 'label' => 'User Activity'],
            ['href' => route('admin.customers.index'), 'icon' => 'bi-person-lines-fill', 'label' => 'Customer Data'],
            ['href' => route('admin.schedules.index'), 'icon' => 'bi-calendar-week', 'label' => 'Schedules'],
            ['href' => route('admin.installations.index'), 'icon' => 'bi-tools', 'label' => 'Installations'],
            ['href' => route('admin.reports.index'), 'icon' => 'bi-file-earmark-bar-graph', 'label' => 'Report Center'],
            ['href' => route('admin.storage.index'), 'icon' => 'bi-hdd', 'label' => 'File Storage'],
            ['href' => route('waspang.report.index'), 'icon' => 'bi-pie-chart', 'label' => 'Report Installation'],
        ];
    }
@endphp

<aside :class="sidebarOpen ? 'w-64' : 'w-16'"
    class="bg-white text-gray-900 flex flex-col p-4 border-r border-gray-200 transition-all duration-700 ease-in-out shadow-lg overflow-hidden">
    <nav class="flex flex-col space-y-3 mt-4">
        @foreach ($menu as $item)
            <a href="{{ $item['href'] }}"
                class="flex items-center px-2 py-2 rounded border border-transparent hover:border-red-600 transition font-semibold min-h-[40px]">
                <i class="bi {{ $item['icon'] }} text-lg flex-shrink-0"></i>
                <span class="ml-2 transition-all duration-700 ease-in-out inline-block overflow-hidden whitespace-nowrap"
                    :class="sidebarOpen ? 'opacity-100 w-auto' : 'opacity-0 w-0'">
                    {{ $item['label'] }}
                </span>
            </a>
        @endforeach
       
    </nav>
</aside>