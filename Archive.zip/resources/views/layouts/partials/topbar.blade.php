<div class="bg-white text-gray-900 p-4 flex justify-between items-center shadow">
    <div class="flex items-center space-x-4">
        <button @click="sidebarOpen = !sidebarOpen"
            class="px-3 py-2 rounded border border-gray-300 hover:bg-gray-200 transition">
            <i class="bi bi-list text-lg"></i>
        </button>
        <h1 class="text-xl font-bold">Admin dashboard</h1>
    </div>

    <form method="POST" action="{{ route('logout') }}" class="no-success">
        @csrf
        <button type="submit"
            class="px-4 py-2 rounded border border-gray-300 hover:bg-red-600 hover:text-white transition font-semibold text-sm">
            Logout
        </button>
    </form>
</div>
