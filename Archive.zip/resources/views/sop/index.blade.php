@extends('layouts.mobile')

@section('header_title', 'S.O.P')

@section('content')
<div class="p-6 space-y-4" x-data="{ openSop: null }">
    @forelse($sops as $sop)
        <div class="bg-[#171a21] rounded-2xl border border-gray-800 shadow-lg">
            <button @click="openSop = openSop === {{ $sop->id }} ? null : {{ $sop->id }}" class="w-full flex justify-between items-center p-5 text-left">
                <h3 class="text-base font-bold text-white">{{ $sop->title }}</h3>
                <svg class="w-5 h-5 text-gray-400 transition-transform" :class="{ 'rotate-180': openSop === {{ $sop->id }} }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
            <div x-show="openSop === {{ $sop->id }}" x-collapse class="px-5 pb-5">
                <!-- Content Display dengan Style Khusus -->
                <div class="text-gray-300 text-sm leading-relaxed sop-content">
                    {!! $sop->content !!}
                </div>
            </div>
        </div>
    @empty
        <div class="text-center py-10">
            <p class="text-gray-500">Tidak ada SOP yang tersedia untuk Anda saat ini.</p>
        </div>
    @endforelse
</div>

<style>
    .sop-content { color: #d1d5db; }
    .sop-content ul { list-style-type: disc; margin-left: 1.5rem; margin-bottom: 0.5rem; }
    .sop-content ol { list-style-type: decimal; margin-left: 1.5rem; margin-bottom: 0.5rem; }
    .sop-content li { margin-bottom: 0.25rem; color: #d1d5db; }
    .sop-content b, .sop-content strong { font-weight: bold; color: #fff; }
    .sop-content i, .sop-content em { font-style: italic; }
    .sop-content p { margin-bottom: 0.5rem; color: #d1d5db; }
</style>
@endsection