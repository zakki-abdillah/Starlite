@extends('layouts.app')

@section('content')
<div class="bg-white rounded-lg shadow-lg p-6">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Jadwal Instalasi</h2>
            <p class="text-gray-600 text-sm">Manajemen pekerjaan instalasi lapangan.</p>
        </div>
        <a href="{{ route('admin.installations.create') }}" class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition">
            <i class="bi bi-plus-lg mr-2"></i>Buat Jadwal Baru
        </a>
    </div>

    {{-- Alerts --}}
    @if(session('success'))
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline">{{ session('success') }}</span>
    </div>
    @endif
    @if(session('error'))
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline">{{ session('error') }}</span>
    </div>
    @endif

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-200" id="dataTable">
            <thead>
                <tr class="bg-gray-50 text-gray-600 uppercase text-xs leading-normal">
                    <th class="py-3 px-6 text-left">Kode Job</th>
                    <th class="py-3 px-6 text-left">Judul</th>
                    <th class="py-3 px-6 text-left">No PO</th>
                    <th class="py-3 px-6 text-left">Waspang</th>
                    <!--th class="py-3 px-6 text-left">Target</th>
                    <th class="py-3 px-6 text-left">Realisasi</th-->
                    <th class="py-3 px-6 text-left">Prosentase (Target vs Realisasi)</th>
                    <th class="py-3 px-6 text-center">Progress Work</th>
                    <!--th class="py-3 px-6 text-center">Status</th-->
                    <th class="py-3 px-6 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="text-gray-600 text-sm font-light">
                @forelse($installations as $installation)
                    @php
                        $target = $installation->target ?? 0;
                        $realisasi = $installation->realisasi ?? 0;

                        $progress = $target > 0 ? round(($realisasi / $target) * 100, 2) : 0;

                         if ($progress < 40) {
                            $color = '#ef4444'; // merah
                            $label = 'Belum';
                        } elseif ($progress < 80) {
                            $color = '#facc15'; // kuning
                            $label = 'Progress';
                        } else {
                            $color = '#22c55e'; // hijau
                            $label = 'Hampir';
                        }
                    @endphp
                <tr class="border-b border-gray-200 hover:bg-gray-100">
                    <td class="py-3 px-6 text-left whitespace-nowrap">
                        <span class="font-medium">{{ $installation->job_code }}</span>
                    </td>
                    <td class="py-3 px-6 text-left">
                        <span class="font-medium">{{ $installation->title }}</span>
                    </td>
                    <td class="py-3 px-6 text-left">
                        <span class="font-medium">{{ $installation->no_po }}</span>
                    </td>
                    <td class="py-3 px-6 text-left">
                        <span>{{ $installation->waspang->name ?? '-' }}</span>
                    </td>
                     <!--td class="py-3 px-6 text-left">
                        <span class="font-medium">{{ $installation->target }}</span>
                    </td>
                     <td class="py-3 px-6 text-left">
                        <span class="font-medium">{{ $installation->realisasi }} </span>
                    </td-->
                     <td class="py-3 px-6 text-left">

                        <div class="flex flex-col items-center justify-center">

                            <!-- Donut -->
                            <div class="relative w-20 h-20 rounded-full flex items-center justify-center"
                                style="background: conic-gradient({{ $color }} {{ $progress }}%, #e5e7eb {{ $progress }}%);">

                                <!-- Inner Circle -->
                                <div class="w-14 h-14 bg-white rounded-full flex flex-col items-center justify-center shadow-inner">

                                    <span class="text-l font-bold text-gray-800">
                                        {{ $progress }}%
                                    </span>

                                    <span class="text-xs text-gray-400">
                                        {{ $label }}
                                    </span>

                                </div>

                            </div>

                            <!-- Info -->
                            <div class="mt-4 text-center text-sm text-gray-600">
                                {{ $realisasi }} / {{ $target }} 
                            </div>

                        </div>

                    </td>

                     <td class="py-3 px-6 text-left">
                        
                            <div class="w-full bg-gray-200 rounded-full h-3">

                            <div class="bg-green-500 h-3 rounded-full"
                                style="width: {{ $installation->progress ?? 0 }}%">
                            </div>

                            </div>

                            <span class="text-xs">
                            {{ $installation->progress ?? 0 }} %
                            </span>

                    </td>
                    
                    <!--td class="py-3 px-6 text-center">
                        @php
                            $statusColors = [
                                'pending' => 'bg-yellow-200 text-yellow-800',
                                'in_progress' => 'bg-blue-200 text-blue-800',
                                'completed' => 'bg-green-200 text-green-800',
                                'canceled' => 'bg-red-200 text-red-800',
                                'on_hold' => 'bg-gray-200 text-gray-800',
                            ];
                        @endphp
                        <span class="py-1 px-3 rounded-full text-xs font-semibold {{ $statusColors[$installation->status] ?? '' }}">
                            {{ str_replace('_', ' ', $installation->status) }}
                        </span>
                    </td-->
                    <td class="py-3 px-6 text-center">
                        <div class="flex item-center justify-center">
                            <a href="{{ route('admin.installations.show', $installation->id) }}" class="w-4 mr-2 transform hover:text-purple-500 hover:scale-110" title="Lihat Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                            <a href="{{ route('admin.installations.edit', $installation->id) }}" class="w-4 mr-2 transform hover:text-blue-500 hover:scale-110" title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <form action="{{ route('admin.installations.destroy', $installation->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus jadwal ini?');" class="inline-block">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="w-4 mr-2 transform hover:text-red-500 hover:scale-110" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="py-4 text-center text-gray-500">Belum ada jadwal instalasi yang dibuat.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@endsection
