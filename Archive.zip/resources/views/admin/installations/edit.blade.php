@extends('layouts.app')

@section('content')
<div class="bg-white rounded-lg shadow-lg p-6">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Edit Jadwal Instalasi</h2>
            <p class="text-gray-600 text-sm">Job Code: {{ $installation->job_code }}</p>
        </div>
        <a href="{{ route('admin.installations.index') }}" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
            <i class="bi bi-arrow-left mr-2"></i>Kembali
        </a>
    </div>

    @if ($errors->any())
    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
        <p class="font-bold">Terjadi Kesalahan Validasi</p>
        <ul>
            @foreach ($errors->all() as $error)
                <li class="list-disc ml-5">- {{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <form action="{{ route('admin.installations.update', $installation->id) }}" method="POST" class="space-y-6">
            @csrf
            @method('PUT')
            
            <div>
                <label class="block text-gray-700 font-medium mb-1.5">Judul Pekerjaan</label>
                <input type="text" name="title" value="{{ old('title', $installation->title) }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition" required>
            </div>

             <div>
                <label class="block text-gray-700 font-medium mb-1.5">No PO</label>
                <input type="text" name="no_po" value="{{ old('no_po', $installation->no_po) }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition" required>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-gray-700 font-medium mb-1.5">Waspang</label>
                    <select name="id_waspang" class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white" required>
                        @foreach($waspangs as $waspang)
                            <option value="{{ $waspang->id }}" @if(old('id_waspang', $installation->id_waspang) == $waspang->id) selected @endif>{{ $waspang->name }}</option>
                        @endforeach
                    </select>
                </div>
                
                 <div>
                <label class="block text-gray-700 font-medium mb-1.5">Target</label>
                <input type="numeric" name="target" value="{{ old('target', $installation->target) }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition" required>
                 </div>

                <div>
                    <label class="block text-gray-700 font-medium mb-1.5">Realisasi</label>
                    <input type="numeric" name="realisasi" value="{{ old('realisasi', $installation->realisasi) }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition" required>
                </div>

                <div>
                    <label class="block text-gray-700 font-medium mb-1.5">Status</label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white" required>
                        <option value="pending" @if(old('status', $installation->status) == 'pending') selected @endif>Pending</option>
                        <option value="in_progress" @if(old('status', $installation->status) == 'in_progress') selected @endif>In Progress</option>
                        <option value="on_hold" @if(old('status', $installation->status) == 'on_hold') selected @endif>On Hold</option>
                        <option value="completed" @if(old('status', $installation->status) == 'completed') selected @endif>Completed</option>
                        <option value="canceled" @if(old('status', $installation->status) == 'canceled') selected @endif>Canceled</option>
                    </select>
                </div>
            </div>

            <div>
                <label class="block text-gray-700 font-medium mb-1.5">Catatan / Info Medan</label>
                <textarea name="description" rows="2" placeholder="Informasi tambahan lokasi..." class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 transition">{{ old('description', $installation->description) }}</textarea>
            </div>

            <div>
                <div class="flex justify-between items-center mb-2">
                    <label class="text-gray-700 font-medium">Titik Koordinat Lokasi</label>
                    <button type="button" class="text-xs px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700" id="btn-add-coord-edit">
                        <i class="bi bi-plus-lg"></i> Tambah Titik
                    </button>
                </div>
                <div id="edit-coordinates-container" class="space-y-3">
                    @foreach (old('coordinates', $installation->coordinates->toArray()) as $index => $coord)
                    <div class="p-3 border border-gray-200 rounded-lg bg-gray-50 space-y-2 coordinate-item">
                        <div class="flex gap-2">
                            <input type="text" name="coordinates[{{ $index }}][latitude]" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Latitude" value="{{ $coord['latitude'] ?? '' }}" required>
                            <input type="text" name="coordinates[{{ $index }}][longitude]" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Longitude" value="{{ $coord['longitude'] ?? '' }}" required>
                            <button type="button" class="px-3 py-2 text-red-600 bg-red-100 rounded hover:bg-red-200 btn-remove-coord" @if($loop->first) disabled @endif onclick="this.closest('.coordinate-item').remove()">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                        <input type="text" name="coordinates[{{ $index }}][description]" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Keterangan (Opsional)" value="{{ $coord['description'] ?? '' }}">
                    </div>
                    @endforeach
                </div>
            </div>

            <div class="flex justify-end space-x-3 pt-6 border-t border-gray-100">
                <a href="{{ route('admin.installations.index') }}" class="px-5 py-2 text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 transition font-medium">
                    Batal
                </a>
                <button type="submit" class="px-5 py-2 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition font-medium">
                    Update Jadwal
                </button>
            </div>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let editCoordIndex = {{ count(old('coordinates', $installation->coordinates->toArray())) }};
            const container = document.getElementById('edit-coordinates-container');
            if (!container) return;

            document.getElementById('btn-add-coord-edit').addEventListener('click', function() {
                const newItem = `
                    <div class="p-3 border border-gray-200 rounded-lg bg-gray-50 space-y-2 coordinate-item">
                        <div class="flex gap-2">
                            <input type="text" name="coordinates[${editCoordIndex}][latitude]" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Latitude" required>
                            <input type="text" name="coordinates[${editCoordIndex}][longitude]" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Longitude" required>
                            <button type="button" class="px-3 py-2 text-red-600 bg-red-100 rounded hover:bg-red-200 btn-remove-coord" onclick="this.closest('.coordinate-item').remove()">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                        <input type="text" name="coordinates[${editCoordIndex}][description]" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Keterangan (Opsional)">
                    </div>
                `;
                container.insertAdjacentHTML('beforeend', newItem);
                editCoordIndex++;
            });
        });
    </script>
</div>
@endsection
