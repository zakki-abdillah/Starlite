@extends('layouts.app')

@section('content')
<div class="bg-white rounded-lg shadow-lg p-6">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Buat Jadwal Instalasi Baru</h2>
            <p class="text-gray-600 text-sm">Isi form di bawah untuk membuat jadwal baru.</p>
        </div>
        <a href="{{ route('admin.installations.index') }}" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
            <i class="bi bi-arrow-left mr-2"></i>Kembali
        </a>
    </div>

    @if(session('error'))
    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
        <p class="font-bold">Terjadi Kesalahan</p>
        <p>{{ session('error') }}</p>
    </div>
    @endif

    @if ($errors->any())
    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
        <p class="font-bold">Terjadi Kesalahan Validasi</p>
        <ul>
            @foreach ($errors->all() as $error)
                <li class="list-disc ml-5">- {{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <form action="{{ route('admin.installations.store') }}" method="POST" class="space-y-6">
            @csrf
            
            <div>
                <label class="block text-gray-700 font-medium mb-1.5">Judul Pekerjaan</label>
                <input type="text" name="title" value="{{ old('title') }}" required placeholder="Contoh: Instalasi Baru"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition">
            </div>
            <div>
                <label class="block text-gray-700 font-medium mb-1.5">No PO</label>
                <input type="text" name="no_po" value="{{ old('no_po') }}" required placeholder="Masukkan No PO"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition">
            </div>

            <div>
                <label class="block text-gray-700 font-medium mb-1.5">Waspang (Pengawas Lapangan)</label>
                <select name="id_waspang" required class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white">
                    <option value="" disabled @if(!old('id_waspang')) selected @endif>-- Pilih Waspang --</option>
                    @foreach($waspangs as $waspang)
                        <option value="{{ $waspang->id }}" @if(old('id_waspang') == $waspang->id) selected @endif>{{ $waspang->name }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-gray-700 font-medium mb-1.5">Target</label>
                <input type="number" name="target" value="{{ old('target') }}" required placeholder="Masukkan Target"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition">
            </div>
            <div>
                <label class="block text-gray-700 font-medium mb-1.5">Realisasi</label>
                <input type="number" name="realisasi" value="{{ old('realisasi') }}" required placeholder="Masukkan Realisasi"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 transition">
            </div>
            <div>
                <label class="block text-gray-700 font-medium mb-1.5">Catatan / Info Medan</label>
                <textarea name="description" rows="2" placeholder="Informasi tambahan lokasi..." class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 transition">{{ old('description') }}</textarea>
            </div>

            <div>
                <div class="flex justify-between items-center mb-2">
                    <label class="text-gray-700 font-medium">Titik Koordinat Lokasi</label>
                    <button type="button" class="text-xs px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700" id="btn-add-coord-create">
                        <i class="bi bi-plus-lg"></i> Tambah Titik
                    </button>
                </div>
                <div id="create-coordinates-container" class="space-y-3">
                    @forelse(old('coordinates', [['latitude' => '', 'longitude' => '', 'description' => '']]) as $index => $coord)
                        <div class="p-3 border border-gray-200 rounded-lg bg-gray-50 space-y-2 coordinate-item">
                            <div class="flex gap-2">
                                <input type="text" name="coordinates[{{ $index }}][latitude]" value="{{ $coord['latitude'] ?? '' }}" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Latitude" required>
                                <input type="text" name="coordinates[{{ $index }}][longitude]" value="{{ $coord['longitude'] ?? '' }}" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Longitude" required>
                                <button type="button" class="px-3 py-2 text-red-600 bg-red-100 rounded hover:bg-red-200 btn-remove-coord" @if($loop->first) disabled @endif>
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                            <input type="text" name="coordinates[{{ $index }}][description]" value="{{ $coord['description'] ?? '' }}" class="w-full px-3 py-2 text-sm border border-gray-300 rounded shadow-sm" placeholder="Keterangan (Opsional)">
                        </div>
                    @empty
                        {{-- Fallback jika old() kosong, seharusnya tidak pernah terjadi dengan array default di atas --}}
                    @endforelse
                </div>
            </div>

            <div class="flex justify-end space-x-3 pt-6 border-t border-gray-100">
                <a href="{{ route('admin.installations.index') }}"
                    class="px-5 py-2 text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 transition font-medium">
                    Batal
                </a>
                <button type="submit"
                    class="px-5 py-2 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition font-medium">
                    Simpan Jadwal
                </button>
            </div>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let createCoordIndex = {{ count(old('coordinates', [1])) }};
            const container = document.getElementById('create-coordinates-container');
            if (!container) return;

            document.getElementById('btn-add-coord-create').addEventListener('click', function() {
                const template = container.firstElementChild.cloneNode(true);
                
                template.querySelectorAll('input').forEach(input => {
                    input.value = '';
                    input.name = input.name.replace(/\[\d+\]/, `[${createCoordIndex}]`);
                });
                
                const removeBtn = template.querySelector('.btn-remove-coord');
                removeBtn.disabled = false;
                
                container.addEventListener('click', function(e) {
                    if (e.target.closest('.btn-remove-coord')) {
                        e.target.closest('.coordinate-item').remove();
                    }
                });

                container.appendChild(template);
                createCoordIndex++;
            });
        });
    </script>
</div>
@endsection