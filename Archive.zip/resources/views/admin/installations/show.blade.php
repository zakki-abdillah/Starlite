@extends('layouts.app')

@section('content')
<div class="bg-white rounded-lg shadow-lg p-6">
<div class="container-fluid">
    

    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Detail</h2>
            <p class="text-gray-600 text-sm">Job Code: {{ $installation->job_code }}</p>
        </div>
        <a href="{{ route('admin.installations.index') }}" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
            <i class="bi bi-arrow-left mr-2"></i>Kembali
        </a>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h4 class="text-xl font-bold text-gray-800">Informasi Pekerjaan</h4>
                </div>
                <h4 class="text-xl font-bold text-gray-800">Statistics</h4>
                        @php
                        $target = $installation->target ?? 0;
                        $realisasi = $installation->realisasi ?? 0;

                        $progress = $target > 0 ? round(($realisasi / $target) * 100, 2) : 0;

                         if ($progress < 40) {
                            $color = '#ef4444'; // merah
                            $label = 'Belum';
                        } elseif ($progress < 80) {
                            $color = '#facc15'; // kuning
                            $label = 'Progress';
                        } else {
                            $color = '#22c55e'; // hijau
                            $label = 'Hampir';
                        }
                    @endphp
                        <div class="flex flex-col items-center justify-center">
                            <h4 class="text-xl font-bold text-gray-800">Prosentase</h4>
                            <!-- Donut -->
                            <div class="relative w-40 h-40 rounded-full flex items-center justify-center"
                                style="background: conic-gradient({{ $color }} {{ $progress }}%, #e5e7eb {{ $progress }}%);">

                                <!-- Inner Circle -->
                                <div class="w-24 h-24 bg-white rounded-full flex flex-col items-center justify-center shadow-inner">

                                    <span class="text-l font-bold text-gray-800">
                                        {{ $progress }}%
                                    </span>

                                    <span class="text-xs text-gray-400">
                                        {{ $label }}
                                    </span>

                                </div>

                            </div>

                            <!-- Info -->
                            <div class="mt-4 text-center text-sm text-gray-600">
                                {{ $realisasi }} / {{ $target }} 
                            </div>


                            <hr>

                            <h4 class="text-xl font-bold text-gray-800">Progress Work</h4>
                             @php
                       
                    
                                $complete = $installation->tasks->where('status', 'completed')->count();
                                $total    = $installation->tasks->count();

                                if ($total == 0) {
                                    $prog = 0;
                                } else {
                                    $prog = round(($complete / $total) * 100, 2);
                                }
                                @endphp
                           
                            <div class="w-full bg-gray-200 rounded-full h-3">

                            <div class="bg-green-500 h-3 rounded-full"
                                style="width: {{ $prog ?? 0 }}%">
                            </div>

                            </div>

                            <span class="text-xs">
                               
                            {{ $prog ?? 0 }} %
                            </span>


                        </div>

                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th style="width: 30%">Judul</th>
                            <td>{{ $installation->title }}</td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td><span class="badge badge-info">{{ ucfirst($installation->status) }}</span></td>
                        </tr>
                        <tr>
                             <th>Deskripsi</th>
                            <td>{{ $installation->description ?? '-' }}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Tim & Lokasi</h6>
                </div>
                <div class="card-body">
                    <h6 class="font-weight-bold">Penanggung Jawab</h6>
                    <p class="mb-4">Waspang: <strong>{{ $installation->waspang->name ?? '-' }}</strong></p>

                    <strong><u>Titik Koordinat</u></strong>
                    <div class="table-responsive">
                        <table class="min-w-full bg-white border border-gray-200" id="dataTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Lat, Long</th>
                                    <th>Ket</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($installation->coordinates as $coord)
                                <tr>
                                    <td  class="py-3 px-6 text-center">{{ $loop->iteration }}</td>
                                    <td class="py-3 px-6 text-center">
                                        <a href="https://www.google.com/maps/search/?api=1&query={{ $coord->latitude }},{{ $coord->longitude }}" target="_blank">
                                            {{ $coord->latitude }}, {{ $coord->longitude }}
                                        </a>
                                    </td class="py-3 px-6 text-center">
                                    <td class="py-3 px-6 text-center">{{ $coord->description }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                     <strong><u>Progress</u></strong>
                     <div class="table-responsive">
                        <table class="min-w-full bg-white border border-gray-200" id="dataTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Position</th>
                                    <th>Status</th>
                                    <th>File</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($installation->task as $coord)
                                <tr>
                                    <td  class="py-3 px-6 text-center">{{ $loop->iteration }}</td>
                                    <td class="py-3 px-6 text-center">
                                     {{ $coord->stage }} - {{ $coord->task_group }} - {{ $coord->task_name }}   
                                    </td >
                                    <td class="py-3 px-6 text-center">{{ $coord->status }}</td>
                                    <td class="py-3 px-6 text-center"> <a href="{{ Storage::url($coord->file_path) }}" target="_blank" class="mt-3 flex items-center justify-center gap-2 w-full py-2 bg-gray-800 hover:bg-gray-700 text-blue-400 rounded-lg text-xs font-medium transition">
                                                <i class="bi bi-file-earmark-text"></i> Lihat
                                            </a></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
</div>

@endsection
