<!DOCTYPE html>
<html>
<head>
    <title>{{ $title ?? 'Laporan' }}</title>
    <style>
        body { font-family: 'Helvetica', 'Arial', sans-serif; font-size: 11px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 6px; text-align: left; word-wrap: break-word; }
        th { background-color: #f2f2f2; font-weight: bold; }
        h2 { text-align: center; margin-bottom: 5px; }
        p { text-align: center; margin-top: 0; font-size: 10px; color: #555; }
        .no-data { text-align: center; color: #888; }
    </style>
</head>
<body>
    <h2>{{ $title ?? 'Laporan' }}</h2>
    <p>Dicetak pada: {{ \Carbon\Carbon::now()->format('d-m-Y H:i') }}</p>
    <table>
        <thead>
            <tr>
                @foreach($headers as $header)
                    <th>{{ $header }}</th>
                @endforeach
            </tr>
        </thead>
        <tbody>
            @forelse($data as $item)
            <tr>
                @foreach($columns as $column)
                    <td>
                        {{ is_callable($column) ? $column($item) : data_get($item, $column, 'N/A') }}
                    </td>
                @endforeach
            </tr>
            @empty
            <tr>
                <td colspan="{{ count($headers) }}" class="no-data">Tidak ada data yang tersedia.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>
