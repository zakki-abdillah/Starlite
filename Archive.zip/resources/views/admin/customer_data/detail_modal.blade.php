<div id="detail-modal" class="fixed inset-0 z-50 hidden items-center justify-center">
    <!-- Backdrop Blur -->
    <div class="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" onclick="closeModal('detail-modal')"></div>

    <!-- Modal Content -->
    <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-3xl m-4 overflow-hidden transform transition-all scale-100">
        <!-- Header -->
        <div class="bg-gray-50 px-6 py-4 border-b border-gray-100 flex justify-between items-center">
            <h3 class="text-lg font-bold text-gray-800 flex items-center gap-2">
                <i class="bi bi-person-vcard text-blue-600"></i> Detail Pelanggan
            </h3>
            <button onclick="closeModal('detail-modal')" class="text-gray-400 hover:text-red-500 transition">
                <i class="bi bi-x-lg text-xl"></i>
            </button>
        </div>

        <!-- Body -->
        <div class="p-6 overflow-y-auto max-h-[80vh]">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Kolom Kiri: Info Utama -->
                <div class="space-y-4">
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">Nama Lengkap</label>
                        <p id="modal-name" class="text-gray-900 font-semibold text-lg border-b border-gray-100 pb-1">-</p>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">NIK</label>
                        <p id="modal-nik" class="text-gray-700 font-mono bg-gray-50 px-2 py-1 rounded inline-block">-</p>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">Nomor HP / WA</label>
                        <p id="modal-phone" class="text-gray-700 flex items-center gap-2">
                            <span>-</span>
                            <a id="modal-wa-link" href="#" target="_blank" class="text-green-500 hover:text-green-600 text-sm">
                                <i class="bi bi-whatsapp"></i> Chat
                            </a>
                        </p>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">Sales Input</label>
                        <div class="flex items-center gap-2 mt-1">
                            <div class="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <p id="modal-sales" class="text-gray-700">-</p>
                        </div>
                    </div>
                </div>

                <!-- Kolom Kanan: Alamat & Foto -->
                <div class="space-y-4">
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">Alamat Pemasangan</label>
                        <div class="bg-gray-50 p-3 rounded-lg border border-gray-100 mt-1">
                            <p id="modal-address" class="text-gray-700 text-sm leading-relaxed">-</p>
                        </div>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block">Foto Lokasi / KTP</label>
                        <div class="rounded-lg overflow-hidden border border-gray-200 bg-gray-100 h-48 flex items-center justify-center relative group">
                            <img id="modal-photo" src="" alt="Foto Pelanggan" class="w-full h-full object-cover">
                            <a id="modal-photo-link" href="#" target="_blank" class="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition text-white font-bold gap-2">
                                <i class="bi bi-zoom-in"></i> Lihat Full
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
