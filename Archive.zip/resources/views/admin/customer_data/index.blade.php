@extends('layouts.app')

@section('title', 'Data Pelanggan')

@section('content')
<div class="bg-white rounded-lg shadow-lg p-6">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Data Pelanggan</h2>
            <p class="text-gray-600 text-sm">Daftar pelanggan dari hasil kunjungan sales.</p>
        </div>
        <!-- Tombol Export atau Print bisa ditambahkan disini -->
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr class="bg-gray-50 text-gray-600 uppercase text-xs leading-normal">
                    <th class="py-3 px-6 text-left">No</th>
                    <th class="py-3 px-6 text-left">Nama Pelanggan</th>
                    <th class="py-3 px-6 text-left">Sales Input</th>
                    <th class="py-3 px-6 text-left">Kontak</th>
                    <th class="py-3 px-6 text-left">Alamat</th>
                    <th class="py-3 px-6 text-center">Foto</th>
                    <th class="py-3 px-6 text-center">Status</th>
                </tr>
            </thead>
            <tbody class="text-gray-600 text-sm font-light">
                @forelse($customers as $index => $customer)
                <tr class="border-b border-gray-200 hover:bg-gray-100 cursor-pointer" 
                    onclick="openDetailModal(this)"
                    data-name="{{ $customer->name }}"
                    data-nik="{{ $customer->nik }}"
                    data-phone="{{ $customer->no_hp }}"
                    data-address="{{ $customer->address }}"
                    data-sales="{{ $customer->salesActivity->user->name ?? 'Unknown' }}"
                    data-photo="{{ $customer->photo_path ? Storage::url($customer->photo_path) : '' }}">
                    <td class="py-3 px-6 text-left whitespace-nowrap">
                        {{ $index + 1 }}
                    </td>
                    <td class="py-3 px-6 text-left">
                        <span class="font-medium">{{ $customer->name }}</span>
                        <br>
                        <span class="text-xs text-gray-500">NIK: {{ $customer->nik }}</span>
                    </td>
                    <td class="py-3 px-6 text-left">
                        <div class="flex items-center">
                            <div class="mr-2">
                                <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs">
                                    {{ substr($customer->salesActivity->user->name ?? 'U', 0, 1) }}
                                </div>
                            </div>
                            <span class="font-medium">{{ $customer->salesActivity->user->name ?? 'Unknown' }}</span>
                        </div>
                    </td>
                    <td class="py-3 px-6 text-left">
                        {{ $customer->no_hp }}
                    </td>
                    <td class="py-3 px-6 text-left">
                        {{ Str::limit($customer->address, 30) }}
                    </td>
                    <td class="py-3 px-6 text-center">
                        @if($customer->photo_path)
                            <a href="{{ Storage::url($customer->photo_path) }}" target="_blank" class="text-blue-500 hover:underline text-xs" onclick="event.stopPropagation()">Lihat Foto</a>
                        @else
                            <span class="text-gray-400 text-xs">-</span>
                        @endif
                    </td>
                    <td class="py-3 px-6 text-center">
                        <span class="bg-green-200 text-green-600 py-1 px-3 rounded-full text-xs">{{ $customer->status_langganan ?? 'New' }}</span>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="8" class="py-4 text-center text-gray-500">Belum ada data pelanggan.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

{{-- Include Modal --}}
@include('admin.customer_data.detail_modal')

<script>
    function openDetailModal(button) {
        // Ambil data dari atribut tombol
        const name = button.getAttribute('data-name');
        const nik = button.getAttribute('data-nik');
        const phone = button.getAttribute('data-phone');
        const address = button.getAttribute('data-address');
        const sales = button.getAttribute('data-sales');
        const photo = button.getAttribute('data-photo');

        // Isi data ke dalam modal
        document.getElementById('modal-name').textContent = name;
        document.getElementById('modal-nik').textContent = nik;
        document.getElementById('modal-phone').querySelector('span').textContent = phone;
        document.getElementById('modal-wa-link').href = 'https://wa.me/' + phone.replace(/^0/, '62').replace(/\D/g, '');
        document.getElementById('modal-address').textContent = address;
        document.getElementById('modal-sales').textContent = sales;
        
        const imgEl = document.getElementById('modal-photo');
        const linkEl = document.getElementById('modal-photo-link');
        
        if (photo) {
            imgEl.src = photo;
            imgEl.classList.remove('hidden');
            linkEl.href = photo;
        } else {
            imgEl.src = ''; // Atau placeholder image
            imgEl.classList.add('hidden');
        }

        // Tampilkan Modal (Gunakan fungsi global jika ada, atau manual class manipulation)
        const modal = document.getElementById('detail-modal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
</script>
@endsection
