@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 sm:px-8">
    <div class="py-8">
        <div>
            <h2 class="text-2xl font-semibold leading-tight">Report Center</h2>
            <span class="text-gray-600">Generate dan unduh laporan untuk kebutuhan manajerial.</span>
        </div>

        <div class="mt-6 p-6 bg-white rounded-lg shadow-sm border border-gray-200">
            <form action="{{ route('admin.reports.index') }}" method="GET" id="reportForm">
                <div x-data="{
                        reportType: '{{ request('report_type') }}',
                        sales: {{ $sales->toJson() }},
                        technicians: {{ $technicians->toJson() }},
                        selectedUsers: {{ json_encode(request('user_ids', [])) }}.map(String),
                        dropdownOpen: false,
                        get availableUsers() {
                            if (['attendances', 'schedules'].includes(this.reportType)) return this.technicians;
                            if (['sales-activities', 'customers'].includes(this.reportType)) return this.sales;
                            return [];
                        },
                        get buttonText() {
                            if (this.selectedUsers.length === 0) return 'Pilih Pengguna (Semua)';
                            const count = this.availableUsers.filter(u => this.selectedUsers.includes(String(u.id))).length;
                            if (count === 0) return 'Pilih Pengguna (Semua)';
                            return count + ' Dipilih';
                        }
                    }" 
                    x-init="$watch('reportType', () => selectedUsers = [])"
                    class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    
                    {{-- Tipe Laporan --}}
                    <div>
                        <label for="report_type" class="block text-sm font-medium text-gray-700">Tipe Laporan</label>
                        <select x-model="reportType" id="report_type" name="report_type" required class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
                            <option value="">Pilih Tipe</option>
                            <option value="attendances">Laporan Absensi</option>
                            <option value="sales-activities">Laporan Aktivitas Sales</option>
                            <option value="customers">Laporan Pelanggan</option>
                            <option value="schedules">Laporan Jadwal Teknisi</option>
                        </select>
                    </div>

                    {{-- Filter Pengguna (Sales/Teknisi) --}}
                    <div x-show="availableUsers.length > 0" style="display: none;">
                        <label for="user_ids" class="block text-sm font-medium text-gray-700">Filter Pengguna</label>
                        
                        <div class="relative mt-1">
                            <button type="button" @click="dropdownOpen = !dropdownOpen" @click.away="dropdownOpen = false"
                                class="relative w-full bg-white border border-gray-300 rounded-md shadow-sm pl-3 pr-10 py-2 text-left cursor-default focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                <span class="block truncate" x-text="buttonText"></span>
                                <span class="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                                    <i class="bi bi-chevron-down text-gray-400"></i>
                                </span>
                            </button>

                            <div x-show="dropdownOpen" class="absolute z-10 mt-1 w-full bg-white shadow-lg max-h-60 rounded-md py-1 text-base ring-1 ring-black ring-opacity-5 overflow-auto focus:outline-none sm:text-sm" style="display: none;">
                                <template x-for="user in availableUsers" :key="user.id">
                                    <div class="flex items-center px-4 py-2 hover:bg-gray-100 cursor-pointer" @click="const id = String(user.id); selectedUsers.includes(id) ? selectedUsers = selectedUsers.filter(u => u !== id) : selectedUsers.push(id)">
                                        <input type="checkbox" :checked="selectedUsers.includes(String(user.id))" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded pointer-events-none">
                                        <span class="ml-3 block truncate" :class="{ 'font-semibold': selectedUsers.includes(String(user.id)) }" x-text="user.name"></span>
                                    </div>
                                </template>
                            </div>
                        </div>
                        
                        <!-- Hidden Inputs for Form Submission -->
                        <template x-for="userId in selectedUsers" :key="userId">
                            <input type="hidden" name="user_ids[]" :value="userId">
                        </template>
                        
                        <p class="text-xs text-gray-500 mt-1">Klik untuk memilih beberapa pengguna.</p>
                    </div>

                    {{-- Filter Rentang Tanggal --}}
                    <div>
                        <label for="start_date" class="block text-sm font-medium text-gray-700">Dari Tanggal</label>
                        <input type="date" name="start_date" id="start_date" value="{{ request('start_date') }}" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label for="end_date" class="block text-sm font-medium text-gray-700">Sampai Tanggal</label>
                        <input type="date" name="end_date" id="end_date" value="{{ request('end_date') }}" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                    </div>

                </div>

                {{-- Tombol Filter --}}
                <div class="mt-6 flex justify-end">
                    <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <i class="bi bi-search mr-2"></i> Tampilkan Data
                    </button>
                </div>
            </form>
        </div>

        {{-- Hasil Data Table --}}
        @if(request('report_type') && isset($data))
        <div class="mt-8">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-medium text-gray-900">Preview Data ({{ $data->count() }} rows)</h3>
                <div class="flex space-x-2">
                    <a href="{{ route('admin.reports.generate', array_merge(request()->all(), ['format' => 'pdf'])) }}" target="_blank" class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none">
                        <i class="bi bi-file-earmark-pdf text-red-500 mr-2"></i> Export PDF
                    </a>
                    <a href="{{ route('admin.reports.generate', array_merge(request()->all(), ['format' => 'xlsx'])) }}" target="_blank" class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none">
                        <i class="bi bi-file-earmark-excel text-green-500 mr-2"></i> Export Excel
                    </a>
                </div>
            </div>

            <div class="bg-white shadow overflow-hidden border-b border-gray-200 sm:rounded-lg overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            @foreach($headers as $header)
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    {{ $header }}
                                </th>
                            @endforeach
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @forelse($data as $item)
                            <tr>
                                @if(request('report_type') == 'attendances')
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $item->created_at->format('d-m-Y H:i') }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->user->name ?? '-' }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full {{ $item->type == 'clock_in' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                                            {{ $item->type == 'clock_in' ? 'Masuk' : 'Keluar' }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->latitude }}, {{ $item->longitude }}</td>
                                
                                @elseif(request('report_type') == 'sales-activities')
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $item->created_at->format('d-m-Y H:i') }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->user->name ?? '-' }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->location_name }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ ucfirst($item->status) }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-500 truncate max-w-xs">{{ $item->note }}</td>

                                @elseif(request('report_type') == 'customers')
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ $item->id }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->name }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->nik }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->no_hp }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->salesActivity->user->name ?? '-' }}</td>

                                @elseif(request('report_type') == 'schedules')
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{{ \Carbon\Carbon::parse($item->scheduled_at)->format('d-m-Y') }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->title }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->customer->name ?? '-' }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $item->teamLeader->name ?? '-' }}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ ucfirst($item->status) }}</td>
                                @endif
                            </tr>
                        @empty
                            <tr>
                                <td colspan="{{ count($headers) }}" class="px-6 py-4 text-center text-sm text-gray-500">Tidak ada data ditemukan untuk filter ini.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        @endif
    </div>
</div>

@endsection
