@extends('layouts.app')

@section('title', 'Kelola Pengguna')

@section('content')
    <!-- Success/Error Messages -->
    @if (session('success'))
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded mb-6">
            <p class="font-bold">Success!</p>
            <p>{{ session('success') }}</p>
        </div>
    @endif

    @if (session('error'))
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded mb-6">
            <p class="font-bold">Error!</p>
            <p>{{ session('error') }}</p>
        </div>
    @endif

    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold text-gray-800">Manage Users</h2>
        <div class="flex gap-2">
            <a href="{{ route('admin.activity.index') }}"
                class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition">
                <i class="bi bi-activity"></i> User Activity
            </a>
            <button onclick="openModal('create-modal')"
                class="px-4 py-2 bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 transition cursor-pointer">
                Add User
            </button>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-xl p-8 overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col"
                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                    </th>
                    <th scope="col"
                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Email
                    </th>
                    <th scope="col"
                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Role
                    </th>
                    <th scope="col" class="relative px-6 py-3">
                        <span class="sr-only">Action</span>
                    </th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                @forelse ($users as $user)
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">{{ $user->name }}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-500">{{ $user->email }}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            @php
                                $roleColor = '';
                                switch ($user->role) {
                                    case 'admin':
                                        $roleColor = 'bg-red-100 text-red-800';
                                        break;
                                    case 'teknisi':
                                        $roleColor = 'bg-green-100 text-green-800';
                                        break;
                                    case 'sales':
                                        $roleColor = 'bg-blue-100 text-blue-800';
                                        break;
                                    default:
                                        $roleColor = 'bg-gray-100 text-gray-800';
                                        break;
                                }
                            @endphp
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full {{ $roleColor }}">
                                {{ $user->role }}
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button type="button"
                                onclick="editUser({{ $user->id }}, '{{ str_replace("'", "\\'", $user->name) }}', '{{ str_replace("'", "\\'", $user->email) }}', '{{ $user->role }}')"
                                class="text-indigo-600 hover:text-indigo-900 mr-2 cursor-pointer">
                                Edit
                            </button>
                            <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST"
                                class="inline-block"
                                onsubmit="return confirm('Remove user will permanently in database, are you sure to remove {{ $user->name }}');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:text-red-900">Delete</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="px-6 py-4 whitespace-nowrap text-center text-gray-500">
                            No one sign-up.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- Memanggil konten dari file terpisah untuk modal --}}
    @include('admin.users.create')

    
    @include('admin.users.edit')

    <script>
        // Fallback jika custom.js tidak dimuat
        if (typeof openModal === 'undefined') {
            window.openModal = function(modalId) {
                const modal = document.getElementById(modalId);
                if (modal) {
                    modal.classList.remove('hidden');
                    modal.classList.add('flex');
                    setTimeout(() => {
                        const content = modal.querySelector('.modal-content');
                        if (content) {
                            content.classList.remove('scale-95', 'opacity-0');
                            content.classList.add('scale-100', 'opacity-100');
                        }
                    }, 10);
                }
            };

            window.closeModal = function(modalId) {
                const modal = document.getElementById(modalId);
                if (modal) {
                    const content = modal.querySelector('.modal-content');
                    if (content) {
                        content.classList.remove('scale-100', 'opacity-100');
                        content.classList.add('scale-95', 'opacity-0');
                    }
                    setTimeout(() => {
                        modal.classList.add('hidden');
                        modal.classList.remove('flex');
                    }, 300);
                }
            };

            // Edit user function
            window.editUser = function(userId, userName, userEmail, userRole) {
                const form = document.getElementById('edit-user-form');
                const updateUrl = '{{ url("admin/kelola-pengguna") }}/' + userId;

                form.setAttribute('action', updateUrl);

                document.getElementById('edit-name').value = userName;
                document.getElementById('edit-email').value = userEmail;
                document.getElementById('edit-password').value = '';

                // Uncheck all radio buttons first
                const allRadios = document.querySelectorAll('#edit-modal input[name="role"]');
                allRadios.forEach(radio => {
                    radio.checked = false;
                });

                // Check the correct role
                const roleRadio = document.querySelector('#edit-modal input[name="role"][value="' + userRole + '"]');
                if (roleRadio) {
                    roleRadio.checked = true;
                }

                openModal('edit-modal');
            };
        }
    </script>

@endsection
