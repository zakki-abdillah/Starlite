<div id="edit-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden modal-container">
    <!-- Background blur + overlay -->
    <div onclick="closeModal('edit-modal')" class="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity">
    </div>

    <!-- Modal content -->
    <div class="relative bg-white shadow-xl rounded-xl p-8 max-w-lg w-full modal-content">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-gray-800">Edit Pengguna</h3>
            <button type="button" onclick="closeModal('edit-modal')" class="text-gray-500 hover:text-gray-700">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <form id="edit-user-form" action="" method="POST" class="space-y-4 no-success">
            @csrf
            @method('PUT')

            <!-- Nama -->
            <div>
                <label for="edit-name" class="block text-gray-700 font-medium mb-2">Nama</label>
                <input type="text" name="name" id="edit-name" required
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm
                              focus:outline-none focus:ring-0 focus:border-gray-300
                              focus:shadow-lg focus:shadow-red-300 transition">
            </div>

            <!-- Email -->
            <div>
                <label for="edit-email" class="block text-gray-700 font-medium mb-2">Email</label>
                <input type="email" name="email" id="edit-email" required
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm
                              focus:outline-none focus:ring-0 focus:border-gray-300
                              focus:shadow-lg focus:shadow-red-300 transition">
            </div>

            <!-- Role pakai radio -->
            <div>
                <label class="block text-gray-700 font-medium mb-2">Peran (Role)</label>
                <div class="flex items-center space-x-6">
                    <label class="flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="role" value="admin" class="text-red-600 focus:ring-red-500">
                        <span>Admin</span>
                    </label>
                    <label class="flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="role" value="teknisi" class="text-red-600 focus:ring-red-500">
                        <span>Teknisi</span>
                    </label>
                    <label class="flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="role" value="sales" class="text-red-600 focus:ring-red-500">
                        <span>Sales</span>
                    </label>
                    <label class="flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="role" value="waspang" class="text-red-600 focus:ring-red-500">
                        <span>Waspang</span>
                    </label>
                </div>
            </div>

            <!-- Password -->
            <div>
                <label for="edit-password" class="block text-gray-700 font-medium mb-2">Password (kosongkan jika tidak
                    diganti)</label>
                <input type="password" name="password" id="edit-password"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm
                              focus:outline-none focus:ring-0 focus:border-gray-300
                              focus:shadow-lg focus:shadow-red-300 transition">
            </div>

            <!-- Buttons -->
            <div class="flex justify-end space-x-3 pt-4">
                <button type="button" onclick="closeModal('edit-modal')"
                    class="px-5 py-2.5 text-gray-600 bg-gray-200 rounded-lg
                            hover:bg-gray-300 transition duration-300 ease-in-out">
                    Batal
                </button>
                <button type="submit"
                    class="px-5 py-2.5 bg-red-600 text-white rounded-lg shadow-md
                            hover:bg-red-700 transition duration-300 ease-in-out">
                    Simpan
                </button>
            </div>

        </form>
    </div>
</div>
