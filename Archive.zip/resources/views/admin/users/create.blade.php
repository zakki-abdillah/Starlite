{{-- resources/views/admin/crate_user.blade.php --}}
<div id="create-modal"
     class="modal-container fixed inset-0 z-50 hidden items-center justify-center modal-backdrop-blur bg-black/30">
    <div class="modal-content bg-white rounded-xl shadow-lg p-6 w-full max-w-md transform transition-all duration-300 scale-95 opacity-0">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-lg font-semibold text-gray-800">Tambah Pengguna</h2>
            <button type="button" onclick="closeModal('create-modal')"
                    class="text-gray-500 hover:text-red-500 text-xl font-bold">
                &times;
            </button>
        </div>

        <form action="{{ route('admin.users.store') }}" method="POST" class="space-y-4">
            @csrf

            {{-- Nama --}}
            <div>
                <label for="name" class="block text-sm font-medium text-gray-700">Nama</label>
                <input type="text" id="name" name="name" required
                       class="mt-1 block w-full rounded-lg border border-gray-300 p-2.5 shadow-sm focus:border-red-500 focus:ring-red-500 focus:outline-none">
            </div>

            {{-- Email --}}
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" id="email" name="email" required
                       class="mt-1 block w-full rounded-lg border border-gray-300 p-2.5 shadow-sm focus:border-red-500 focus:ring-red-500 focus:outline-none">
            </div>

            {{-- Role (Radio merah 3 pilihan) --}}
            <div>
                <span class="block text-sm font-medium text-gray-700">Role</span>
                <div class="mt-2 flex flex-col space-y-2">
                    <label class="inline-flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="role" value="admin" required
                               class="text-red-500 focus:ring-red-500">
                        <span class="text-gray-700">Admin</span>
                    </label>
                    <label class="inline-flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="role" value="teknisi" required
                               class="text-red-500 focus:ring-red-500">
                        <span class="text-gray-700">Teknisi</span>
                    </label>
                    <label class="inline-flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="role" value="sales" required
                               class="text-red-500 focus:ring-red-500">
                        <span class="text-gray-700">Sales</span>
                    </label>
                     <label class="inline-flex items-center space-x-2 cursor-pointer">
                        <input type="radio" name="role" value="waspang" required
                               class="text-red-500 focus:ring-red-500">
                        <span class="text-gray-700">Waspang</span>
                    </label>
                </div>
            </div>

            {{-- Password (paling bawah) --}}
            <div class="password-toggle-container relative">
                <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                <input type="password" id="password" name="password" required
                       class="mt-1 block w-full rounded-lg border border-gray-300 p-2.5 shadow-sm focus:border-red-500 focus:ring-red-500 focus:outline-none">
                <button type="button"
                        class="password-toggle-btn absolute right-3 top-9 text-gray-500 hover:text-red-500">
                    <i class="bi bi-eye eye-icon"></i>
                </button>
            </div>

            {{-- Tombol Aksi --}}
            <div class="flex justify-end space-x-3 mt-6">
                <button type="button" onclick="closeModal('create-modal')"
                        class="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 text-gray-700">
                    Batal
                </button>
                <button type="submit"
                        class="px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white font-medium">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>
