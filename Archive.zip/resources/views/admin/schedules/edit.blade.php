<div id="edit-schedule-modal" class="fixed inset-0 z-50 hidden items-center justify-center">
    <!-- Backdrop -->
    <div class="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onclick="closeModal('edit-schedule-modal')"></div>

    <!-- Modal Content -->
    <div class="relative bg-white rounded-xl shadow-2xl w-full max-w-2xl m-4 overflow-hidden transform transition-all scale-100">
        <div class="bg-gray-50 px-6 py-4 border-b border-gray-100 flex justify-between items-center">
            <h3 class="text-lg font-bold text-gray-800">Edit Jadwal</h3>
            <button onclick="closeModal('edit-schedule-modal')" class="text-gray-400 hover:text-red-500 transition">
                <i class="bi bi-x-lg text-xl"></i>
            </button>
        </div>

        <form id="edit-schedule-form" method="POST" class="p-6">
            @csrf
            @method('PUT')
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Pekerjaan</label>
                    <input type="text" name="title" id="edit-title" class="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500" required>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Pelanggan</label>
                    <select name="customer_id" id="edit-customer_id" class="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500" required>
                        @foreach($customers as $customer)
                            <option value="{{ $customer->id }}">{{ $customer->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tipe Tugas</label>
                    <select name="task_type" id="edit-task_type" class="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500" required>
                        <option value="pemasangan">Pemasangan Baru</option>
                        <option value="maintenance">Maintenance</option>
                        <option value="perbaikan">Perbaikan</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Waktu Penugasan</label>
                    <input type="datetime-local" name="scheduled_at" id="edit-scheduled_at" class="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500" required>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select name="status" id="edit-status" class="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500" required>
                        <option value="pending">Pending</option>
                        <option value="in_progress">In Progress</option>
                        <option value="on_hold">On Hold</option>
                        <option value="completed">Completed</option>
                        <option value="canceled">Canceled</option>
                    </select>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tim Teknisi</label>
                    <div id="edit-technician-checkboxes" class="border border-gray-300 rounded-lg p-4 h-32 overflow-y-auto space-y-2 bg-white">
                        @forelse($technicians as $index => $tech)
                            <label class="flex items-center justify-between space-x-3 cursor-pointer p-2 rounded-md hover:bg-gray-50">
                                <div class="flex items-center space-x-3">
                                    <input type="checkbox" name="technician_ids[]" value="{{ $tech->id }}"
                                        class="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500 edit-tech-checkbox" data-tech-id="{{ $tech->id }}">
                                    <span class="text-gray-700">{{ $tech->name }}</span>
                                </div>
                                <input type="radio" name="team_leader_id" value="{{ $tech->id }}"
                                    class="h-4 w-4 text-blue-600 focus:ring-blue-500 edit-leader-radio" disabled>
                            </label>
                        @empty
                            <p class="text-gray-500">Tidak ada teknisi yang tersedia.</p>
                        @endforelse
                    </div>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Catatan</label>
                    <textarea name="work_note" id="edit-work_note" rows="2" class="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"></textarea>
                </div>
            </div>

            <div class="mt-6 flex justify-end gap-3">
                <button type="button" onclick="closeModal('edit-schedule-modal')" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">Batal</button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Update Jadwal</button>
            </div>
        </form>

        <script>
            // This script needs to be within the main page script block or here.
            // Let's assume it's better to have it in the main index.blade.php script block
            // to avoid duplication and ensure it runs in the right context.
            document.addEventListener('DOMContentLoaded', function () {
                const editContainer = document.getElementById('edit-schedule-modal');
                if (!editContainer) return;

                editContainer.addEventListener('change', function(e) {
                    if (e.target.classList.contains('edit-tech-checkbox')) {
                        const techId = e.target.dataset.techId;
                        const radio = editContainer.querySelector(`input.edit-leader-radio[value="${techId}"]`);
                        if (radio) {
                            radio.disabled = !e.target.checked;
                            if (!e.target.checked) {
                                radio.checked = false;
                            }
                        }
                    }
                });
            });
        </script>
    </div>
</div>
