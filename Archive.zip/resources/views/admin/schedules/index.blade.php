@extends('layouts.app')

@section('title', 'Manajemen Jadwal')

@section('content')
<div class="bg-white rounded-lg shadow-lg p-6">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h2 class="text-2xl font-bold text-gray-800">Jadwal Teknisi</h2>
            <p class="text-gray-600 text-sm">Schedule table.</p>
        </div>
        <button onclick="openModal('create-schedule-modal')" class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 transition">
            <i class="bi bi-plus-lg mr-2"></i>Add Schedule
        </button>
    </div>

    @if(session('success'))
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline">{{ session('success') }}</span>
    </div>
    @endif

    @if(session('warning'))
    <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline">{{ session('warning') }}</span>
    </div>
    @endif

    @if(session('error'))
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline">{{ session('error') }}</span>
    </div>
    @endif

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr class="bg-gray-50 text-gray-600 uppercase text-xs leading-normal">
                    <th class="py-3 px-6 text-left">Pelanggan</th>
                    <th class="py-3 px-6 text-left">Tugas</th>
                    <th class="py-3 px-6 text-left">Tim Teknisi</th>
                    <th class="py-3 px-6 text-center">Jadwal</th>
                    <th class="py-3 px-6 text-center">Status</th>
                    <th class="py-3 px-6 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="text-gray-600 text-sm font-light">
                @forelse($schedules as $schedule)
                <tr class="border-b border-gray-200 hover:bg-gray-100">
                    <td class="py-3 px-6 text-left">
                        <span class="font-medium">{{ $schedule->customer->name }}</span>
                        <p class="text-xs text-gray-500">{{ Str::limit($schedule->customer->address, 30) }}</p>
                    </td>
                    <td class="py-3 px-6 text-left">
                        <span class="font-medium">{{ $schedule->title }}</span>
                        <p class="text-xs text-gray-500 capitalize">{{ $schedule->task_type }}</p>
                    </td>
                    <td class="py-3 px-6 text-left">
                        <div class="flex items-center -space-x-2">
                            @foreach($schedule->technicians as $technician)
                            <div class="w-8 h-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center text-xs font-bold border-2 border-white" title="{{ $technician->name }}">
                                {{ strtoupper(substr($technician->name, 0, 1)) }}
                            </div>
                            @endforeach
                        </div>
                    </td>
                    <td class="py-3 px-6 text-center">
                        <span class="font-medium">{{ $schedule->scheduled_at->format('d M Y') }}</span>
                        <p class="text-xs text-gray-500">{{ $schedule->scheduled_at->format('H:i') }} WIB</p>
                    </td>
                    <td class="py-3 px-6 text-center">
                        @php
                            $statusColors = [
                                'pending' => 'bg-yellow-200 text-yellow-800',
                                'in_progress' => 'bg-blue-200 text-blue-800',
                                'completed' => 'bg-green-200 text-green-800',
                                'canceled' => 'bg-red-200 text-red-800',
                                'on_hold' => 'bg-gray-200 text-gray-800',
                            ];
                        @endphp
                        <span class="py-1 px-3 rounded-full text-xs font-semibold {{ $statusColors[$schedule->status] ?? '' }}">
                            {{ str_replace('_', ' ', $schedule->status) }}
                        </span>
                    </td>
                    <td class="py-3 px-6 text-center">
                        <div class="flex item-center justify-center">
                            <button onclick="toggleDetails(this, {{ $schedule->id }})" class="w-4 mr-2 transform hover:text-gray-500 hover:scale-110" title="Lihat Detail">
                                <i class="bi bi-eye"></i>
                            </button>
                            <button onclick="editSchedule({{ $schedule->id }})" class="w-4 mr-2 transform hover:text-blue-500 hover:scale-110" title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            <form action="{{ route('admin.schedules.destroy', $schedule->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus jadwal ini?');" class="inline-block">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="w-4 mr-2 transform hover:text-red-500 hover:scale-110" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <tr class="hidden bg-gray-50" data-schedule-id="{{ $schedule->id }}">
                    <td colspan="6" class="p-4 border-b border-gray-200">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                                <h4 class="font-bold text-gray-700 mb-1">Detail Pelanggan</h4>
                                <p><span class="font-semibold">No. HP:</span> {{ $schedule->customer->no_hp ?? 'N/A' }}</p>
                                <p><span class="font-semibold">Alamat:</span> {{ $schedule->customer->address }}</p>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-700 mb-1">Detail Pekerjaan</h4>
                                <p><span class="font-semibold">Dibuat oleh:</span> {{ $schedule->admin->name ?? 'N/A' }}</p>
                                <p><span class="font-semibold">Team Leader:</span> {{ $schedule->teamLeader->name ?? 'N/A' }}</p>
                                @if($schedule->work_note)
                                <p class="mt-2"><span class="font-semibold">Catatan Admin:</span><br>{{ $schedule->work_note }}</p>
                                @endif
                            </div>
                            @if(($schedule->status === 'on_hold' || $schedule->status === 'canceled') && $schedule->hold_reason)
                            <div class="text-red-600">
                                <h4 class="font-bold text-red-700 mb-1">Alasan Ditunda/Batal</h4>
                                <p>{{ $schedule->hold_reason }}</p>
                            </div>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="py-4 text-center text-gray-500">Belum ada jadwal yang dibuat.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

{{-- Include Modals --}}
@include('admin.schedules.create')
@include('admin.schedules.edit')

<script>
    function toggleDetails(button, scheduleId) {
        const detailRow = document.querySelector(`tr[data-schedule-id="${scheduleId}"]`);
        const icon = button.querySelector('i');
        if (detailRow) {
            const isHidden = detailRow.classList.contains('hidden');
            if (isHidden) {
                detailRow.classList.remove('hidden');
                icon.classList.remove('bi-eye');
                icon.classList.add('bi-eye-slash');
                button.title = "Sembunyikan Detail";
            } else {
                detailRow.classList.add('hidden');
                icon.classList.remove('bi-eye-slash');
                icon.classList.add('bi-eye');
                button.title = "Lihat Detail";
            }
        }
    }

    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
    }

    async function editSchedule(scheduleId) {
        try {
            const response = await fetch(`/admin/schedules/${scheduleId}/edit`);
            if (!response.ok) {
                throw new Error('Gagal mengambil data jadwal.');
            }
            const schedule = await response.json();

            const form = document.getElementById('edit-schedule-form');
            const updateUrl = `{{ url('admin/schedules') }}/${schedule.id}`;
            form.setAttribute('action', updateUrl);

            document.getElementById('edit-title').value = schedule.title;
            document.getElementById('edit-customer_id').value = schedule.customer_id;
            document.getElementById('edit-task_type').value = schedule.task_type;
            document.getElementById('edit-status').value = schedule.status;
            
            // Format datetime-local (YYYY-MM-DDTHH:mm)
            if (schedule.scheduled_at) {
                const scheduledDate = new Date(schedule.scheduled_at);
                // Adjust for timezone offset to display correctly in local time input
                const timezoneOffset = scheduledDate.getTimezoneOffset() * 60000;
                const localISOTime = new Date(scheduledDate.getTime() - timezoneOffset).toISOString().slice(0, 16);
                document.getElementById('edit-scheduled_at').value = localISOTime;
            }

            document.getElementById('edit-work_note').value = schedule.work_note || '';

            // Handle checkboxes for technicians
            const technicianIds = schedule.technicians.map(tech => tech.id.toString());
            const checkboxes = document.querySelectorAll('#edit-technician-checkboxes .edit-tech-checkbox');
            const radios = document.querySelectorAll('#edit-technician-checkboxes .edit-leader-radio');

            // Reset all first
            checkboxes.forEach(cb => cb.checked = false);
            radios.forEach(rb => {
                rb.checked = false;
                rb.disabled = true;
            });

            checkboxes.forEach(checkbox => {
                const isChecked = technicianIds.includes(checkbox.value);
                checkbox.checked = isChecked;
                const radio = document.querySelector(`.edit-leader-radio[value="${checkbox.value}"]`);
                if (radio) radio.disabled = !isChecked;
            });

            document.querySelector(`.edit-leader-radio[value="${schedule.team_leader_id}"]`).checked = true;

            openModal('edit-schedule-modal');

        } catch (error) {
            console.error('Error:', error);
            alert('Terjadi kesalahan saat memuat data edit. Silakan coba lagi.');
        }
    }

    // Close modal on escape key press
    document.addEventListener('keydown', function (event) {
        if (event.key === "Escape") {
            closeModal('create-schedule-modal');
            closeModal('edit-schedule-modal');
        }
    });
</script>
@endsection
