<div id="create-schedule-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden modal-container">
    <div onclick="closeModal('create-schedule-modal')" class="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity">
    </div>

    <div class="relative bg-white shadow-xl rounded-xl p-8 max-w-2xl w-full modal-content max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-gray-800">Buat Jadwal Baru</h3>
            <button type="button" onclick="closeModal('create-schedule-modal')" class="text-gray-500 hover:text-gray-700">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>

        <form action="{{ route('admin.schedules.store') }}" method="POST" class="space-y-4">
            @csrf
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="md:col-span-2">
                    <label class="block text-gray-700 font-medium mb-2">Judul Pekerjaan</label>
                    <input type="text" name="title" required placeholder="Contoh: Instalasi Baru"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm
                               focus:outline-none focus:ring-0 focus:border-gray-300
                               focus:shadow-lg focus:shadow-red-300 transition">
                </div>

                <div>
                    <label class="block text-gray-700 font-medium mb-2">Pelanggan</label>
                    <select name="customer_id" required
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm
                               focus:outline-none focus:ring-0 focus:border-gray-300
                               focus:shadow-lg focus:shadow-red-300 transition bg-white">
                        <option value="">-- Pilih Pelanggan --</option>
                        @foreach($customers as $customer)
                            <option value="{{ $customer->id }}">{{ $customer->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-gray-700 font-medium mb-2">Tipe Tugas</label>
                    <select name="task_type" required
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm
                               focus:outline-none focus:ring-0 focus:border-gray-300
                               focus:shadow-lg focus:shadow-red-300 transition bg-white">
                        <option value="pemasangan">Pemasangan Baru</option>
                        <option value="maintenance">Maintenance</option>
                        <option value="perbaikan">Perbaikan</option>
                    </select>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-gray-700 font-medium mb-2">Waktu Penugasan</label>
                    <input type="datetime-local" name="scheduled_at" required
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm
                               focus:outline-none focus:ring-0 focus:border-gray-300
                               focus:shadow-lg focus:shadow-red-300 transition">
                </div>

                <div class="md:col-span-2">
                    <label class="block text-gray-700 font-medium mb-2">Tim Teknisi</label>
                    <div class="border border-gray-300 rounded-lg p-4 h-32 overflow-y-auto space-y-2 bg-white">
                        @forelse($technicians as $index => $tech)
                            <label class="flex items-center justify-between space-x-3 cursor-pointer p-2 rounded-md hover:bg-gray-50">
                                <div class="flex items-center space-x-3">
                                    <input type="checkbox" name="technician_ids[]" value="{{ $tech->id }}"
                                        class="h-4 w-4 text-red-600 border-gray-300 rounded focus:ring-red-500 tech-checkbox" data-tech-id="{{ $tech->id }}">
                                    <span class="text-gray-700">{{ $tech->name }}</span>
                                </div>
                                <input type="radio" name="team_leader_id" value="{{ $tech->id }}"
                                    class="h-4 w-4 text-red-600 focus:ring-red-500 leader-radio" disabled>
                            </label>
                        @empty
                            <p class="text-gray-500">Tidak ada teknisi yang tersedia.</p>
                        @endforelse
                    </div>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-gray-700 font-medium mb-2">Catatan / Info Medan</label>
                    <textarea name="work_note" rows="3" placeholder="Informasi tambahan terkait lokasi atau kendala..."
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm
                               focus:outline-none focus:ring-0 focus:border-gray-300
                               focus:shadow-lg focus:shadow-red-300 transition"></textarea>
                </div>
            </div>

            <div class="flex justify-end space-x-3 pt-6 border-t border-gray-100 mt-4">
                <button type="button" onclick="closeModal('create-schedule-modal')"
                    class="px-6 py-2.5 text-gray-600 bg-gray-200 rounded-lg
                            hover:bg-gray-300 transition duration-300 ease-in-out font-medium">
                    Batal
                </button>
                <button type="submit"
                    class="px-6 py-2.5 bg-red-600 text-white rounded-lg shadow-md
                            hover:bg-red-700 transition duration-300 ease-in-out font-medium">
                    Simpan Jadwal
                </button>
            </div>
        </form>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const container = document.getElementById('create-schedule-modal');
                if (!container) return;

                container.addEventListener('change', function(e) {
                    if (e.target.classList.contains('tech-checkbox')) {
                        const techId = e.target.dataset.techId;
                        const radio = container.querySelector(`input.leader-radio[value="${techId}"]`);
                        if (radio) {
                            radio.disabled = !e.target.checked;
                            if (!e.target.checked) {
                                radio.checked = false;
                            }
                        }
                    }
                });
            });
        </script>
    </div>
</div>