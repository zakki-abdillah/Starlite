@extends('layouts.app')

@section('title', 'Buat SOP Baru')

@section('content')
<style>
    #editor ul { list-style-type: disc; margin-left: 1.5rem; }
    #editor ol { list-style-type: decimal; margin-left: 1.5rem; }
    #editor li { margin-bottom: 0.25rem; }
</style>

<div class="p-6">
    <div class="bg-white rounded-xl shadow-lg max-w-2xl mx-auto">
        <div class="p-4 border-b border-gray-100">
            <h2 class="text-lg font-semibold text-gray-800">Formulir SOP Baru</h2>
        </div>
        <form action="{{ route('admin.sop.store') }}" method="POST" class="p-6 space-y-4" id="sopForm">
            @csrf
            <div>
                <label for="title" class="block text-sm font-medium text-gray-700 mb-1">Judul SOP</label>
                <input type="text" name="title" id="title" value="{{ old('title') }}" required class="w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                @error('title') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Konten SOP</label>
                <div class="border border-gray-300 rounded-lg overflow-hidden focus-within:ring-1 focus-within:ring-blue-500 focus-within:border-blue-500">
                    <!-- Simple Toolbar -->
                    <div class="bg-gray-50 border-b border-gray-300 p-2 flex gap-2">
                        <button type="button" onmousedown="event.preventDefault(); document.execCommand('bold', false, null);" class="p-1.5 rounded hover:bg-gray-200 text-gray-700 font-bold border border-gray-300 bg-white" title="Bold">
                            <i class="bi bi-type-bold"></i>
                        </button>
                        <button type="button" onmousedown="event.preventDefault(); document.execCommand('italic', false, null);" class="p-1.5 rounded hover:bg-gray-200 text-gray-700 italic border border-gray-300 bg-white" title="Italic">
                            <i class="bi bi-type-italic"></i>
                        </button>
                        <div class="w-px bg-gray-300 mx-1"></div>
                        <button type="button" onmousedown="event.preventDefault(); document.execCommand('insertUnorderedList', false, null);" class="p-1.5 rounded hover:bg-gray-200 text-gray-700 border border-gray-300 bg-white" title="Bullet List">
                            <i class="bi bi-list-ul"></i>
                        </button>
                        <button type="button" onmousedown="event.preventDefault(); document.execCommand('insertOrderedList', false, null);" class="p-1.5 rounded hover:bg-gray-200 text-gray-700 border border-gray-300 bg-white" title="Numbered List">
                            <i class="bi bi-list-ol"></i>
                        </button>
                    </div>
                    <!-- Editor Area -->
                    <div id="editor" contenteditable="true" class="p-4 min-h-[300px] outline-none prose max-w-none bg-white">
                        {!! old('content') !!}
                    </div>
                </div>
                <!-- Hidden Textarea to store content on submit -->
                <textarea name="content" id="content" class="hidden">{{ old('content') }}</textarea>
                @error('content') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
            </div>

            <div>
                <label for="role" class="block text-sm font-medium text-gray-700 mb-1">Tujukan Untuk Role</label>
                <select name="role" id="role" required class="w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    <option value="">-- Pilih Role --</option>
                    <option value="teknisi" @if(old('role') == 'teknisi') selected @endif>Teknisi</option>
                    <option value="sales" @if(old('role') == 'sales') selected @endif>Sales</option>
                    <option value="waspang" @if(old('role') == 'waspang') selected @endif>Waspang</option>
                </select>
                @error('role') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
            </div>
            <div class="flex justify-end gap-4 pt-4">
                <a href="{{ route('admin.sop.index') }}" class="px-4 py-2 rounded-lg bg-gray-200 text-gray-800 font-semibold text-sm hover:bg-gray-300 transition">Batal</a>
                <button type="submit" class="px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700 transition">Simpan SOP</button>
            </div>
        </form>
    </div>
</div>

<script>
    document.getElementById('sopForm').addEventListener('submit', function() {
        document.getElementById('content').value = document.getElementById('editor').innerHTML;
    });
</script>
@endsection