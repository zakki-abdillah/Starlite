@extends('layouts.app')

@section('title', 'Kelola SOP')

@section('content')
<div class="p-6">
    <div class="bg-white rounded-xl shadow-lg">
        <div class="p-4 border-b border-gray-100 flex justify-between items-center">
            <h2 class="text-lg font-semibold text-gray-800">Daftar SOP</h2>
            <a href="{{ route('admin.sop.create') }}" class="px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700 transition">
                Buat SOP Baru
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-500">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3">Judul</th>
                        <th scope="col" class="px-6 py-3">Untuk Role</th>
                        <th scope="col" class="px-6 py-3">Dibuat Pada</th>
                        <th scope="col" class="px-6 py-3 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($sops as $sop)
                    <tr class="bg-white border-b hover:bg-gray-50">
                        <td class="px-6 py-4 font-medium text-gray-900">
                            {{ $sop->title }}
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 rounded text-xs font-bold
                                {{ $sop->role == 'teknisi' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800' }}">
                                {{ ucfirst($sop->role) }}
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            {{ $sop->created_at->format('d M Y') }}
                        </td>
                        <td class="px-6 py-4 text-right flex justify-end gap-2">
                            <a href="{{ route('admin.sop.edit', $sop) }}" class="font-medium text-blue-600 hover:underline">Edit</a>
                            <form action="{{ route('admin.sop.destroy', $sop) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus SOP ini?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="font-medium text-red-600 hover:underline">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="px-6 py-10 text-center text-gray-500">Belum ada SOP yang dibuat.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
