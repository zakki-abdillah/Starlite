@extends('layouts.mobile')

@section('header_title', 'Detail Tugas')

@section('content')
<div class="p-4 pb-24 max-w-4xl mx-auto">
    {{-- Back Button --}}
    <a href="{{ route('teknisi.dashboard') }}" class="inline-flex items-center gap-2 text-gray-400 hover:text-white mb-4">
        <i class="bi bi-arrow-left"></i>
        <span>Kembali ke Dashboard</span>
    </a>

    {{-- Success/Error Messages --}}
    @if(session('success'))
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline">{{ session('success') }}</span>
    </div>
    @endif
    @if(session('error'))
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline">{{ session('error') }}</span>
    </div>
    @endif

    <div class="bg-[#171a21] rounded-xl shadow-lg overflow-hidden border border-gray-800">
        <div class="p-6 border-b border-gray-800">
            <div class="flex justify-between items-start">
                <div>
                    <h2 class="text-2xl font-bold text-white">{{ $schedule->title }}</h2>
                    <p class="text-sm text-gray-400">Jadwal: {{ $schedule->scheduled_at->format('d M Y, H:i') }}</p>
                </div>
                @php
                    $statusColors = [
                        'pending' => 'bg-yellow-100 text-yellow-800',
                        'in_progress' => 'bg-blue-100 text-blue-800',
                        'completed' => 'bg-green-100 text-green-800',
                        'canceled' => 'bg-red-100 text-red-800',
                        'on_hold' => 'bg-gray-200 text-gray-800',
                    ];
                @endphp
                <span class="py-1 px-3 rounded-full text-xs font-semibold uppercase {{ $statusColors[$schedule->status] ?? '' }}">
                    {{ str_replace('_', ' ', $schedule->status) }}
                </span>
            </div>
        </div>

        <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {{-- Kolom Kiri: Info Pelanggan & Tim --}}
            <div class="space-y-4">
                <div>
                    <h4 class="font-semibold text-gray-300 mb-2">Info Pelanggan</h4>
                    <div class="bg-gray-900 p-4 rounded-lg border border-gray-800">
                        <p class="font-bold text-lg text-white">{{ $schedule->customer->name }}</p>
                        <p class="text-sm text-gray-400">{{ $schedule->customer->address }}</p>
                        <div class="mt-3 flex gap-2">
                            @if($schedule->latitude && $schedule->longitude)
                            <a href="https://www.google.com/maps/dir/?api=1&destination={{ $schedule->latitude }},{{ $schedule->longitude }}" target="_blank" class="text-sm bg-blue-600 text-white px-3 py-1.5 rounded-md flex items-center gap-1.5 hover:bg-blue-700 transition">
                                <i class="bi bi-map-fill"></i> Navigasi
                            </a>
                            @endif
                            <a href="https://wa.me/{{ preg_replace('/^0/', '62', $schedule->customer->no_hp) }}" target="_blank" class="text-sm bg-green-600 text-white px-3 py-1.5 rounded-md flex items-center gap-1.5 hover:bg-green-700 transition">
                                <i class="bi bi-whatsapp"></i> Chat
                            </a>
                        </div>
                    </div>
                </div>
                <div>
                    <h4 class="font-semibold text-gray-300 mb-2">Tim Bertugas</h4>
                    <ul class="space-y-2">
                        @foreach($schedule->technicians as $technician)
                        <li class="flex items-center gap-3 p-2 bg-gray-900 rounded-lg border border-gray-800">
                            <div class="w-8 h-8 rounded-full bg-gray-800 text-gray-400 flex items-center justify-center text-sm font-bold border border-gray-700">
                                {{ strtoupper(substr($technician->name, 0, 1)) }}
                            </div>
                            <span class="text-gray-300">{{ $technician->name }}</span>
                            @if($technician->id == $schedule->team_leader_id)
                                <span class="ml-auto text-xs font-bold text-red-600 bg-red-100 px-2 py-0.5 rounded-full">LEADER</span>
                            @endif
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>

            {{-- Kolom Kanan: Update Status (Hanya untuk Team Leader) --}}
            <div>
                <h4 class="font-semibold text-gray-300 mb-2">Update Progress</h4>
                @if(Auth::id() == $schedule->team_leader_id)
                    @if(!in_array($schedule->status, ['completed', 'canceled']))
                    <form action="{{ route('technician.schedules.update', $schedule->id) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="bg-gray-900 p-4 rounded-lg border border-gray-800 space-y-4">
                            <div>
                                <label for="status" class="block text-sm font-medium text-gray-400">Ubah Status Menjadi</label>
                                <select name="status" id="status-select" class="mt-1 block w-full rounded-md border-gray-700 bg-gray-800 text-white shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-500 focus:ring-opacity-50" required>
                                    @if($schedule->status == 'pending')
                                    <option value="in_progress">In Progress</option>
                                    @endif
                                    @if($schedule->status == 'in_progress' || $schedule->status == 'on_hold')
                                    <option value="completed">Completed</option>
                                    <option value="on_hold">On Hold</option>
                                    <option value="canceled">Canceled</option>
                                    @endif
                                </select>
                            </div>

                            <div id="reason-container" class="hidden">
                                <label for="hold_reason" class="block text-sm font-medium text-gray-400">Alasan (Wajib diisi)</label>
                                <textarea name="hold_reason" id="hold_reason" rows="3" class="mt-1 block w-full rounded-md border-gray-700 bg-gray-800 text-white shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-500 focus:ring-opacity-50" placeholder="Jelaskan kenapa pekerjaan ditunda atau dibatalkan..."></textarea>
                            </div>

                            <button type="submit" class="w-full bg-red-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-red-700 transition">
                                Update Status
                            </button>
                        </div>
                    </form>
                    @else
                    <div class="bg-gray-900 p-4 rounded-lg border border-gray-800 text-center text-gray-400">
                        <p class="font-semibold">Pekerjaan telah selesai atau dibatalkan.</p>
                        <p class="text-sm">Tidak ada aksi lebih lanjut yang diperlukan.</p>
                    </div>
                    @endif
                @else
                    <div class="bg-gray-900 p-4 rounded-lg border border-gray-800 text-center text-gray-500">
                        <p class="font-semibold">Hanya Team Leader yang dapat mengupdate status pekerjaan.</p>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const statusSelect = document.getElementById('status-select');
    const reasonContainer = document.getElementById('reason-container');
    const reasonTextarea = document.getElementById('hold_reason');

    if (statusSelect) {
        function toggleReason() {
            const selectedValue = statusSelect.value;
            if (selectedValue === 'on_hold' || selectedValue === 'canceled') {
                reasonContainer.classList.remove('hidden');
                reasonTextarea.required = true;
            } else {
                reasonContainer.classList.add('hidden');
                reasonTextarea.required = false;
            }
        }

        statusSelect.addEventListener('change', toggleReason);
        // Initial check
        toggleReason();
    }
});
</script>
@endsection
