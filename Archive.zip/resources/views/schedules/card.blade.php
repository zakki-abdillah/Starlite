<div class="mt-6">
    
    @forelse($schedules as $schedule)
    <div class="bg-[#171a21] rounded-xl shadow-lg border border-gray-800 p-4 mb-4 relative overflow-hidden">
        <!-- Status Strip -->
        <div class="absolute left-0 top-0 bottom-0 w-1.5 
            {{ $schedule->status == 'completed' ? 'bg-emerald-500' : ($schedule->status == 'in_progress' ? 'bg-blue-500' : 'bg-amber-500') }}">
        </div>

        <div class="pl-3">
            <div class="flex justify-between items-start mb-2">
                <div>
                    <h4 class="font-bold text-white">{{ $schedule->title }}</h4>
                    <p class="text-xs text-gray-400 flex items-center gap-1 mt-1">
                        <i class="bi bi-calendar-event"></i> {{ $schedule->scheduled_at->format('d M Y, H:i') }} WIB
                    </p>
                </div>
                <span class="px-2 py-1 text-[10px] font-bold uppercase rounded-lg 
                    {{ $schedule->status == 'completed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : ($schedule->status == 'in_progress' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20') }}">
                    {{ str_replace('_', ' ', $schedule->status) }}
                </span>
            </div>

            <!-- Info Pelanggan -->
            <div class="bg-gray-900 p-3 rounded-lg mb-3 border border-gray-800">
                <p class="text-sm font-semibold text-gray-200">{{ $schedule->customer->name }}</p>
                <p class="text-xs text-gray-500 mt-1">{{ $schedule->customer->address }}</p>
                <div class="mt-2 flex gap-2">
                    @if($schedule->latitude && $schedule->longitude)
                    <a href="https://www.google.com/maps/dir/?api=1&destination={{ $schedule->latitude }},{{ $schedule->longitude }}" target="_blank" class="text-xs bg-blue-600 text-white px-2 py-1 rounded flex items-center gap-1 hover:bg-blue-500 transition">
                        <i class="bi bi-map-fill"></i> Navigasi
                    </a>
                    @endif
                    <a href="https://wa.me/{{ preg_replace('/^0/', '62', $schedule->customer->no_hp) }}" target="_blank" class="text-xs bg-emerald-600 text-white px-2 py-1 rounded flex items-center gap-1 hover:bg-emerald-500 transition">
                        <i class="bi bi-whatsapp"></i> Chat
                    </a>
                </div>
            </div>

            <!-- Tombol Aksi (Update Status) -->
            <div class="mt-4">
                <a href="{{ route('technician.schedules.show', $schedule->id) }}" class="block w-full text-center bg-gray-700 text-white py-2 rounded-lg text-sm font-bold hover:bg-gray-600 transition">
                    Lihat Detail & Update
                </a>
            </div>
        </div>
    </div>
    @empty
    <div class="text-center py-10 bg-[#171a21] rounded-xl border border-dashed border-gray-800">
        <div class="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-800 text-gray-500 mb-3">
            <i class="bi bi-calendar-x text-xl"></i>
        </div>
        <p class="text-gray-500 text-sm">Belum ada jadwal tugas.</p>
    </div>
    @endforelse
</div>
