<div id="success-modal" 
     class="fixed inset-0 z-50 hidden items-center justify-center bg-black/30 backdrop-blur-sm">
    <div class="bg-white rounded-2xl shadow-xl p-8 flex flex-col items-center justify-center 
                transform scale-75 opacity-0 transition-all duration-500"
         id="success-content">

        {{-- Icon checklist animasi --}}
        <svg class="w-20 h-20 text-green-500 checkmark" viewBox="0 0 52 52">
            <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
            <path class="checkmark-check" fill="none" d="M14 27l7 7 17-17"/>
        </svg>

        <h2 class="mt-4 text-xl font-semibold text-gray-800">Berhasil!</h2>
        <p class="text-gray-600">Data berhasil diproses.</p>
    </div>
</div>
