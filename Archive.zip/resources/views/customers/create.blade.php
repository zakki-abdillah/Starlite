@extends('layouts.mobile')

@section('header_title', 'Form Pelanggan Baru')

@section('content')
<div class="p-4">
    <div class="bg-[#171a21] rounded-2xl shadow-lg p-6 border border-gray-800">
        <div class="mb-6 text-center">
            <div class="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-3 border border-blue-500/20">
                <i class="bi bi-person-plus-fill text-2xl text-blue-400"></i>
            </div>
            <h2 class="text-xl font-bold text-white">Data Pelanggan</h2>
            <p class="text-sm text-gray-400">Lengkapi data pelanggan yang sudah Deal.</p>
        </div>

        <form action="{{ route('customers.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            
            {{-- Menangkap ID Aktivitas jika ada (dari redirect Deal) --}}
            @if(isset($activity))
                <input type="hidden" name="activity_id" value="{{ $activity->id }}">
                <div class="mb-4 p-3 bg-emerald-500/5 rounded-lg border border-emerald-500/10 flex items-start gap-3">
                    <i class="bi bi-check-circle-fill text-emerald-500 mt-0.5"></i>
                    <div>
                        <p class="text-xs text-emerald-400 font-bold uppercase">Sumber Deal</p>
                        <p class="text-sm text-white font-medium">{{ $activity->location_name }}</p>
                    </div>
                </div>
            @endif

            <!-- Nama Lengkap -->
            <div class="mb-4">
                <label class="block text-xs font-medium text-gray-400 mb-1">Nama Lengkap</label>
                <input type="text" name="name" value="{{ old('name') }}" class="w-full rounded-xl border-gray-700 bg-gray-900 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500/20 placeholder-gray-600" placeholder="Nama sesuai KTP" required>
            </div>

            <!-- NIK -->
            <div class="mb-4">
                <label class="block text-xs font-medium text-gray-400 mb-1">NIK (KTP)</label>
                <input type="number" name="nik" value="{{ old('nik') }}" class="w-full rounded-xl border-gray-700 bg-gray-900 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500/20 placeholder-gray-600" placeholder="16 digit NIK" required>
            </div>

            <!-- No HP -->
            <div class="mb-4">
                <label class="block text-xs font-medium text-gray-400 mb-1">Nomor HP / WhatsApp</label>
                <input type="tel" name="no_hp" value="{{ old('no_hp') }}" class="w-full rounded-xl border-gray-700 bg-gray-900 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500/20 placeholder-gray-600" placeholder="08xxxxxxxxxx" required>
            </div>

            <!-- Alamat -->
            <div class="mb-4">
                <label class="block text-xs font-medium text-gray-400 mb-1">Alamat Pemasangan</label>
                <textarea name="address" rows="3" class="w-full rounded-xl border-gray-700 bg-gray-900 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500/20 placeholder-gray-600" placeholder="Alamat lengkap..." required>{{ old('address', $activity->location_name ?? '') }}</textarea>
                @if(isset($activity))
                <p class="text-xs text-gray-500 mt-1">*Alamat otomatis terisi dari lokasi check-in.</p>
                @endif
            </div>

            <!-- Foto KTP / Rumah -->
            <div class="mb-6">
                <label class="block text-xs font-medium text-gray-400 mb-1">Foto KTP / Lokasi</label>
                <input type="file" name="photo" accept="image/*" capture="environment" class="block w-full text-sm text-gray-400 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-blue-500/10 file:text-blue-400 hover:file:bg-blue-500/20 transition" required>
            </div>

            <div class="flex gap-3">
                <a href="{{ route('sales-activities.index') }}" class="w-1/3 flex justify-center py-3 px-4 border border-gray-700 rounded-xl shadow-sm text-sm font-bold text-gray-300 bg-gray-800/50 hover:bg-gray-800 transition">
                    Batal
                </a>
                <button type="submit" class="w-2/3 flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-lg shadow-blue-900/30 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 transition">
                    Simpan Data
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
