@extends('layouts.app')

@section('title', 'Admin Dashboard')
@section('content')
    <div class="mb-6">
        <h2 class="text-3xl font-bold text-gray-800">Admin Dashboard</h2>
        <p class="text-gray-600 mt-1">Welcome back, {{ $user->name }}! Here's your system overview.</p>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <!-- Total Users Card -->
        <div class="bg-white rounded-lg shadow-lg p-6 border-l-4 border-blue-500 hover:shadow-xl transition-shadow">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-600 uppercase">Total Users</p>
                    <p class="text-3xl font-bold text-gray-900 mt-2">{{ $totalUsers }}</p>
                </div>
                <div class="bg-blue-100 p-3 rounded-full">
                    <i class="bi bi-people-fill text-blue-600 text-2xl"></i>
                </div>
            </div>
        </div>

        <!-- Total Admin Card -->
        <div class="bg-white rounded-lg shadow-lg p-6 border-l-4 border-red-500 hover:shadow-xl transition-shadow">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-600 uppercase">Administrator</p>
                    <p class="text-3xl font-bold text-gray-900 mt-2">{{ $totalAdmin }}</p>
                </div>
                <div class="bg-red-100 p-3 rounded-full">
                    <i class="bi bi-shield-lock-fill text-red-600 text-2xl"></i>
                </div>
            </div>
        </div>

        <!-- Total Staff Card -->
        <div class="bg-white rounded-lg shadow-lg p-6 border-l-4 border-green-500 hover:shadow-xl transition-shadow">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-600 uppercase">Teknisi</p>
                    <p class="text-3xl font-bold text-gray-900 mt-2">{{ $totalTeknisi }}</p>
                </div>
                <div class="bg-green-100 p-3 rounded-full">
                    <i class="bi bi-person-badge-fill text-green-600 text-2xl"></i>
                </div>
            </div>
        </div>

        <!-- Total Students Card -->
        <div class="bg-white rounded-lg shadow-lg p-6 border-l-4 border-purple-500 hover:shadow-xl transition-shadow">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-600 uppercase">Sales</p>
                    <p class="text-3xl font-bold text-gray-900 mt-2">{{ $totalSales }}</p>
                </div>
                <div class="bg-purple-100 p-3 rounded-full">
                    <i class="bi bi-person-fill text-purple-600 text-2xl"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Welcome Message -->
    <div class="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg shadow-lg p-8 text-white">
        <div class="flex items-center">
            <i class="bi bi-emoji-smile text-5xl mr-4"></i>
            <div>
                <h3 class="text-2xl font-bold">Howdy, {{ $user->name }}!</h3>
                <p class="mt-2 text-blue-100">.
                </p>
            </div>
        </div>
    </div>
@endsection
