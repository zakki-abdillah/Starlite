<!DOCTYPE html>
<html lang="en" translate="no">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="google" content="notranslate">
    <meta http-equiv="Content-Language" content="en">
    <title>Starlite Indonesia</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('starlite.png') }}?v={{ time() }}">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: url('{{ asset('assets_image/input nama file disinix1') }}') center/cover no-repeat;
        }

        body::before {
            content: "";
            position: absolute;
            inset: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 0;
        }
    </style>
</head>

<body class="flex justify-center items-center min-h-screen relative font-sans notranslate">

    <div id="loginForm"
        class="relative z-10 bg-white bg-opacity-90 p-10 rounded-xl max-w-sm w-11/12 text-center opacity-0 transform translate-y-8 transition-all duration-1000 ease-in-out">
        <!--h1 class="text-blue-700 text-4xl font-bold mb-2">STARLITE</h1-->
        <center><img src="{{ asset('starlite.png') }}"></center>
        <p class="text-gray-600 mb-6">PT Integrasi Jaringan Ekosistem</p>

        @if ($errors->any())
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4 text-left">
                <ul class="list-disc list-inside text-sm">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}" class="space-y-4" onsubmit="this.querySelector('button[type=submit]').disabled = true; this.querySelector('button[type=submit]').innerText = 'Logging in...';">
            @csrf
            <div>
                <input type="email" name="email" placeholder="Email" required
                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-0 focus:outline-none focus:border-blue-500 transition-colors duration-300">
            </div>

            <div class="relative">
                <input type="password" id="password" name="password" placeholder="Password" required
                    class="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-0 focus:outline-none focus:border-blue-500 transition-colors duration-300">
                <div id="eyeContainer"
                    class="absolute inset-y-0 right-0 flex items-center pr-3 pl-2 cursor-pointer transition-colors duration-300 rounded-r-lg">
                    <i id="eyeIcon" class="bi-eye text-lg transition-colors duration-200"></i>
                </div>
            </div>

            <button type="submit"
                class="w-full py-3 bg-blue-700 text-white font-bold rounded-lg cursor-pointer transition-colors duration-300 hover:bg-blue-800">
                LogIn
            </button>

        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const loginForm = document.getElementById('loginForm');
            setTimeout(() => loginForm.classList.remove('opacity-0', 'translate-y-8'), 100);

            const password = document.getElementById('password');
            const eyeIcon = document.getElementById('eyeIcon');
            const eyeContainer = document.getElementById('eyeContainer');

            eyeContainer.addEventListener('click', () => {
                if (password.type === "password") {
                    password.type = "text";
                    eyeIcon.classList.remove("bi-eye");
                    eyeIcon.classList.add("bi-eye-slash");
                    eyeContainer.classList.add('bg-red-700');
                    eyeContainer.classList.remove('bg-white');
                    eyeIcon.classList.add('text-white');
                    eyeIcon.classList.remove('text-gray-500');
                } else {
                    password.type = "password";
                    eyeIcon.classList.remove("bi-eye-slash");
                    eyeIcon.classList.add("bi-eye");
                    eyeContainer.classList.remove('bg-red-700');
                    eyeContainer.classList.add('bg-white');
                    eyeIcon.classList.remove('text-white');
                    eyeIcon.classList.add('text-gray-500');
                }
            });
        });
    </script>
    <div class="absolute bottom-4 w-full text-center text-gray-400 text-sm z-50">
        &copy; 2026 Starlite Indonesia
    </div>

</body>

</html>
