<div class="space-y-4 pb-6">
    {{-- Header Section --}}
    <div class="px-4 pt-2">
        <h2 class="text-xl font-bold text-white">Tugas Instalasi Anda</h2>
        <p class="text-gray-400 text-xs">Daftar pengerjaan yang ditugaskan kepada Anda hari ini.</p>
    </div>

    @if(isset($installations) && $installations->isNotEmpty())
        <div class="px-4 space-y-4">
            @foreach($installations as $installation)
            <div class="bg-[#1e293b] border border-gray-700 rounded-2xl shadow-xl overflow-hidden transform active:scale-95 transition-all duration-200">
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <div class="flex-1">
                            <h3 class="text-lg font-bold text-white leading-tight mb-1" title="{{ $installation->title }}">
                                {{ $installation->title }}
                            </h3>
                            <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-blue-900/50 text-blue-300 border border-blue-800">
                                {{ $installation->job_code }}
                            </span>
                        </div>
                        <div class="bg-blue-600 p-2 rounded-xl">
                            @foreach($installation->coordinates as $coord)
                            <a href="https://www.google.com/maps/search/?api=1&query={{ $coord->latitude }},{{ $coord->longitude }}" target="_blank">
                                        <i class="bi bi-geo-alt-fill text-white"></i>
                            </a>
                            @endforeach
                        </div>
                    </div>
                    
                    <div class="mt-4 pt-4 border-t border-gray-700/50 flex items-center justify-between">
                        
                         <div class="text-[10px] text-gray-400">
                            <i class="bi bi-clock mr-1"></i> Progress: <span class="text-blue-400">{{ $installation->progress }} % </span>
                        </div>
                        
                        <a href="{{ route('waspang.installations.show', $installation->id) }}" 
                           class="flex items-center justify-center gap-2 px-6 py-2.5 bg-blue-600 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-900/20 hover:bg-blue-500 active:bg-blue-700 transition-colors w-1/2">
                            <span>PELAPORAN PROGRESS</span>
                            <i class="bi bi-arrow-right-short text-lg"></i>
                        </a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    @else
        <div class="mx-4 text-center py-12 bg-[#1e293b]/50 border-2 border-dashed border-gray-700 rounded-2xl">
            <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gray-800 text-gray-500 mb-3">
                <i class="bi bi-clipboard-x text-2xl"></i>
            </div>
            <p class="text-gray-400 text-sm font-medium">Belum ada tugas baru untuk Anda.</p>
        </div>
    @endif
</div>