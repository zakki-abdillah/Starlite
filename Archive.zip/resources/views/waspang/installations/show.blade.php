@extends('layouts.mobile')

@section('header_title', 'Menu Instalasi')
@section('header_bg', 'bg-slate-900')

@section('content')
{{-- Menggunakan Alpine.js untuk navigasi antar menu tanpa reload --}}
<div x-data="{ activeStage: null }" class="pb-20">

    {{-- TAMPILAN UTAMA: HEADER & GRID MENU --}}
    <div x-show="!activeStage" 
         x-transition:enter="transition ease-out duration-300" 
         x-transition:enter-start="opacity-0 transform scale-95" 
         x-transition:enter-end="opacity-100 transform scale-100">
        
        <div class="p-4 space-y-6">
            <div class="bg-[#1e293b] border border-gray-700 rounded-2xl shadow-xl p-5 relative overflow-hidden">
                <div class="relative z-10">
                    <h2 class="text-lg font-bold text-white leading-tight">{{ $installation->title }}</h2>
                    <div class="flex items-center gap-2 mt-1">
                        <span class="text-[10px] font-mono text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                            {{ $installation->job_code }}
                        </span>
                    </div>
                </div>
                <i class="bi bi-tower absolute -right-4 -bottom-4 text-6xl text-white/5"></i>
            </div>

            {{-- Grid Menu Tahapan --}}
            <div class="grid grid-cols-2 gap-4">
                @php
                    $stages = [
                        'prepare_work' => ['label' => 'Prepare Work', 'icon' => 'bi-clipboard-data'],
                        'civil_work' => ['label' => 'Civil Work', 'icon' => 'bi-bricks'],
                        'electrical_work' => ['label' => 'Electrical Work', 'icon' => 'bi-lightning-charge'],
                    ];
                    $isPreviousStageCompleted = true;
                @endphp

                @foreach ($stages as $stageKey => $stageInfo)
                    @php
                        $tasks = $tasksByStage->get($stageKey, collect());
                        $isCurrentStageLocked = !$isPreviousStageCompleted;
                        $allTasksInStageCompleted = $tasks->isNotEmpty() && $tasks->every(fn($task) => $task->status === 'completed');
                        
                        // Styling dinamis berdasarkan status
                        $cardClass = $isCurrentStageLocked ? 'opacity-50 grayscale cursor-not-allowed' : 'hover:scale-[1.02] active:scale-95 cursor-pointer';
                        $bgClass = $allTasksInStageCompleted ? 'bg-emerald-900/20 border-emerald-500/30' : 'bg-[#1e293b] border-gray-700';
                        $iconColor = $allTasksInStageCompleted ? 'text-emerald-400' : ($isCurrentStageLocked ? 'text-gray-500' : 'text-blue-400');
                    @endphp

                    <div @if(!$isCurrentStageLocked) @click="activeStage = '{{ $stageKey }}'" @endif 
                         class="{{ $bgClass }} border rounded-2xl p-4 flex flex-col items-center justify-center text-center gap-3 shadow-lg transition-all duration-200 {{ $cardClass }} relative overflow-hidden group h-32">
                        
                        <div class="p-3 rounded-full {{ $allTasksInStageCompleted ? 'bg-emerald-500/10' : 'bg-blue-500/10' }}">
                            <i class="bi {{ $stageInfo['icon'] }} text-2xl {{ $iconColor }}"></i>
                        </div>
                        
                        <div class="z-10">
                            <h3 class="text-sm font-bold text-white">{{ $stageInfo['label'] }}</h3>
                            <p class="text-[10px] {{ $allTasksInStageCompleted ? 'text-emerald-400' : 'text-gray-400' }} mt-1">
                                @if($allTasksInStageCompleted)
                                    <i class="bi bi-check-circle-fill mr-1"></i> Done
                                @else
                                    {{ $tasks->where('status', 'completed')->count() }}/{{ $tasks->count() }} Task
                                @endif
                            </p>
                        </div>

                       
                            <div class="absolute inset-0 border-2 border-emerald-500/20 rounded-2xl pointer-events-none"></div>
                       
                    </div>

                   
                @endforeach
            </div>
        </div>
    </div>

    @foreach ($stages as $stageKey => $stageInfo)
        <div x-show="activeStage === '{{ $stageKey }}'" 
             x-transition:enter="transition ease-out duration-300" 
             x-transition:enter-start="opacity-0 translate-x-10" 
             x-transition:enter-end="opacity-100 translate-x-0"
             class="fixed inset-0 bg-[#0f172a] z-50 overflow-y-auto" style="display: none;">
            @php
                $tasks = $tasksByStage->get($stageKey, collect());
                $taskGroups = $tasks->groupBy('task_group');
                $groupIcons = [
                    'Permit Community' => 'bi-file-earmark-text',
                    'Survey and Design' => 'bi-rulers',
                    'Pole' => 'bi-signpost-split',
                    'Pemasangan X-Frame' => 'bi-bounding-box',
                    'Instal ODP' => 'bi-hdd-stack',
                    'Aksesoris KU Distribusi' => 'bi-diagram-2',
                    'Aksesoris KU Feeder' => 'bi-diagram-3',
                    'Pulling Precon' => 'bi-grip-horizontal',
                    'Pemeriksaan Precon' => 'bi-patch-check',
                    'Electrical Work' => 'bi-lightning-charge',
                ];
            @endphp

            <div x-data="{ activeGroup: null }">

                {{-- TAMPILAN SUB-MENU (jika ada > 1 grup & belum ada yg dipilih) --}}
                <div x-show="!activeGroup" 
                     x-transition:enter="transition ease-out duration-300" 
                     x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100">
                    {{-- Header Sub-Menu dengan Tombol Back ke Menu Utama --}}
                    <div class="bg-slate-900 p-4 flex items-center gap-4 border-b border-gray-800 sticky top-0 z-30">
                        <button @click="activeStage = null" class="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-800 text-white hover:bg-gray-700 transition">
                            <i class="bi bi-arrow-left text-lg"></i>
                        </button>
                        <div>
                            <h2 class="text-lg font-bold text-white">{{ $stageInfo['label'] }}</h2>
                            <p class="text-xs text-gray-400">Pilih kategori pekerjaan</p>
                        </div>
                    </div>
                    {{-- List Sub-Menu --}}
                    <div class="p-4 space-y-3 pb-32">
                        @foreach ($taskGroups as $groupName => $tasksInGroup)
                            <div @click="activeGroup = '{{ $groupName }}'" class="bg-[#1e293b] border border-gray-700 rounded-2xl p-4 flex items-center gap-4 shadow-lg cursor-pointer active:scale-95 transition-transform">
                                <div class="p-3 rounded-full bg-blue-500/10">
                                    <i class="bi {{ $groupIcons[$groupName] ?? 'bi-list-task' }} text-xl text-blue-400"></i>
                                </div>
                                <div>
                                    <h3 class="font-bold text-white">{{ $groupName }}</h3>
                                    <p class="text-xs text-gray-400">{{ $tasksInGroup->where('status', 'completed')->count() }} dari {{ $tasksInGroup->count() }} selesai</p>
                                </div>
                                <i class="bi bi-chevron-right text-gray-500 ml-auto"></i>
                            </div>
                        @endforeach
                    </div>
                </div>

                <div x-show="activeGroup" 
                     x-transition:enter="transition ease-out duration-300" 
                     x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                     style="display: none;">
                    {{-- Header List Tugas dengan Tombol Back ke Sub-Menu (jika perlu) --}}
                    <div class="bg-slate-900 p-4 flex items-center gap-4 border-b border-gray-800 sticky top-0 z-30">
                        <button @click="activeGroup = null; $event.stopPropagation();" class="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-800 text-white hover:bg-gray-700 transition">
                            <i class="bi bi-arrow-left text-lg"></i>
                        </button>
                        <div>
                            <h2 class="text-lg font-bold text-white" x-text="activeGroup"></h2>
                            <p class="text-xs text-gray-400">Daftar tugas yang harus diselesaikan</p>
                        </div>
                    </div>

                    @foreach ($taskGroups as $groupName => $tasksInGroup)
                        <div x-show="activeGroup === '{{ $groupName }}'" class="p-4 space-y-4 pb-32">
                            @forelse ($tasksInGroup as $task)
                                @php
                                    $needs_coordinates = $task->stage === 'civil_work';
                                @endphp
                                <div class="bg-[#1e293b] p-5 rounded-2xl border border-gray-700 shadow-lg" x-data="taskForm({{ $needs_coordinates ? 'true' : 'false' }})">
                                    {{-- ... (Konten task card yang sudah ada, tidak perlu diubah) ... --}}
                                    <div class="flex justify-between items-start mb-4">
                                        <div class="flex items-start gap-3">
                                            <div class="mt-1">
                                                @if ($task->status == 'completed')
                                                    <div class="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center border border-emerald-500/30">
                                                        <i class="bi bi-check text-emerald-400 text-sm"></i>
                                                    </div>
                                                @else
                                                    <div class="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center border border-blue-500/30">
                                                        <span class="text-[10px] font-bold text-blue-400">{{ $loop->iteration }}</span>
                                                    </div>
                                                @endif
                                            </div>
                                            <div>
                                                <h4 class="text-white font-bold text-sm leading-snug">{{ $task->task_name }}</h4>
                                                <p class="text-[10px] text-gray-400 mt-1">
                                                    Status: 
                                                    <span class="{{ $task->status == 'completed' ? 'text-emerald-400' : 'text-amber-400' }}">
                                                        {{ $task->status == 'completed' ? 'Selesai' : 'Pending' }}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
            
                                    @if ($task->status == 'completed')
                                        <div class="bg-slate-900/50 rounded-xl p-3 border border-gray-700/50">
                                            <div class="flex items-center justify-between text-xs">
                                                <span class="text-gray-500">Selesai pada:</span>
                                                <span class="text-gray-300">{{ $task->completed_at->format('d M Y, H:i') }}</span>
                                            </div>
                                            <a href="{{ Storage::url($task->file_path) }}" target="_blank" class="mt-3 flex items-center justify-center gap-2 w-full py-2 bg-gray-800 hover:bg-gray-700 text-blue-400 rounded-lg text-xs font-medium transition">
                                                <i class="bi bi-file-earmark-text"></i> Lihat Bukti
                                            </a>
                                        </div>
                                    @else
                                        <form x-on:submit.prevent="submitForm($event.target)" action="{{ route('waspang.tasks.update', $task->id) }}" method="POST" enctype="multipart/form-data" class="space-y-4">
                                            @csrf
                                            @if($needs_coordinates)
                                            <input type="hidden" name="latitude" x-model="lat">
                                            <input type="hidden" name="longitude" x-model="lng">
                                            @endif

                                            {{-- Input Khusus untuk Task Tertentu --}}
                                            @if($task->task_name === 'Erection')
                                            <div class="space-y-2">
                                                <label class="block text-[10px] font-medium text-gray-400 uppercase tracking-wider">Kategori Tiang</label>
                                                <div class="grid grid-cols-3 gap-2">
                                                    @foreach(['T6', 'T7', 'T9'] as $type)
                                                    <div>
                                                        <input type="radio" name="details[pole_type]" value="{{ $type }}" id="pole_{{ $task->id }}_{{ $type }}" class="sr-only peer" required>
                                                        <label for="pole_{{ $task->id }}_{{ $type }}" class="block text-center text-xs font-bold py-2 px-3 rounded-lg border border-gray-700 peer-checked:bg-blue-600 peer-checked:text-white peer-checked:border-blue-600 transition cursor-pointer">
                                                            {{ $type }}
                                                        </label>
                                                    </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                            @endif

                                            {{-- Input Umum --}}
                                            <div>
                                                <label class="block text-[10px] font-medium text-gray-400 mb-1.5 uppercase tracking-wider">Upload Bukti</label>
                                                <div class="relative">
                                                    <input type="file" name="file" required class="block w-full text-xs text-gray-400 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-blue-600 file:text-white hover:file:bg-blue-500 transition cursor-pointer bg-slate-900/50 rounded-xl border border-gray-700">
                                                </div>
                                            </div>
                                            <div>
                                                <label class="block text-[10px] font-medium text-gray-400 mb-1.5 uppercase tracking-wider">Catatan</label>
                                                <textarea name="notes" rows="2" class="block w-full rounded-xl border-gray-700 bg-slate-900/50 text-white text-sm focus:border-blue-500 focus:ring-blue-500/20 placeholder-gray-600" placeholder="Tambahkan catatan..."></textarea>
                                            </div>
                                            @if($needs_coordinates)
                                            <div x-show="loadingLocation" class="text-xs text-blue-400 flex items-center gap-2">
                                                <i class="bi bi-geo-alt-fill animate-pulse"></i> <span>Mencari lokasi...</span>
                                            </div>
                                            @endif
                                            <button type="submit" :disabled="loadingLocation || submitting" class="w-full bg-blue-600 text-white py-3 rounded-xl font-bold text-sm shadow-lg shadow-blue-900/20 hover:bg-blue-500 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed">
                                                <template x-if="submitting">
                                                    <i class="bi bi-arrow-repeat animate-spin"></i>
                                                </template>
                                                <template x-if="!submitting">
                                                    <i class="bi bi-check-lg"></i>
                                                </template>
                                                <span x-text="submitting ? 'Mengirim...' : (loadingLocation ? 'Tunggu Lokasi...' : 'Tandai Selesai')"></span>
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            @empty
                                <div class="text-center py-10">
                                    <p class="text-gray-500 text-sm">Tidak ada tugas dalam kategori ini.</p>
                                </div>
                            @endforelse
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    @endforeach
</div>

<script>
    function taskForm(needs_gps = false) {
        return {
            lat: '',
            lng: '',
            loadingLocation: needs_gps,
            submitting: false,
            init() {
                if (needs_gps) {
                    if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(
                            (position) => {
                                this.lat = position.coords.latitude;
                                this.lng = position.coords.longitude;
                                this.loadingLocation = false;
                            },
                            (error) => {
                                alert('Gagal mengambil lokasi. Pastikan GPS aktif dan berikan izin akses lokasi.');
                                this.loadingLocation = false;
                            }
                        );
                    } else {
                        alert('Browser tidak mendukung Geolocation.');
                        this.loadingLocation = false;
                    }
                }
            },
            submitForm(form) {
                this.submitting = true;
                form.submit();
            }
        }
    }
</script>
@endsection
