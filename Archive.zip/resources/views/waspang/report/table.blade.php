<div class="bg-white p-5 rounded-xl shadow">

<table class="w-full text-center text-sm">

<thead>
<tr class="border-b text-gray-500">
    <th>Job</th>
    <th>Target</th>
    <th>Completed</th>
    <th>Daily</th>
    <th>Weekly</th>
    <th>Monthly</th>
    <th>Progress</th>
</tr>
</thead>

<tbody>
@forelse($items as $item)
<tr class="border-b hover:bg-gray-50">

<td class="py-3 font-semibold">{{ $item->name }}</td>

<td>{{ $item->target }}</td>

<td class="text-green-600 font-bold">{{ $item->completed }}</td>

<td class="text-blue-500 font-bold">{{ $item->daily }}</td>

<td class="text-yellow-500 font-bold">{{ $item->weekly }}</td>

<td class="text-purple-500 font-bold">{{ $item->monthly }}</td>

<td class="w-40">
    <div class="w-full bg-gray-200 h-3 rounded">
        <div class="h-3 rounded bg-green-500"
            style="width: {{ $item->progress }}%">
        </div>
    </div>
    <span class="text-xs">{{ $item->progress }}%</span>
</td>

</tr>
@empty
<tr>
<td colspan="7" class="py-4 text-gray-400">
    Tidak ada data
</td>
</tr>
@endforelse
</tbody>

</table>

</div>