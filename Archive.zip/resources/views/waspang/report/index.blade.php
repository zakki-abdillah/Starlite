@extends('layouts.app')

@section('content')
<div class="p-6 space-y-6 relative">

{{-- TOOLTIP --}}
<div id="tooltip"
     class="hidden absolute bg-black text-white text-xs px-2 py-1 rounded z-50"></div>

{{-- FILTER --}}
<select id="projectFilter" class="border px-3 py-2 rounded">
    <option value="">All Project</option>
    @foreach($projects as $p)
        <option value="{{ $p->id }}">{{ $p->title }}</option>
    @endforeach
</select>

{{-- TAB --}}
<div class="flex gap-2">
    <button onclick="switchTab('daily')" id="btn-daily" class="px-3 py-2 bg-blue-500 text-white rounded">Daily</button>
    <button onclick="switchTab('weekly')" id="btn-weekly" class="px-3 py-2 bg-gray-200 rounded">Weekly</button>
    <button onclick="switchTab('monthly')" id="btn-monthly" class="px-3 py-2 bg-gray-200 rounded">Monthly</button>
</div>

{{-- CHART --}}
<div class="bg-white p-6 rounded-xl shadow">
    <div id="chart" class="flex items-end gap-3 h-56"></div>
    <svg id="lineChart" width="100%" height="220"></svg>
</div>

{{-- TABLE --}}
<div class="bg-white p-5 rounded-xl shadow">
<table class="w-full text-center text-sm">
<thead>
<tr class="border-b">
    <th>Project</th>
    <th>Target</th>
    <th>Completed</th>
    <th>Progress</th>
</tr>
</thead>
<tbody id="table-body"></tbody>
</table>
</div>

</div>

<script>

let currentProject = '';
let currentTab = 'daily';
let charts = {};
let interval = null;

// INIT
document.addEventListener("DOMContentLoaded", () => {

    document.getElementById('projectFilter')
        .addEventListener('change', function(){
            currentProject = this.value;
            fetchData();
        });

    fetchData();
    startLive();
});

// FETCH AJAX
async function fetchData() {

    let url = `{{ route('waspang.report.data') }}?project_id=${currentProject}`;

    let res = await fetch(url);
    let json = await res.json();

    charts = json;

    renderTable(json.table);
    renderAll();
}

// AUTO REFRESH
function startLive(){
    if(interval) clearInterval(interval);
    interval = setInterval(fetchData,5000);
}

// SWITCH TAB
function switchTab(tab){

    currentTab = tab;

    document.querySelectorAll('[id^=btn-]').forEach(btn=>{
        btn.classList.remove('bg-blue-500','text-white');
        btn.classList.add('bg-gray-200');
    });

    document.getElementById('btn-'+tab)
        .classList.add('bg-blue-500','text-white');

    renderAll();
}

// RENDER ALL
function renderAll(){
    renderChart(charts[currentTab]);
    renderLine(charts[currentTab]);
}

// TABLE
function renderTable(data){

    let tbody = document.getElementById('table-body');
    tbody.innerHTML = '';

    data.forEach(item=>{
        tbody.innerHTML += `
            <tr class="border-b">
                <td>${item.name}</td>
                <td>${item.target}</td>
                <td>${item.completed}</td>
                <td>${item.progress}%</td>
            </tr>
        `;
    });
}

// BAR CHART
function renderChart(data){

    let el = document.getElementById('chart');
    el.innerHTML = '';

    let max = Math.max(...data.map(d=>d.value),1);

    data.forEach(item=>{

        let h = (item.value/max)*180;

        el.innerHTML += `
            <div class="flex-1 flex flex-col items-center group relative">

                <div class="absolute bottom-full hidden group-hover:block
                            bg-black text-white text-xs px-2 py-1 rounded">
                    ${item.label} : ${item.value}
                </div>

                <div class="w-full bg-blue-400 rounded-t-lg
                            transition-all duration-700"
                     style="height:${h}px">
                </div>

                <span class="text-xs">${item.value}</span>
                <span class="text-[10px] text-gray-400">${item.label}</span>
            </div>
        `;
    });
}

// LINE CHART
function renderLine(data){

    let svg = document.getElementById('lineChart');
    let tooltip = document.getElementById('tooltip');

    svg.innerHTML = '';

    let max = Math.max(...data.map(d=>d.value),1);

    let points = '';

    data.forEach((item,i)=>{
        let x = i*80 + 40;
        let y = 200 - (item.value/max*180);
        points += `${x},${y} `;
    });

    let line = document.createElementNS("http://www.w3.org/2000/svg","polyline");
    line.setAttribute("points",points);
    line.setAttribute("stroke","#3b82f6");
    line.setAttribute("fill","none");
    line.setAttribute("stroke-width","3");

    svg.appendChild(line);

    data.forEach((item,i)=>{

        let x = i*80 + 40;
        let y = 200 - (item.value/max*180);

        let c = document.createElementNS("http://www.w3.org/2000/svg","circle");

        c.setAttribute("cx",x);
        c.setAttribute("cy",y);
        c.setAttribute("r",6);
        c.setAttribute("fill","#3b82f6");

        c.addEventListener('mousemove',(e)=>{
            tooltip.classList.remove('hidden');
            tooltip.style.left = e.pageX + 10 + 'px';
            tooltip.style.top  = e.pageY - 20 + 'px';
            tooltip.innerHTML = `${item.label} : <b>${item.value}</b>`;
        });

        c.addEventListener('mouseleave',()=>{
            tooltip.classList.add('hidden');
        });

        svg.appendChild(c);
    });
}

</script>

@endsection