@extends('layouts.mobile')

@section('header_title', 'Dashboard Sales')

@section('content')
<div class="p-4">

    @include('attendances.card')

     @include('sales.activities.card')
</div>
@endsection