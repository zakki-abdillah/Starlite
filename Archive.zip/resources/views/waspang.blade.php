@extends('layouts.mobile')

@section('header_title', 'Dashboard')

@section('content')
<div class="p-4">
    @include('attendances.card')

    @include('waspang.index')
</div>
@endsection