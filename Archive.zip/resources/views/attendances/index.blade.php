@extends('layouts.mobile')

@section('header_title', 'Dashboard')

@section('content')
<div class="p-6 space-y-6">
    {{-- Flash Message --}}
    @if (session('success'))
        <div class="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-4 py-2.5 rounded-xl text-[11px] flex items-center gap-2" role="alert">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            <span class="font-medium">{{ session('success') }}</span>
        </div>
    @endif

    {{-- Attendance Status Card --}}
    @include('attendances.card')
@endsection