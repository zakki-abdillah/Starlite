<div class="bg-[#171a21] rounded-2xl p-5 border border-gray-800 shadow-lg relative overflow-hidden mb-6">
    <div class="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full -mr-10 -mt-10 blur-2xl"></div>

    @if ($todayAttendance)
        <div class="flex items-center gap-4 relative z-10">
            <div class="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
            </div>

            <div class="flex-1">
                <div class="flex justify-between items-center">
                    <p class="text-[9px] font-black text-gray-500 uppercase tracking-wider">Status Presensi</p>
                    <span class="text-[8px] px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-md font-bold uppercase">Live</span>
                </div>
                <h3 class="text-sm font-bold text-white mt-0.5">Sudah Absen {{ $todayAttendance->type == 'clock_in' ? 'Masuk' : 'Keluar' }}</h3>
                <p class="text-[10px] text-gray-400 mt-0.5 font-medium">
                    Pukul <span class="text-blue-400 font-bold tabular-nums">{{ $todayAttendance->created_at->format('H:i:s') }}</span> WIB
                </p>
            </div>
        </div>
    @else
        <div class="flex items-center gap-4 relative z-10">
            <div class="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
            </div>

            <div class="flex-1">
                <div class="flex justify-between items-center text-[9px] font-black uppercase tracking-wider">
                    <p class="text-gray-500">Attendance Status</p>
                    <span class="text-amber-500">Missing</span>
                </div>
                <h3 class="text-sm font-bold text-white mt-0.5">Belum Absen Masuk</h3>
                <p class="text-[10px] text-gray-500 mt-0.5 leading-tight font-medium">Silahkan tekan tombol kamera di bawah untuk mulai bekerja.</p>
            </div>
        </div>
    @endif
</div>