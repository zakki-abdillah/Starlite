@extends('layouts.mobile')

@section('header_title', 'Absen ' . ($type == 'clock_in' ? 'Masuk' : 'Keluar'))

@section('content')
    <div class="p-6 text-white">
        <form id="attendance-form" action="{{ route('attendance.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="type" value="{{ $type }}">
            <input type="hidden" name="latitude" id="latitude">
            <input type="hidden" name="longitude" id="longitude">
            <input type="file" name="photo" id="photo-input" class="hidden" accept="image/*" capture="user">

            {{-- Camera View --}}
            <div id="camera-container" class="relative w-full aspect-square bg-gray-900 rounded-2xl overflow-hidden border-2 border-gray-700 shadow-lg">
                <video id="camera-preview" class="w-full h-full object-cover" style="transform: scaleX(-1);" autoplay playsinline></video>
                <div id="loading-spinner" class="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/80 text-white">
                    <svg class="animate-spin h-8 w-8 text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <p class="mt-3 text-sm font-medium">Membuka kamera...</p>
                </div>
            </div>

            {{-- Captured Image Preview --}}
            <div id="preview-container" class="hidden relative w-full aspect-square bg-gray-900 rounded-2xl overflow-hidden border-2 border-blue-500 shadow-lg">
                <canvas id="canvas" class="hidden"></canvas>
                <img id="photo-preview" class="w-full h-full object-cover" src="" alt="Photo Preview">
            </div>

            {{-- Action Buttons --}}
            <div class="mt-6">
                <button type="button" id="capture-btn" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-4 rounded-xl transition duration-300 shadow-lg shadow-blue-900/30 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed">
                    <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                    Ambil Foto
                </button>

                <div id="retake-submit-container" class="hidden mt-4 grid grid-cols-2 gap-4">
                    <button type="button" id="retake-btn" class="w-full bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 px-4 rounded-xl transition duration-300">
                        Ulangi
                    </button>
                    <button type="submit" id="submit-btn" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-xl transition duration-300 flex items-center justify-center">
                        Kirim Absen
                    </button>
                </div>
            </div>

            <div id="error-message" class="mt-4 text-red-400 text-sm text-center"></div>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const video = document.getElementById('camera-preview');
            const canvas = document.getElementById('canvas');
            const photoPreview = document.getElementById('photo-preview');
            const captureBtn = document.getElementById('capture-btn');
            const retakeBtn = document.getElementById('retake-btn');
            const submitBtn = document.getElementById('submit-btn');
            const form = document.getElementById('attendance-form');
            const photoInput = document.getElementById('photo-input');
            const latInput = document.getElementById('latitude');
            const lonInput = document.getElementById('longitude');
            const errorMessage = document.getElementById('error-message');

            const cameraContainer = document.getElementById('camera-container');
            const previewContainer = document.getElementById('preview-container');
            const retakeSubmitContainer = document.getElementById('retake-submit-container');
            const loadingSpinner = document.getElementById('loading-spinner');

            let stream;

            async function startCamera() {
                captureBtn.disabled = true;

                errorMessage.textContent = '';
                loadingSpinner.style.display = 'flex';
                loadingSpinner.querySelector('p').textContent = 'Meminta izin kamera & lokasi...';

                if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                    loadingSpinner.style.display = 'none';
                    errorMessage.innerHTML = "Browser Anda tidak mendukung akses kamera atau koneksi tidak aman (HTTPS diperlukan).";
                    return;
                }

                try {
                    // Meminta izin kamera dan lokasi secara bersamaan
                    const [mediaStream, geoPosition] = await Promise.all([
                        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false }),
                        getLocation()
                    ]);

                    // Handle Camera Stream
                    stream = mediaStream;
                    video.srcObject = stream;
                    latInput.value = geoPosition.coords.latitude;
                    lonInput.value = geoPosition.coords.longitude;

                    video.onloadedmetadata = () => {
                        loadingSpinner.style.display = 'none';
                        captureBtn.disabled = false;
                        video.play().catch(e => console.log("Autoplay blocked:", e));
                    };
                } catch (err) {
                    loadingSpinner.style.display = 'none';
                    errorMessage.textContent = `Gagal mendapatkan izin: ${err.message}. Pastikan izin kamera dan lokasi diberikan.`;
                }
            }

            function getLocation() {
                return new Promise((resolve, reject) => {
                    if (!navigator.geolocation) {
                        reject('Geolocation tidak didukung oleh browser Anda.');
                        return;
                    }
                    navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true });
                });
            }

            captureBtn.addEventListener('click', () => {
                captureBtn.disabled = true;

                // Capture photo
                const context = canvas.getContext('2d');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                // Flip the canvas context horizontally to un-mirror the image
                context.translate(canvas.width, 0);
                context.scale(-1, 1);
                context.drawImage(video, 0, 0, canvas.width, canvas.height);

                const dataUrl = canvas.toDataURL('image/jpeg');
                photoPreview.src = dataUrl;

                canvas.toBlob(blob => {
                    const file = new File([blob], "attendance.jpg", { type: "image/jpeg" });
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    photoInput.files = dataTransfer.files;
                }, 'image/jpeg');

                // Switch views & stop camera
                cameraContainer.style.display = 'none';
                previewContainer.style.display = 'block';
                captureBtn.style.display = 'none';
                retakeSubmitContainer.style.display = 'grid';
                stream.getTracks().forEach(track => track.stop());
            });

            retakeBtn.addEventListener('click', () => {
                cameraContainer.style.display = 'block';
                previewContainer.style.display = 'none';
                captureBtn.style.display = 'flex';
                retakeSubmitContainer.style.display = 'none';
                photoInput.value = '';
                startCamera();
            });

            // Panggil fungsi utama untuk memulai kamera
            startCamera();
        });
    </script>
@endsection