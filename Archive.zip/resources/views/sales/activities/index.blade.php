@extends('layouts.mobile')

@section('header_title', 'Aktivitas Harian')

@section('content')
<div class="p-4" x-data="salesActivity()">
    
    <!-- Tombol Check-in -->
    <div class="mb-6 bg-[#171a21] rounded-2xl shadow-lg border border-gray-800 p-5 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full -mr-10 -mt-10 blur-2xl"></div>

        <h3 class="font-bold text-lg mb-4 text-white relative z-10">Kunjungan Baru</h3>
        <form action="{{ route('sales-activities.store') }}" method="POST" enctype="multipart/form-data" class="relative z-10">
            @csrf
            <input type="hidden" name="latitude" x-model="lat">
            <input type="hidden" name="longitude" x-model="lng">

            <div class="mb-4">
                <label class="block text-xs font-medium text-gray-400 mb-1">Nama Lokasi / Calon Pelanggan</label>
                <input type="text" name="location_name" class="block w-full rounded-xl border-gray-700 bg-gray-900 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500/20 placeholder-gray-600 sm:text-sm" required placeholder="Input text here...">
            </div>

            <div class="mb-4">
                <label class="block text-xs font-medium text-gray-400 mb-1">Foto Lokasi</label>
                <input type="file" name="photo" accept="image/*" capture="environment" class="block w-full text-sm text-gray-400 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-blue-500/10 file:text-blue-400 hover:file:bg-blue-500/20 transition">
            </div>

            <div x-show="loadingLocation" class="text-xs text-blue-400 mb-3 flex items-center gap-2">
                <i class="bi bi-geo-alt-fill animate-pulse"></i> Sedang mengambil lokasi...
            </div>

            <button type="submit" :disabled="!lat || !lng" class="w-full bg-blue-600 text-white py-3 px-4 rounded-xl font-bold shadow-lg shadow-blue-900/20 hover:bg-blue-700 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed transition-all">
                <span x-show="!lat">Tunggu Lokasi...</span>
                <span x-show="lat">Check-in Sekarang</span>
            </button>
        </form>
    </div>

    <!-- List Aktivitas -->
    <h3 class="font-bold text-lg mb-3 text-white">Riwayat Hari Ini</h3>
    <div class="space-y-4">
        @forelse($activities as $activity)
        <div class="bg-[#171a21] rounded-2xl shadow-lg border border-gray-800 p-4 relative overflow-hidden">
            <!-- Status Indicator Line -->
            <div class="absolute left-0 top-0 bottom-0 w-1 {{ $activity->status == 'deal' ? 'bg-emerald-500' : ($activity->status == 'failed' ? 'bg-red-500' : 'bg-amber-500') }}"></div>
            
            <div class="pl-3">
                <div class="flex justify-between items-start mb-2">
                    <div>
                        <h4 class="font-bold text-white text-base">{{ $activity->location_name }}</h4>
                        <p class="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                            <i class="bi bi-clock"></i> {{ $activity->created_at->format('H:i') }} WIB
                        </p>
                    </div>
                    <span class="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-lg 
                        {{ $activity->status == 'deal' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 
                          ($activity->status == 'failed' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20') }}">
                        {{ ucfirst($activity->status) }}
                    </span>
                </div>
                
                <p class="text-sm text-gray-400 leading-relaxed">{{ $activity->note }}</p>

                <!-- Action Buttons & Update Form -->
                <div class="mt-4 pt-3 border-t border-gray-800 flex flex-wrap gap-3" x-data="{ openUpdate: false }">
                    
                    {{-- Tombol Update Status (Hanya jika belum Deal/Failed) --}}
                    @if(!in_array($activity->status, ['deal', 'failed']))
                        <button @click="openUpdate = !openUpdate" class="text-[11px] font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1 bg-blue-500/5 px-3 py-1.5 rounded-lg border border-blue-500/10">
                            <i class="bi bi-pencil-square"></i> Update Status
                        </button>
                    @endif

                    {{-- Tombol Isi Form Pelanggan (Hanya tampil jika status sudah DEAL) --}}
                    @if($activity->status == 'deal')
                        <a href="{{ route('customers.create', ['activity_id' => $activity->id]) }}" class="text-[11px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 bg-emerald-500/5 px-3 py-1.5 rounded-lg border border-emerald-500/10">
                            <i class="bi bi-person-plus-fill"></i> Isi Form Pelanggan
                        </a>
                    @endif

                    {{-- Form Dropdown Update Status (Hidden by default) --}}
                    <div x-show="openUpdate" class="w-full mt-3" x-transition>
                        <form action="{{ route('sales-activities.update', $activity->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <select name="status" class="block w-full text-sm rounded-xl border-gray-700 bg-gray-900 text-white mb-2 focus:border-blue-500 focus:ring-blue-500/20" onchange="this.form.submit()">
                                <option value="promosi" {{ $activity->status == 'promosi' ? 'selected' : '' }}>Promosi</option>
                                <option value="penjajakan" {{ $activity->status == 'penjajakan' ? 'selected' : '' }}>Penjajakan</option>
                                <option value="deal">Deal (Daftar Pelanggan)</option>
                                <option value="failed">Gagal / Batal</option>
                            </select>
                            <textarea name="note" placeholder="Catatan tambahan..." class="block w-full text-sm rounded-xl border-gray-700 bg-gray-900 text-white mb-2 focus:border-blue-500 focus:ring-blue-500/20" rows="2">{{ $activity->note }}</textarea>
                            <button type="submit" class="w-full bg-blue-600 hover:bg-blue-500 text-white py-2 px-3 rounded-xl text-sm font-bold transition">Simpan Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        @empty
        <div class="text-center py-10">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800 text-gray-600 mb-3">
                <i class="bi bi-clipboard-x text-2xl"></i>
            </div>
            <p class="text-gray-500 text-sm">Belum ada aktivitas hari ini.</p>
        </div>
        @endforelse
    </div>
</div>

<script>
    function salesActivity() {
        return {
            lat: '',
            lng: '',
            loadingLocation: true,
            init() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        (position) => {
                            this.lat = position.coords.latitude;
                            this.lng = position.coords.longitude;
                            this.loadingLocation = false;
                        },
                        (error) => {
                            alert('Gagal mengambil lokasi. Pastikan GPS aktif.');
                            this.loadingLocation = false;
                        }
                    );
                } else {
                    alert('Browser tidak mendukung Geolocation.');
                }
            }
        }
    }
</script>
@endsection
