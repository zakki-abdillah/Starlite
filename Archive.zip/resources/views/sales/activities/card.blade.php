<div class="bg-[#171a21] rounded-2xl p-5 border border-gray-800 shadow-lg relative overflow-hidden mb-6">
    <div class="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full -mr-10 -mt-10 blur-2xl"></div>

    <div class="flex justify-between items-center mb-4 relative z-10">
        <div>
            <h3 class="font-bold text-white text-lg">Statistik Sales</h3>
            <p class="text-xs text-gray-400">Performa Anda</p>
        </div>
        <a href="{{ route('sales-activities.index') }}" class="w-8 h-8 flex items-center justify-center bg-blue-500/10 text-blue-400 rounded-full hover:bg-blue-500/20 transition">
            <i class="bi bi-arrow-right"></i>
        </a>
    </div>

    <div class="grid grid-cols-3 gap-3 mb-4 relative z-10">
        <div class="bg-gray-800/50 p-3 rounded-xl text-center border border-gray-700/50">
            <span class="block text-xl font-bold text-white">{{ $activities->count() }}</span>
            <span class="text-[10px] text-gray-400 font-bold uppercase">Hari Ini</span>
        </div>
        
        <div class="bg-emerald-500/10 p-3 rounded-xl text-center border border-emerald-500/20">
            <span class="block text-xl font-bold text-emerald-400">{{ $totalCustomers }}</span>
            <span class="text-[10px] text-emerald-400 font-bold uppercase">Pelanggan</span>
        </div>

        <div class="bg-blue-500/10 p-3 rounded-xl text-center border border-blue-500/20">
            <span class="block text-xl font-bold text-blue-400">{{ $monthlyVisits }}</span>
            <span class="text-[10px] text-blue-400 font-bold uppercase">Bulan Ini</span>
        </div>
    </div>

    <a href="{{ route('sales-activities.index') }}" class="relative z-10 flex items-center justify-center w-full bg-blue-600 text-white py-3 rounded-xl font-bold shadow-lg shadow-blue-900/30 hover:bg-blue-700 transition">
        <i class="bi bi-plus-lg mr-2"></i> Kunjungan Baru
    </a>
</div>