<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Illuminate\Support\Collection;

class CustomersExport implements FromCollection, WithHeadings, WithMapping
{
    protected $data;

    public function __construct(Collection $data)
    {
        $this->data = $data;
    }

    public function collection()
    {
        return $this->data;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Customer Name',
            'NIK',
            'No. HP',
            'Address',
            'Subscription Status',
            'Registered By (Sales)',
            'Created At',
        ];
    }

    public function map($customer): array
    {
        return [
            $customer->id,
            $customer->name,
            $customer->nik,
            $customer->no_hp,
            $customer->address,
            $customer->status_langganan,
            $customer->salesActivity->user->name ?? 'N/A',
            $customer->created_at->format('Y-m-d H:i:s'),
        ];
    }
}
