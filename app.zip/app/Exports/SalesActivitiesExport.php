<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Illuminate\Support\Collection;

class SalesActivitiesExport implements FromCollection, WithHeadings, WithMapping
{
    protected $data;

    public function __construct(Collection $data)
    {
        $this->data = $data;
    }

    public function collection()
    {
        return $this->data;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Sales Name',
            'Location Name',
            'Latitude',
            'Longitude',
            'Status',
            'Note',
            'Created At',
        ];
    }

    public function map($activity): array
    {
        return [
            $activity->id,
            $activity->user->name ?? 'N/A',
            $activity->location_name,
            $activity->latitude,
            $activity->longitude,
            $activity->status,
            $activity->note,
            $activity->created_at->format('Y-m-d H:i:s'),
        ];
    }
}
