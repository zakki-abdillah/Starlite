<?php

namespace App\Http\Controllers;

use App\Models\Installation;
use App\Models\InstallationTask;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Attendance;
use Carbon\Carbon;


class WaspangController extends Controller
{
    public function index()
    {
        $user = Auth::user();

       

        $installations = Installation::where('id_waspang', $user->id)
            ->latest()
            ->get();

        $todayAttendance = Attendance::where('user_id', $user->id)
            ->whereDate('created_at', Carbon::today())
            ->latest()
            ->first();
        
            foreach ($installations as $installation) {

        $complete = $installation->tasks->where('status', 'completed')->count();
        $total    = $installation->tasks->count();

        if ($total == 0) {
            $installation->progress = 0;
        } else {
            $installation->progress = round(($complete / $total) * 100, 2);
        }

    }


        return view('waspang', compact('installations', 'todayAttendance'));
    }

    public function show(Installation $installation)
    {
        if ($installation->id_waspang !== Auth::id()) {
            abort(403, 'ANDA TIDAK MEMILIKI AKSES KE TUGAS INI.');
        }

         $tasks = $installation->tasks()->get();

    $tasksByStage = $tasks->groupBy('stage');

    

    return view('waspang.installations.show', compact(
        'installation',
        'tasksByStage'
    ));
    }

    public function updateTask(Request $request, InstallationTask $task)
    {
        $wib = Carbon::now('Asia/Jakarta');
        if ($task->installation->id_waspang !== Auth::id()) {
            abort(403, 'ANDA TIDAK MEMILIKI AKSES UNTUK MENGUPDATE TUGAS INI.');
        }

        $request->validate([
            'file' => 'required|file|mimes:jpg,jpeg,png,pdf,doc,docx|max:10240',
            'notes' => 'nullable|string',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'details' => 'nullable|array',
        ]);

        $path = $request->file('file')->store('installation_files', 'public');

        $task->update([
            'status' => 'completed',
            'file_path' => $path,
            'latitude' => $request->input('latitude'),
            'longitude' => $request->input('longitude'),
            'notes' => $request->notes,
            'details' => $request->details,
            'completed_at' => $wib,
        ]);

        return back()->with('success', 'Pekerjaan "' . $task->task_name . '" berhasil diselesaikan.');
    }
}
