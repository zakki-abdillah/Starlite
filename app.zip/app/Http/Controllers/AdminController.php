<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class AdminController extends Controller
{
    /**
     * Display admin dashboard
     */
    public function dashboard()
    {
        $user = auth()->user();

        // Admin dashboard data - all user statistics
        $totalUsers = User::count();
        $totalAdmin = User::where('role', 'admin')->count();
        $totalTeknisi = User::where('role', 'teknisi')->count();
        $totalSales = User::where('role', 'sales')->count();

        return view('admin', compact('user', 'totalUsers', 'totalAdmin', 'totalTeknisi', 'totalSales'));
    }
}
