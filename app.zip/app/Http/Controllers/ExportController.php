<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\SalesActivity;
use App\Models\Attendance;
use App\Models\Customer;
use App\Models\Schedule;
use App\Exports\UsersExport;
use App\Exports\SalesActivitiesExport;
use App\Exports\AttendancesExport;
use App\Exports\CustomersExport;
use App\Exports\SchedulesExport;
use Barryvdh\DomPDF\Facade\Pdf;
use Maatwebsite\Excel\Facades\Excel;
use Carbon\Carbon;

class ExportController extends Controller
{

    public function reportCenter(Request $request)
    {
        $sales = User::where('role', 'sales')->select('id', 'name')->get();
        $technicians = User::where('role', 'teknisi')->select('id', 'name')->get();

        $data = collect([]);
        $headers = [];
        $reportType = $request->input('report_type');

        if ($reportType) {
            $query = $this->getReportQuery($request);
            $data = $query->latest()->get();

            switch ($reportType) {
                case 'attendances':
                    $headers = ['Waktu', 'Nama Karyawan', 'Tipe Absen', 'Koordinat'];
                    break;
                case 'sales-activities':
                    $headers = ['Tanggal', 'Nama Sales', 'Lokasi', 'Status', 'Catatan'];
                    break;
                case 'customers':
                    $headers = ['ID', 'Nama Pelanggan', 'NIK', 'No. HP', 'Sales'];
                    break;
                case 'schedules':
                    $headers = ['Tgl Jadwal', 'Judul', 'Customer', 'Team Leader', 'Status'];
                    break;
            }
        }

        return view('admin.reports.index', compact('sales', 'technicians', 'data', 'headers'));
    }


    public function export(Request $request, $type, $format)
    {
        $allowedTypes = ['users', 'sales-activities', 'attendances', 'customers'];
        $allowedFormats = ['pdf', 'xlsx'];

        if (!in_array($type, $allowedTypes) || !in_array($format, $allowedFormats)) {
            abort(404, 'Tipe atau format export tidak valid.');
        }

        $filename = $type . '-' . Carbon::now()->format('Y-m-d') . '.' . $format;

        $data = null;
        $exportClass = null;
        $pdfViewData = [];

        switch ($type) {
            case 'users':
                $data = User::all();
                $exportClass = new UsersExport($data);
                $pdfViewData = [
                    'title' => 'Laporan Data Pengguna',
                    'headers' => ['ID', 'Nama', 'Email', 'Role', 'Tanggal Bergabung'],
                    'columns' => [
                        'id',
                        'name',
                        'email',
                        function($item) { return ucfirst($item->role); },
                        function($item) { return $item->created_at->format('d-m-Y'); }
                    ],
                ];
                break;
            case 'sales-activities':
                $data = SalesActivity::with('user')->latest()->get();
                $exportClass = new SalesActivitiesExport($data);
                $pdfViewData = [
                    'title' => 'Laporan Aktivitas Sales',
                    'headers' => ['Tanggal', 'Nama Sales', 'Lokasi', 'Status', 'Catatan'],
                    'columns' => [
                        function($item) { return $item->created_at->format('d-m-Y H:i'); },
                        'user.name',
                        'location_name',
                        function($item) { return ucfirst($item->status); },
                        'note',
                    ],
                ];
                break;
            case 'attendances':
                $data = Attendance::with('user')->latest()->get();
                $exportClass = new AttendancesExport($data);
                $pdfViewData = [
                    'title' => 'Laporan Absensi Karyawan',
                    'headers' => ['Waktu', 'Nama Karyawan', 'Tipe Absen', 'Koordinat'],
                    'columns' => [
                        function($item) { return $item->created_at->format('d-m-Y H:i'); },
                        'user.name',
                        function($item) { return $item->type === 'clock_in' ? 'Masuk' : 'Keluar'; },
                        function($item) { return "{$item->latitude}, {$item->longitude}"; },
                    ],
                ];
                break;
            case 'customers':
                $data = Customer::with('salesActivity.user')->latest()->get();
                $exportClass = new CustomersExport($data);
                $pdfViewData = [
                    'title' => 'Laporan Data Pelanggan',
                    'headers' => ['ID', 'Nama Pelanggan', 'NIK', 'No. HP', 'Alamat', 'Status', 'Sales'],
                    'columns' => [
                        'id', 'name', 'nik', 'no_hp', 'address', 'status_langganan', 'salesActivity.user.name'
                    ],
                ];
                break;
            default:
                return redirect()->back()->with('error', 'Tipe export tidak ditemukan.');
        }

        if ($format === 'pdf') {
            $pdf = Pdf::loadView('admin.exports.template_pdf', array_merge($pdfViewData, ['data' => $data]))
                      ->setPaper('a4', 'landscape');
            return $pdf->download($filename);
        }

        if ($format === 'xlsx') {
            return Excel::download($exportClass, $filename);
        }
    }

    public function generateReport(Request $request)
    {
        $request->validate([
            'report_type' => 'required|in:attendances,sales-activities,customers,schedules',
            'format' => 'required|in:pdf,xlsx',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'user_ids' => 'nullable|array',
            'user_ids.*' => 'exists:users,id',
        ]);

        $type = $request->input('report_type');
        $format = $request->input('format');
        $filename = "report-{$type}-" . Carbon::now()->format('Y-m-d') . ".{$format}";

        $query = $this->getReportQuery($request);
        $pdfViewData = [];

        switch ($type) {
            case 'attendances':
                $pdfViewData = [
                    'title' => 'Laporan Absensi Karyawan',
                    'headers' => ['Waktu', 'Nama Karyawan', 'Tipe Absen', 'Koordinat'],
                    'columns' => [
                        fn($item) => $item->created_at->format('d-m-Y H:i'),
                        'user.name',
                        fn($item) => $item->type === 'clock_in' ? 'Masuk' : 'Keluar',
                        fn($item) => "{$item->latitude}, {$item->longitude}",
                    ],
                ];
                break;

            case 'sales-activities':
                $pdfViewData = [
                    'title' => 'Laporan Aktivitas Sales',
                    'headers' => ['Tanggal', 'Nama Sales', 'Lokasi', 'Status', 'Catatan'],
                    'columns' => [
                        fn($item) => $item->created_at->format('d-m-Y H:i'),
                        'user.name', 'location_name',
                        fn($item) => ucfirst($item->status),
                        'note',
                    ],
                ];
                break;

            case 'customers':
                $pdfViewData = [
                    'title' => 'Laporan Data Pelanggan',
                    'headers' => ['ID', 'Nama Pelanggan', 'NIK', 'No. HP', 'Sales'],
                    'columns' => ['id', 'name', 'nik', 'no_hp', 'salesActivity.user.name'],
                ];
                break;
            
            case 'schedules':
                 $pdfViewData = [
                    'title' => 'Laporan Jadwal Teknisi',
                    'headers' => ['Tgl Jadwal', 'Judul', 'Customer', 'Team Leader', 'Status'],
                    'columns' => [
                        fn($item) => Carbon::parse($item->scheduled_at)->format('d-m-Y'),
                        'title', 'customer.name', 'teamLeader.name', 'status'
                    ],
                ];
                break;
        }

        $data = $query->latest()->get();
        if ($format === 'pdf') {
            $pdf = Pdf::loadView('admin.exports.template_pdf', array_merge($pdfViewData, ['data' => $data]))
                      ->setPaper('a4', 'landscape');
            return $pdf->download($filename);
        }

        if ($format === 'xlsx') {
            $exportClass = null;
            switch ($type) {
                case 'users': $exportClass = new UsersExport($data); break;
                case 'sales-activities': $exportClass = new SalesActivitiesExport($data); break;
                case 'attendances': $exportClass = new AttendancesExport($data); break;
                case 'customers': $exportClass = new CustomersExport($data); break;
                case 'schedules': $exportClass = new SchedulesExport($data); break;
            }
            
            if (!$exportClass) {
                return redirect()->back()->with('error', 'Format export tidak didukung untuk tipe ini.');
            }

            return Excel::download($exportClass, $filename);
        }
    }

    private function getReportQuery(Request $request)
    {
        $type = $request->input('report_type');
        $query = null;

        switch ($type) {
            case 'attendances':
                $query = Attendance::query()->with('user');
                if ($request->filled('user_ids')) $query->whereIn('user_id', $request->user_ids);
                break;
            case 'sales-activities':
                $query = SalesActivity::query()->with('user');
                if ($request->filled('user_ids')) $query->whereIn('user_id', $request->user_ids);
                break;
            case 'customers':
                $query = Customer::query()->with('salesActivity.user');
                if ($request->filled('user_ids')) {
                    $query->whereHas('salesActivity', function ($q) use ($request) {
                        $q->whereIn('user_id', $request->user_ids);
                    });
                }
                break;
            case 'schedules':
                $query = Schedule::query()->with(['customer', 'teamLeader']);
                if ($request->filled('user_ids')) {
                    $query->whereHas('technicians', function ($q) use ($request) {
                        $q->whereIn('users.id', $request->user_ids);
                    });
                }
                break;
        }

        if ($query && $request->filled('start_date') && $request->filled('end_date')) {
            $query->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }

        return $query;
    }
}
