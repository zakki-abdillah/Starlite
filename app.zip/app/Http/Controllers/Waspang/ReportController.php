<?php

namespace App\Http\Controllers\Waspang;

use App\Http\Controllers\Controller;
use App\Models\Installation;
use App\Models\InstallationTask;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ReportController extends Controller
{
    public function index()
    {
        $projects = Installation::select('id','title')->get();
        return view('waspang.report.index', compact('projects'));
    }

    public function getData(Request $request)
    {
        $projectId = $request->project_id;

        // =========================
        // TABLE
        // =========================
        $installations = Installation::with('tasks');

        if (!empty($projectId)) {
            $installations->where('id',$projectId);
        }

        $table = $installations->get()->map(function ($item){

            $tasks = $item->tasks;

            $target = min($tasks->count(),24);
            $completed = min($tasks->where('status','completed')->count(),24);

            return [
                'name'=>$item->title,
                'target'=>$target,
                'completed'=>$completed,
                'progress'=>$target>0 ? round(($completed/$target)*100,2):0
            ];
        });

        // =========================
        // TASK QUERY
        // =========================
        $taskQuery = InstallationTask::query();

        if (!empty($projectId)) {
            $taskQuery->where('installation_id',$projectId);
        }

        // =========================
        // DAILY
        // =========================
        $daily = collect(range(0,6))->map(function($i) use($taskQuery){

            $date = now()->subDays($i);

            return [
                'label'=>$date->format('d M'),
                'value'=>(clone $taskQuery)
                    ->whereDate('completed_at',$date)
                    ->count()
            ];
        })->reverse()->values();

        // =========================
        // WEEKLY
        // =========================
        $weekly = collect(range(0,3))->map(function($i) use($taskQuery){

            $start = now()->subWeeks($i)->startOfWeek();
            $end   = now()->subWeeks($i)->endOfWeek();

            return [
                'label'=>'W'.$start->format('W'),
                'value'=>(clone $taskQuery)
                    ->whereBetween('completed_at',[$start,$end])
                    ->count()
            ];
        })->reverse()->values();

        // =========================
        // MONTHLY
        // =========================
        $monthly = collect(range(0,5))->map(function($i) use($taskQuery){

            $date = now()->subMonths($i);

            return [
                'label'=>$date->format('M'),
                'value'=>(clone $taskQuery)
                    ->whereMonth('completed_at',$date->month)
                    ->whereYear('completed_at',$date->year)
                    ->count()
            ];
        })->reverse()->values();

        return response()->json([
            'table'=>$table,
            'daily'=>$daily,
            'weekly'=>$weekly,
            'monthly'=>$monthly
        ]);
    }
}