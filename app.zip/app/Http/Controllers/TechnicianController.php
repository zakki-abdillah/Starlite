<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Schedule;
use App\Models\Attendance;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class TechnicianController extends Controller
{
    /**
     * Dashboard Teknisi: Menampilkan jadwal tugas & absensi
     */
    public function index()
    {
        $user = Auth::user();

        $schedules = Schedule::whereHas('technicians', function($q) use ($user) {
                $q->where('users.id', $user->id);
            })
            ->with(['customer', 'technicians'])
            ->orderBy('scheduled_at', 'asc')
            ->get();

        $todayAttendance = Attendance::where('user_id', $user->id)
            ->whereDate('created_at', Carbon::today())
            ->latest()
            ->first();

        return view('teknisi', compact('schedules', 'todayAttendance'));
    }

    /**
     * Menampilkan halaman detail untuk sebuah jadwal.
     */
    public function show(Schedule $schedule)
    {
        // Pastikan teknisi yang login adalah bagian dari tim untuk jadwal ini
        if (!$schedule->technicians->contains(Auth::id())) {
            abort(403, 'Anda tidak memiliki akses ke jadwal ini.');
        }

        $schedule->load(['customer', 'technicians']);

        return view('schedules.show', compact('schedule'));
    }

    /**
     * Update Status Pekerjaan (oleh Team Leader)
     */
    public function update(Request $request, Schedule $schedule)
    {
        // Pastikan hanya team leader yang bisa update
        if ($schedule->team_leader_id !== Auth::id()) {
            return back()->with('error', 'Hanya team leader yang dapat mengubah status pekerjaan.');
        }

        $request->validate([
            'status' => 'required|in:pending,in_progress,completed,on_hold,canceled',
            'hold_reason' => 'required_if:status,on_hold,canceled|nullable|string',
        ]);

        $data = [
            'status' => $request->status,
            'hold_reason' => in_array($request->status, ['on_hold', 'canceled']) ? $request->hold_reason : null,
        ];

        // Otomatis isi jam mulai jika status berubah ke In Progress
        if ($request->status == 'in_progress' && !$schedule->start_at) {
            $data['start_at'] = now();
        }
        
        // Otomatis isi jam selesai jika status berubah ke Completed
        if ($request->status == 'completed' && !$schedule->end_at) {
            $data['end_at'] = now();
        }

        $schedule->update($data);

        return redirect()->route('technician.schedules.show', $schedule->id)
                         ->with('success', 'Status pekerjaan berhasil diperbarui.');
    }
}