<?php

namespace App\Http\Controllers;

use App\Models\SalesActivity;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class SalesActivityController extends Controller
{

    public function index()
    {
        $user = Auth::user();
        if ($user->role === 'admin') {
            $activities = SalesActivity::with('user')->latest()->get();
        } else {
            $activities = SalesActivity::where('user_id', $user->id)->latest()->get();
        }

        return view('sales.activities.index', compact('activities'));
    }

    /**
     * Check-in System: Sales membuat log baru di lokasi
     */
    public function store(Request $request)
    {
        $request->validate([
            'location_name' => 'required|string|max:255',
            'latitude'      => 'required|numeric',
            'longitude'     => 'required|numeric',
            'photo'         => 'nullable|image|max:5120',
        ]);

        $path = null;
        if ($request->hasFile('photo')) {
            $path = $request->file('photo')->store('sales_activities', 'public');
        }

        SalesActivity::create([
            'user_id'        => Auth::id(),
            'location_name'  => $request->location_name,
            'latitude'       => $request->latitude,
            'longitude'      => $request->longitude,
            'photo_evidence' => $path,
            'status'         => 'promosi',
            'note'           => 'Check-in lokasi',
        ]);

        return redirect()->back()->with('success', 'Check-in berhasil! Aktivitas dimulai.');
    }


    public function update(Request $request, SalesActivity $salesActivity)
    {

        if ($salesActivity->user_id !== Auth::id() && Auth::user()->role !== 'admin') {
            abort(403, 'Unauthorized action.');
        }

        $request->validate([
            'status' => 'required|in:promosi,penjajakan,deal,failed',
            'note'   => 'nullable|string',
        ]);

        $salesActivity->update([
            'status' => $request->status,
            'note'   => $request->note ?? $salesActivity->note,
        ]);

        if ($request->status === 'deal') {
            return redirect()->route('customers.create', ['activity_id' => $salesActivity->id])
                             ->with('success', 'Status Deal! Silakan lengkapi data pelanggan.');
        }

        return redirect()->back()->with('success', 'Status aktivitas diperbarui.');
    }
}
