<?php


namespace App\Http\Controllers;

use App\Models\Attendance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class AttendanceController extends Controller
{
    public function index()
    {
        $attendances = Attendance::with('user')->latest()->get();
        return view('admin.attendance.index', compact('attendances'));
    }

    public function history()
    {
        $user_id = Auth::id();
        $attendances = Attendance::where('user_id', $user_id)->latest()->get();
        $todayAttendance = Attendance::where('user_id', $user_id)
            ->whereDate('created_at', \Carbon\Carbon::today())
            ->latest()
            ->first();
        return view('attendances.index', compact('attendances', 'todayAttendance'));
    }

    public function create()
    {
        $last_attendance = Attendance::where('user_id', Auth::id())->latest()->first();
        $attendance_type = 'clock_in';

        if ($last_attendance && $last_attendance->type === 'clock_in') {
            $attendance_type = 'clock_out';
        }

        return view('attendances.attendance_create', ['type' => $attendance_type]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'type' => 'required|in:clock_in,clock_out',
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
            'photo' => 'required|image|max:5120',
        ]);

        $path = $request->file('photo')->store('attendances', 'public');

        Attendance::create([
            'user_id' => Auth::id(),
            'type' => $request->type,
            'photo_path' => $path,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
        ]);

        $message = $request->type === 'clock_in' ? 'Absen masuk berhasil!' : 'Absen keluar berhasil!';

        // Redirect sesuai role
        $role = Auth::user()->role;
        if ($role === 'teknisi') {
            return redirect()->route('teknisi.dashboard')->with('success', $message);
        } elseif ($role === 'sales') {
            return redirect()->route('sales.dashboard')->with('success', $message);
        }

        return redirect()->route('dashboard')->with('success', $message);
    }
}