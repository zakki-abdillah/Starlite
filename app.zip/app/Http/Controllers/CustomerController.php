<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\SalesActivity;
use Illuminate\Support\Facades\Auth;

class CustomerController extends Controller
{
    /**
     * (Admin View)
     */
    public function index()
    {
        $customers = Customer::with('salesActivity.user')->latest()->get();
        if (Auth::user()->role !== 'admin') {
        }

        return view('admin.customer_data.index', compact('customers'));
    }

    public function create(Request $request)
    {
        $activity = null;
        if ($request->has('activity_id')) {
            $activity = SalesActivity::find($request->activity_id);
        }

        return view('customers.create', compact('activity'));
    }

    /**
     * Menyimpan data customer baru.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'nik' => 'required|numeric',
            'no_hp' => 'required|string',
            'address' => 'required|string',
            'photo' => 'required|image|max:5120',
            'activity_id' => 'nullable|exists:sales_activities,id',
        ]);

        $path = $request->file('photo')->store('customers', 'public');

        Customer::create([
            'activity_id' => $request->activity_id,
            'name' => $request->name,
            'nik' => $request->nik,
            'no_hp' => $request->no_hp,
            'address' => $request->address,
            'photo_path' => $path,
            'status_langganan' => 'New',
        ]);

        return redirect()->route('sales.dashboard')->with('success', 'Pelanggan berhasil didaftarkan!');
    }
}
