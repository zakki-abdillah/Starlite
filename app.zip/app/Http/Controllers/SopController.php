<?php

namespace App\Http\Controllers;

use App\Models\Sop;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SopController extends Controller
{
    /**
     * Display a listing of the SOPs for admin.
     */
    public function index()
    {
        $sops = Sop::latest()->get();
        return view('admin.sop.index', compact('sops'));
    }

    /**
     * Show the form for creating a new SOP.
     */
    public function create()
    {
        return view('admin.sop.create');
    }

    /**
     * Store a newly created SOP in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'role' => 'required|in:teknisi,sales,waspang',
        ]);

        Sop::create($request->all());

        return redirect()->route('admin.sop.index')->with('success', 'SOP berhasil dibuat.');
    }

    /**
     * Show the form for editing the specified SOP.
     */
    public function edit(Sop $sop)
    {
        return view('admin.sop.edit', compact('sop'));
    }

    /**
     * Update the specified SOP in storage.
     */
    public function update(Request $request, Sop $sop)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'role' => 'required|in:teknisi,sales,waspang',
        ]);

        $sop->update($request->all());

        return redirect()->route('admin.sop.index')->with('success', 'SOP berhasil diperbarui.');
    }

    /**
     * Remove the specified SOP from storage.
     */
    public function destroy(Sop $sop)
    {
        $sop->delete();
        return redirect()->route('admin.sop.index')->with('success', 'SOP berhasil dihapus.');
    }

    /**
     * Show SOPs for the authenticated user (teknisi/sales).
     */
    public function showForUser()
    {
        $user = Auth::user();
        if ($user->role === 'admin') {
            $sops = Sop::latest()->get();
        } else {
            $sops = Sop::where('role', $user->role)->latest()->get();
        }
        return view('sop.index', compact('sops'));
    }
}
