<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SalesActivity;
use App\Models\Attendance;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class SalesController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        $todayAttendance = Attendance::where('user_id', $user->id)
            ->whereDate('created_at', Carbon::today())
            ->latest()
            ->first();

        $activities = SalesActivity::where('user_id', $user->id)
            ->whereDate('created_at', Carbon::today())
            ->latest()
            ->get();

        $totalCustomers = SalesActivity::where('user_id', $user->id)
            ->where('status', 'deal')
            ->count();

        $monthlyVisits = SalesActivity::where('user_id', $user->id)
            ->whereMonth('created_at', Carbon::now()->month)
            ->count();

        return view('sales', compact('todayAttendance', 'activities', 'totalCustomers', 'monthlyVisits'));
    }
}