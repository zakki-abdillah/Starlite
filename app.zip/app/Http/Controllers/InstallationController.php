<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Installation;
use App\Models\User;
use App\Models\InstallationTask;
use App\Models\InstallationDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class InstallationController extends Controller
{
    public function index()
    {
        $installations = Installation::with(['waspang'])->latest()->get();
        $waspangs = User::where('role', 'waspang')->latest()->get();
        foreach ($installations as $installation) {

        $complete = $installation->tasks->where('status', 'completed')->count();
        $total    = $installation->tasks->count();

        if ($total == 0) {
            $installation->progress = 0;
        } else {
            $installation->progress = round(($complete / $total) * 100, 2);
        }

         }

        return view('admin.installations.index', compact('installations', 'waspangs'));
    }

    public function create()
    {
        $waspangs = User::where('role', 'waspang')->latest()->get();
        return view('admin.installations.create', compact('waspangs'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'no_po' => 'required|string|max:255',
            'target' => 'required|numeric',
            'realisasi' => 'required|numeric',
            'description' => 'nullable|string',
            'id_waspang' => 'required|exists:users,id',
            'coordinates' => 'required|array|min:1',
            'coordinates.*.latitude' => 'required|numeric',
            'coordinates.*.longitude' => 'required|numeric',
            'coordinates.*.description' => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $installationData = $request->only(['title', 'description', 'id_waspang', 'no_po', 'target', 'realisasi']);
            $installationData['admin_id'] = Auth::id();
            $installationData['status'] = 'pending';
            $installationData['job_code'] = 'JOB-' . time();

            $installation = Installation::create($installationData);
            $installation->coordinates()->createMany($request->coordinates);
            $this->generateStandardTasks($installation->id);

            DB::commit();

            return redirect()->route('admin.installations.index')->with('success', 'Jadwal instalasi berhasil dibuat.');
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('Error creating installation: ' . $e->getMessage());
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage())->withInput();
        }
    }

    private function generateStandardTasks(int $installationId): void
    {
        $tasks = [
            // Tahap 1: Prepare Work
            ['stage' => 'prepare_work', 'task_group' => 'Permit Community', 'task_name' => 'Sosialisasi Warga'],
            ['stage' => 'prepare_work', 'task_group' => 'Permit Community', 'task_name' => 'Perjanjian Kerjasama'],
            ['stage' => 'prepare_work', 'task_group' => 'Survey and Design', 'task_name' => 'Pengajuan Boundery'],
            ['stage' => 'prepare_work', 'task_group' => 'Survey and Design', 'task_name' => 'Survey Design'],
            ['stage' => 'prepare_work', 'task_group' => 'Survey and Design', 'task_name' => 'Design Review'],
            // Tahap 2: Civil Work
            ['stage' => 'civil_work', 'task_group' => 'Pole', 'task_name' => 'Digging & Kedalaman'],
            ['stage' => 'civil_work', 'task_group' => 'Pole', 'task_name' => 'Erection'],
            ['stage' => 'civil_work', 'task_group' => 'Pole', 'task_name' => 'Cor Tiang'],
            ['stage' => 'civil_work', 'task_group' => 'Pole', 'task_name' => 'Label Tiang'],
            ['stage' => 'civil_work', 'task_group' => 'Pemasangan X-Frame', 'task_name' => 'Instalasi X-Frame Feeder'],
            ['stage' => 'civil_work', 'task_group' => 'Pemasangan X-Frame', 'task_name' => 'Instalasi X-Frame Distribusi'],
            ['stage' => 'civil_work', 'task_group' => 'Instal ODP', 'task_name' => 'Pemasangan ODP'],
            ['stage' => 'civil_work', 'task_group' => 'Aksesoris KU Distribusi', 'task_name' => 'Clamp Ring'],
            ['stage' => 'civil_work', 'task_group' => 'Aksesoris KU Distribusi', 'task_name' => 'Clamp S'],
            ['stage' => 'civil_work', 'task_group' => 'Aksesoris KU Feeder', 'task_name' => 'Clamp A'],
            ['stage' => 'civil_work', 'task_group' => 'Aksesoris KU Feeder', 'task_name' => 'Dead End'],
            ['stage' => 'civil_work', 'task_group' => 'Pulling Precon', 'task_name' => 'Pulling Precon 50'],
            ['stage' => 'civil_work', 'task_group' => 'Pulling Precon', 'task_name' => 'Pulling Precon 100'],
            ['stage' => 'civil_work', 'task_group' => 'Pulling Precon', 'task_name' => 'Pulling Precon 150'],
            ['stage' => 'civil_work', 'task_group' => 'Pemeriksaan Precon', 'task_name' => 'Pemeriksaan Precon 50'],
            ['stage' => 'civil_work', 'task_group' => 'Pemeriksaan Precon', 'task_name' => 'Pemeriksaan Precon 100'],
            ['stage' => 'civil_work', 'task_group' => 'Pemeriksaan Precon', 'task_name' => 'Pemeriksaan Precon 150'],
            // Tahap 3: Electrical Work
            ['stage' => 'electrical_work', 'task_group' => 'Electrical Work', 'task_name' => 'Splicing Core'],
            ['stage' => 'electrical_work', 'task_group' => 'Electrical Work', 'task_name' => 'Testing Sinyal'],
        ];

        $tasksToInsert = [];
        foreach ($tasks as $task) {
            $tasksToInsert[] = array_merge($task, [
                'installation_id' => $installationId,
                'created_at' => now(), 'updated_at' => now()
            ]);
        }
        
        InstallationTask::insert($tasksToInsert);
    }

    public function show(Installation $installation)
    {
        $installation->load(['waspang', 'coordinates', 'task']);
        
        $progress = [
            'prepare' => 0,
            'civil' => 0,
            'electrical' => 0,
        ];

        return view('admin.installations.show', compact('installation', 'progress'));
    }

    public function updateItem(Request $request, $itemId)
    {
        $request->validate([
            'photo' => 'required|image|max:5120',
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
        ]);

        // $task = InstallationTask::findOrFail($itemId);
        // $installation = $task->installation;

        // Cek Locking Stage
        // if ($installation->isStageLocked($task->stage)) {
        //     return back()->with('error', 'Tahap ini terkunci karena tahap sebelumnya belum selesai.');
        // }

        // Upload Foto
        $path = $request->file('photo')->store('installation_evidence', 'public');
        return back()->with('success', 'Bukti pekerjaan berhasil diupload.');
    }

    

     public function edit(Installation $installation)
    {
        $installation->load('coordinates'); 
        $waspangs = User::where('role', 'waspang')->latest()->get();
        return view('admin.installations.edit', compact('installation', 'waspangs'));
    }


    public function update(Request $request, Installation $installation)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'status' => 'required|in:pending,in_progress,completed,on_hold,canceled',
            'id_waspang' => 'required|exists:users,id',
            'no_po' => 'required|string|max:255',
            'target' => 'required|numeric',
           'realisasi' => 'required|numeric',
           'coordinates' => 'required|array|min:1',
            'coordinates.*.latitude' => 'required|numeric',
            'coordinates.*.longitude' => 'required|numeric',
            'coordinates.*.description' => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $installation->update($request->only(['title', 'status', 'id_waspang', 'no_po', 'target', 'realisasi', 'description']));
            // Logika untuk update coordinates
            $installation->coordinates()->delete();
            $installation->coordinates()->createMany($request->coordinates);

            DB::commit();
            return redirect()->route('admin.installations.index')->with('success', 'Jadwal instalasi berhasil diperbarui.');
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('Error updating installation: ' . $e->getMessage());
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage())->withInput();
        }
    }

    public function destroy(Installation $installation)
    {
        $installation->delete();
        return redirect()->route('admin.installations.index')->with('success', 'Jadwal instalasi berhasil dihapus.');
    }
}
