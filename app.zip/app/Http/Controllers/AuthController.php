<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\LoginHistory;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $credentials = $request->only('email', 'password');
        $remember = $request->boolean('remember');

        if (Auth::attempt($credentials, $remember)) {
            $request->session()->regenerate();

            $user = Auth::user();

            if ($user->role === 'admin') {
                return redirect()->intended('/admin');
            } elseif ($user->role === 'teknisi') {
                return redirect()->intended('/teknisi');
            } elseif ($user->role === 'sales') {
                return redirect()->intended('/sales');
            } elseif ($user->role === 'waspang') {
                return redirect()->intended('/waspang');
            }

            return redirect()->intended('/dashboard');
        }

        return back()->withErrors([
            'email' => 'email atau password salah',
        ])->onlyInput('email');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }

    /**
     * Redirect user to their respective dashboard based on role.
     */
    public function redirectDashboard()
    {
        $role = Auth::user()->role;

        if ($role === 'admin') {
            return redirect()->route('admin.dashboard');
        } elseif ($role === 'teknisi') {
            return redirect()->route('teknisi.dashboard');
        } elseif ($role === 'sales') {
            return redirect()->route('sales.dashboard');
        } elseif ($role === 'waspang') {
            return redirect()->route('waspang.dashboard');
        }

        return redirect('/login');
    }
}
