@extends('layouts.app')

@section('content')
<div class="bg-white rounded-lg shadow-lg p-6">
    <div class="mb-6">
        <h2 class="text-2xl font-bold text-gray-800">Tugas Instalasi Anda</h2>
        <p class="text-gray-600 text-sm">Berikut adalah daftar pekerjaan yang ditugaskan kepada Anda.</p>
    </div>

    @if($installations->isEmpty())
        <div class="text-center py-10 border-2 border-dashed rounded-lg">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 text-gray-400 mb-3">
                <i class="bi bi-clipboard-check text-2xl"></i>
            </div>
            <p class="text-gray-500 font-medium">Tidak ada tugas untuk saat ini.</p>
        </div>
    @else
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($installations as $installation)
            <div class="border rounded-lg shadow-sm bg-white hover:shadow-md transition-shadow duration-300">
                <div class="p-5">
                    <h3 class="text-lg font-bold text-gray-800 truncate" title="{{ $installation->title }}">
                        {{ $installation->title }}
                    </h3>
                    <p class="text-xs text-gray-500 mb-4">{{ $installation->job_code }}</p>
                </div>
                <div class="px-5 py-3 bg-gray-50 border-t flex justify-end">
                    {{-- Tombol ini bisa diarahkan ke route yang menampilkan KMZ atau detail pekerjaan --}}
                    <a href="{{ route('admin.installations.show', $installation->id) }}" class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg shadow-md hover:bg-blue-700 transition">
                        KMZ Viewport
                    </a>
                </div>
            </div>
            @endforeach
        </div>
    @endif
</div>
@endsection
