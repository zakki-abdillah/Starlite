<?php

namespace App\Http\Controllers;

use App\Models\Schedule;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ScheduleController extends Controller
{
    /**
     * 
     */
    public function index()
    {
        $schedules = Schedule::with(['customer', 'technicians', 'admin', 'teamLeader'])->latest()->get();
        $customers = Customer::latest()->get();
        $technicians = User::where('role', 'teknisi')->get();
        return view('admin.schedules.index', compact('schedules', 'customers', 'technicians'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'customer_id' => 'required|exists:customer,id',
            'technician_ids' => 'required|array|min:1',
            'technician_ids.*' => 'required|exists:users,id',
            'team_leader_id' => 'required|exists:users,id',
            'title' => 'required|string|max:255',
            'task_type' => 'required|in:pemasangan,maintenance,perbaikan',
            'scheduled_at' => 'required|date',
            'work_note' => 'nullable|string',
        ]);

        if (!in_array($request->team_leader_id, $request->technician_ids)) {
            return back()->with('error', 'Team leader harus merupakan salah satu teknisi yang dipilih.')->withInput();
        }

        $customer = Customer::with('salesActivity')->find($request->customer_id);

        $scheduleData = $request->except('technician_ids');
        $scheduleData['admin_id'] = Auth::id();
        $scheduleData['status'] = 'pending';

        if ($customer && $customer->salesActivity) {
            $scheduleData['latitude'] = $customer->salesActivity->latitude;
            $scheduleData['longitude'] = $customer->salesActivity->longitude;
        }

        $schedule = Schedule::create($scheduleData);
        $schedule->technicians()->attach($request->technician_ids);

        if (isset($scheduleData['latitude'])) {
            return redirect()->route('admin.schedules.index')->with('success', 'Jadwal berhasil dibuat.');
        }
        return redirect()->route('admin.schedules.index')->with('warning', 'Jadwal berhasil dibuat, namun koordinat lokasi tidak dapat ditambahkan karena data aktivitas sales tidak ditemukan.');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Schedule $schedule)
    {
        $schedule->load('technicians');
        return response()->json($schedule);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Schedule $schedule)
    {
        $request->validate([
            'customer_id' => 'required|exists:customer,id',
            'technician_ids' => 'required|array|min:1',
            'technician_ids.*' => 'required|exists:users,id',
            'team_leader_id' => 'required|exists:users,id',
            'title' => 'required|string|max:255',
            'task_type' => 'required|in:pemasangan,maintenance,perbaikan',
            'scheduled_at' => 'required|date',
            'status' => 'required|in:pending,in_progress,on_hold,completed,canceled',
            'work_note' => 'nullable|string',
        ]);

        // Pastikan team leader ada di dalam tim yang dipilih
        if (!in_array($request->team_leader_id, $request->technician_ids)) {
            return back()->with('error', 'Team leader harus merupakan salah satu teknisi yang dipilih.')->withInput();
        }

        $customer = Customer::with('salesActivity')->find($request->customer_id);
        if ($customer && $customer->salesActivity) {
            $scheduleData = $request->except(['technician_ids', '_token', '_method']);
            $scheduleData['latitude'] = $customer->salesActivity->latitude;
            $scheduleData['longitude'] = $customer->salesActivity->longitude;

            $schedule->update($scheduleData);
            $schedule->technicians()->sync($request->technician_ids);

            return redirect()->route('admin.schedules.index')->with('success', 'Jadwal berhasil diperbarui.');
        }

        // Fallback or error if customer/sales activity is gone
        $schedule->update($request->except(['technician_ids', '_token', '_method']));
        $schedule->technicians()->sync($request->technician_ids);
        return redirect()->route('admin.schedules.index')->with('warning', 'Jadwal diperbarui, namun data koordinat tidak dapat diperbarui karena aktivitas sales tidak ditemukan.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Schedule $schedule)
    {
        $schedule->delete();
        return redirect()->route('admin.schedules.index')->with('success', 'Jadwal berhasil dihapus.');
    }
}
