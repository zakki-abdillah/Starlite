<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;

    protected $table = 'customer';

    protected $fillable = [
        'activity_id',
        'name',
        'address',
        'nik',
        'photo_path',
        'no_hp',
        'status_langganan',
    ];

    public function salesActivity()
    {
        return $this->belongsTo(SalesActivity::class, 'activity_id');
    }
}
