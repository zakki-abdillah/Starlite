<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InstallationTask extends Model
{
    use HasFactory;

    protected $fillable = [
        'installation_id',
        'stage',
        'task_group',
        'task_name',
        'status',
        'file_path',
        'latitude',
        'longitude',
        'notes',
        'details',
        'completed_at',
    ];

    protected $casts = [
        'completed_at' => 'datetime',
        'details' => 'array',
    ];

    public function installation()
    {
        return $this->belongsTo(Installation::class);
    }
    
    public function getProgress($installation_id)
    {
    $complete = \DB::table('installation_tasks')
        ->where('installation_id', $installation_id)
        ->where('status', 'complete')
        ->count();

    $pending = \DB::table('installation_tasks')
        ->where('installation_id', $installation_id)
        ->where('status', 'pending')
        ->count();

        if ($pending == 0) {
            return 100;
        }

    return round(($complete / $pending) * 100, 2);
    }
}
