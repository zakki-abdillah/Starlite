<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InstallationCoordinate extends Model
{
    protected $table = 'installation_coordinates';

    public $timestamps = false;

    protected $fillable = [
        'installation_id',
        'latitude',
        'longitude',
        'description',
    ];

    public function installation()
    {
        return $this->belongsTo(Installation::class, 'installation_id');
    }
}
