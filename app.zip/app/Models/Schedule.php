<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Schedule extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id',
        'admin_id',
        'team_leader_id',
        'title',
        'task_type',
        'work_note',
        'scheduled_at',
        'start_at',
        'latitude',
        'longitude',
        'end_at',
        'status',
        'hold_reason',
    ];

    protected $casts = [
        'scheduled_at' => 'datetime',
        'start_at' => 'datetime',
        'end_at' => 'datetime',
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id');
    }

    public function admin()
    {
        return $this->belongsTo(User::class, 'admin_id');
    }

    public function technicians()
    {
        return $this->belongsToMany(User::class, 'schedule_technician', 'schedule_id', 'technician_id');
    }

    public function teamLeader()
    {
        return $this->belongsTo(User::class, 'team_leader_id');
    }
}
