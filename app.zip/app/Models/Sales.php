<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sales extends Model
{
    protected $table = 'sales';

    protected $fillable = [
        'user_id',
        'name',
        'nik',
        'no_hp',
        'address',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
