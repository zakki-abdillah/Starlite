<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SalesActivity extends Model
{
    use HasFactory;

    protected $table = 'sales_activities';

    protected $fillable = [
        'user_id',
        'location_name',
        'status', // promosi, penjajakan, deal, failed
        'note',
        'photo_evidence',
        'latitude',
        'longitude',
    ];

    // Relasi ke User (Sales yang melakukan aktivitas)
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relasi ke Customer (Jika status deal, aktivitas ini menghasilkan 1 customer)
    public function customer()
    {
        return $this->hasOne(Customer::class, 'activity_id');
    }
}
