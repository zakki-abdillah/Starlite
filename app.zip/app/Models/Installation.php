<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Installation extends Model
{

    /**
     * 
     *
     * @var array
     */
    protected $fillable = [
        'job_code',
        'title',
        'admin_id',
        'id_waspang',
        'no_po',
        'target',
        'realisasi',
        'description',
        'status',
    ];

    /**
     * 
     */

    public function admin()
    {
        return $this->belongsTo(User::class, 'admin_id');
    }

    public function waspang()
    {
        return $this->belongsTo(User::class, 'id_waspang');
    }

    public function coordinates()
    {
        return $this->hasMany(InstallationCoordinate::class, 'installation_id');
    }
    

     public function task()
    {
        return $this->hasMany(InstallationTask::class, 'installation_id')->where('status', 'completed');
    }
    

    /**
     * Relasi ke Item Pekerjaan (SOW)
     */
    public function tasks()
    {
        return $this->hasMany(InstallationTask::class, 'installation_id');
    }
}
