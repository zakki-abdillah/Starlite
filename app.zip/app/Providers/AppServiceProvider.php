<?php

namespace App\Providers;

use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
public function boot(): void
{
    // Jika Anda ingin memaksa HTTPS di semua kondisi (termasuk lokal dengan SSL buatan)
    if (config('app.env') !== 'local' || env('FORCE_HTTPS', false) || (request()->server->has('HTTP_HOST') && str_contains(request()->getHost(), 'ngrok'))) {
        URL::forceScheme('https');
    }
}
}
