/*
 Navicat Premium Dump SQL

 Source Server         : MAMP
 Source Server Type    : MySQL
 Source Server Version : 80044 (8.0.44)
 Source Host           : localhost:8889
 Source Schema         : starlite

 Target Server Type    : MySQL
 Target Server Version : 80044 (8.0.44)
 File Encoding         : 65001

 Date: 25/04/2026 18:33:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for attendance
-- ----------------------------
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` enum('clock_in','clock_out') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attendance_user_id_foreign` (`user_id`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of attendance
-- ----------------------------
BEGIN;
INSERT INTO `attendance` (`id`, `user_id`, `type`, `photo_path`, `latitude`, `longitude`, `address`, `created_at`, `updated_at`) VALUES (1, 4, 'clock_in', 'attendances/QXytTDeKqy35ZYAujgymwUhTIBQZcHvtbmTADXIH.jpg', -7.0492791, 110.4681511, NULL, '2026-03-14 07:09:15', '2026-03-14 07:09:15');
INSERT INTO `attendance` (`id`, `user_id`, `type`, `photo_path`, `latitude`, `longitude`, `address`, `created_at`, `updated_at`) VALUES (2, 1, 'clock_in', 'attendances/Bd9SH9SYy74dyJIGa0gUG97SOns21Mn8CiHxwDyq.jpg', -7.0491872, 110.4681997, NULL, '2026-03-14 07:20:45', '2026-03-14 07:20:45');
INSERT INTO `attendance` (`id`, `user_id`, `type`, `photo_path`, `latitude`, `longitude`, `address`, `created_at`, `updated_at`) VALUES (3, 4, 'clock_out', 'attendances/SlXZOQgnTQnHlSysq0TT8ZnJQF9vfT97LmMLa8RE.jpg', -7.0491872, 110.4681997, NULL, '2026-03-14 07:21:42', '2026-03-14 07:21:42');
INSERT INTO `attendance` (`id`, `user_id`, `type`, `photo_path`, `latitude`, `longitude`, `address`, `created_at`, `updated_at`) VALUES (4, 4, 'clock_in', 'attendances/fbUKWkaJSy0TiHmEMdjlPsbpI7w5u1lNYMAF5JWZ.jpg', -7.0492275, 110.4682774, NULL, '2026-03-14 07:52:22', '2026-03-14 07:52:22');
INSERT INTO `attendance` (`id`, `user_id`, `type`, `photo_path`, `latitude`, `longitude`, `address`, `created_at`, `updated_at`) VALUES (5, 4, 'clock_out', 'attendances/l1c9mAqq9CCCYajSMC1D4orpjOVP6K1lypVSxzwR.jpg', -7.0491872, 110.4682290, NULL, '2026-03-16 13:55:22', '2026-03-16 13:55:22');
COMMIT;

-- ----------------------------
-- Table structure for cache
-- ----------------------------
DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of cache
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for cache_locks
-- ----------------------------
DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of cache_locks
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `activity_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_hp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_langganan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_activity_id_foreign` (`activity_id`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`activity_id`) REFERENCES `sales_activities` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of customer
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of failed_jobs
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for installation_coordinates
-- ----------------------------
DROP TABLE IF EXISTS `installation_coordinates`;
CREATE TABLE `installation_coordinates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `installation_id` bigint unsigned NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `installation_coordinates_installation_id_foreign` (`installation_id`),
  CONSTRAINT `installation_coordinates_ibfk_1` FOREIGN KEY (`installation_id`) REFERENCES `installations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of installation_coordinates
-- ----------------------------
BEGIN;
INSERT INTO `installation_coordinates` (`id`, `installation_id`, `latitude`, `longitude`, `description`) VALUES (1, 1, -6.9641899, 110.4385109, 'afda');
INSERT INTO `installation_coordinates` (`id`, `installation_id`, `latitude`, `longitude`, `description`) VALUES (17, 6, -7.0372410, 110.4734650, NULL);
INSERT INTO `installation_coordinates` (`id`, `installation_id`, `latitude`, `longitude`, `description`) VALUES (19, 3, -7.0372410, 110.4734650, 'fafdaf');
COMMIT;

-- ----------------------------
-- Table structure for installation_tasks
-- ----------------------------
DROP TABLE IF EXISTS `installation_tasks`;
CREATE TABLE `installation_tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `installation_id` bigint unsigned NOT NULL,
  `stage` enum('prepare_work','civil_work','electrical_work') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','completed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `details` json DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `installation_tasks_installation_id_foreign` (`installation_id`),
  CONSTRAINT `installation_tasks_ibfk_1` FOREIGN KEY (`installation_id`) REFERENCES `installations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of installation_tasks
-- ----------------------------
BEGIN;
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (1, 1, 'prepare_work', 'Permit Community', 'Sosialisasi Warga', 'completed', 'installation_files/GI9MQ2sYna0j4r814gdqGo7TnAZ2AtS60Xfru01t.png', NULL, NULL, 'dd', NULL, '2026-03-13 11:56:41', '2026-03-13 11:55:06', '2026-03-13 11:56:41');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (2, 1, 'prepare_work', 'Permit Community', 'Perjanjian Kerjasama', 'completed', 'installation_files/ZTTmjtvcJYY1VGqF4bXXXvlTuIDe7ra5yKGe8dRl.png', NULL, NULL, 'ada', NULL, '2026-03-13 11:56:30', '2026-03-13 11:55:06', '2026-03-13 11:56:30');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (3, 1, 'prepare_work', 'Survey and Design', 'Pengajuan Boundery', 'completed', 'installation_files/s5IhDErXykwboCwN3JG0qe49u3W8G2FGj0KciQVs.png', NULL, NULL, 'aaa', NULL, '2026-02-13 23:13:12', '2026-03-13 11:55:06', '2026-03-13 23:13:12');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (4, 1, 'prepare_work', 'Survey and Design', 'Survey Design', 'completed', 'installation_files/DDK4gJp8tgMRRQz8TcJJKTpPQwJuN1OeQiTDR9Ej.png', NULL, NULL, 'ddd', NULL, '2026-03-13 23:16:33', '2026-03-13 11:55:06', '2026-03-13 23:16:33');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (5, 1, 'prepare_work', 'Survey and Design', 'Design Review', 'completed', 'installation_files/Bf95AB8AEzYog3RfKqYwZp1NtYWGpRPzuImyevZr.png', NULL, NULL, NULL, NULL, '2026-03-13 23:17:08', '2026-03-13 11:55:06', '2026-03-13 23:17:08');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (6, 1, 'civil_work', 'Pole', 'Digging & Kedalaman', 'completed', 'installation_files/gJmJLpFEQXtsDFrlRNHVmft5WNFqVUxxIDkm2SJO.png', -7.0492275, 110.4682774, 'adfa', NULL, '2026-03-14 14:32:22', '2026-03-13 11:55:06', '2026-03-14 07:32:22');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (7, 1, 'civil_work', 'Pole', 'Erection', 'completed', 'installation_files/jgLrl49R8SYwR05elUat9ppWjr7Grg5D0vBkwRVp.png', -7.0492883, 110.4681969, 'fafafa', '{\"pole_type\": \"T6\"}', '2026-03-16 17:49:54', '2026-03-13 11:55:06', '2026-03-16 10:49:54');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (8, 1, 'civil_work', 'Pole', 'Cor Tiang', 'completed', 'installation_files/WCgTE0eL00rzNjqhLe9UKcv2iLWl9Ib5oacCD0hx.png', -7.0491747, 110.4682319, 'fghdh', NULL, '2026-03-16 20:49:37', '2026-03-13 11:55:06', '2026-03-16 13:49:37');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (9, 1, 'civil_work', 'Pole', 'Label Tiang', 'completed', 'installation_files/6cpugYoybdLYnPGl7BQATnFweJk1kgr8MtMRtiKB.png', -7.0491490, 110.4681549, NULL, NULL, '2026-03-16 21:29:13', '2026-03-13 11:55:06', '2026-03-16 14:29:13');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (10, 1, 'civil_work', 'Pemasangan X-Frame', 'Instalasi X-Frame Feeder', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (11, 1, 'civil_work', 'Pemasangan X-Frame', 'Instalasi X-Frame Distribusi', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (12, 1, 'civil_work', 'Instal ODP', 'Pemasangan ODP', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (13, 1, 'civil_work', 'Aksesoris KU Distribusi', 'Clamp Ring', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (14, 1, 'civil_work', 'Aksesoris KU Distribusi', 'Clamp S', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (15, 1, 'civil_work', 'Aksesoris KU Feeder', 'Clamp A', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (16, 1, 'civil_work', 'Aksesoris KU Feeder', 'Dead End', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (17, 1, 'civil_work', 'Pulling Precon', 'Pulling Precon 50', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (18, 1, 'civil_work', 'Pulling Precon', 'Pulling Precon 100', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (19, 1, 'civil_work', 'Pulling Precon', 'Pulling Precon 150', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (20, 1, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 50', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (21, 1, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 100', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (22, 1, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 150', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (23, 1, 'electrical_work', 'Electrical Work', 'Splicing Core', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (24, 1, 'electrical_work', 'Electrical Work', 'Testing Sinyal', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (49, 3, 'prepare_work', 'Permit Community', 'Sosialisasi Warga', 'completed', 'installation_files/iAx1DaACF9qslZt7GOUR4cZsrMAr50AfR5Zc9E91.png', NULL, NULL, 'afdafd', NULL, '2026-03-16 20:51:38', '2026-03-16 13:51:04', '2026-03-16 13:51:38');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (50, 3, 'prepare_work', 'Permit Community', 'Perjanjian Kerjasama', 'completed', 'installation_files/0MikywXcmmvh40R1NtVddJtvS8ZhGhHbByQpOvCy.png', NULL, NULL, 'afdafaf', NULL, '2026-03-16 20:54:51', '2026-03-16 13:51:04', '2026-03-16 13:54:51');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (51, 3, 'prepare_work', 'Survey and Design', 'Pengajuan Boundery', 'completed', 'installation_files/lylY1BJJz7OTKIh3l3990ePsnBrTvsftT57ij6Vu.png', NULL, NULL, 'boundery', NULL, '2026-03-16 21:25:15', '2026-03-16 13:51:04', '2026-03-16 14:25:15');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (52, 3, 'prepare_work', 'Survey and Design', 'Survey Design', 'completed', 'installation_files/aGdRMfklIFgUfulf072FqRtdF8eErRLKNgroapUD.png', NULL, NULL, 'mm', NULL, '2026-03-16 21:26:03', '2026-03-16 13:51:04', '2026-03-16 14:26:03');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (53, 3, 'prepare_work', 'Survey and Design', 'Design Review', 'completed', 'installation_files/wO7aB2tlqJg0bm5ypfbAmxqAN2YhqQ0Xghfv4iaV.png', NULL, NULL, 'afadf', NULL, '2026-03-16 21:26:23', '2026-03-16 13:51:04', '2026-03-16 14:26:23');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (54, 3, 'civil_work', 'Pole', 'Digging & Kedalaman', 'completed', 'installation_files/ZZPcxtD5bFZYStaBA5fMFQ71G77YPfWupruZC7hw.jpg', -7.0492053, 110.4682159, NULL, NULL, '2026-03-27 11:31:51', '2026-03-16 13:51:04', '2026-03-27 04:31:51');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (55, 3, 'civil_work', 'Pole', 'Erection', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (56, 3, 'civil_work', 'Pole', 'Cor Tiang', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (57, 3, 'civil_work', 'Pole', 'Label Tiang', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (58, 3, 'civil_work', 'Pemasangan X-Frame', 'Instalasi X-Frame Feeder', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (59, 3, 'civil_work', 'Pemasangan X-Frame', 'Instalasi X-Frame Distribusi', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (60, 3, 'civil_work', 'Instal ODP', 'Pemasangan ODP', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (61, 3, 'civil_work', 'Aksesoris KU Distribusi', 'Clamp Ring', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (62, 3, 'civil_work', 'Aksesoris KU Distribusi', 'Clamp S', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (63, 3, 'civil_work', 'Aksesoris KU Feeder', 'Clamp A', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (64, 3, 'civil_work', 'Aksesoris KU Feeder', 'Dead End', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (65, 3, 'civil_work', 'Pulling Precon', 'Pulling Precon 50', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (66, 3, 'civil_work', 'Pulling Precon', 'Pulling Precon 100', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (67, 3, 'civil_work', 'Pulling Precon', 'Pulling Precon 150', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (68, 3, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 50', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (69, 3, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 100', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (70, 3, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 150', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (71, 3, 'electrical_work', 'Electrical Work', 'Splicing Core', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (72, 3, 'electrical_work', 'Electrical Work', 'Testing Sinyal', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-16 13:51:04', '2026-03-16 13:51:04');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (121, 6, 'prepare_work', 'Permit Community', 'Sosialisasi Warga', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (122, 6, 'prepare_work', 'Permit Community', 'Perjanjian Kerjasama', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (123, 6, 'prepare_work', 'Survey and Design', 'Pengajuan Boundery', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (124, 6, 'prepare_work', 'Survey and Design', 'Survey Design', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (125, 6, 'prepare_work', 'Survey and Design', 'Design Review', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (126, 6, 'civil_work', 'Pole', 'Digging & Kedalaman', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (127, 6, 'civil_work', 'Pole', 'Erection', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (128, 6, 'civil_work', 'Pole', 'Cor Tiang', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (129, 6, 'civil_work', 'Pole', 'Label Tiang', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (130, 6, 'civil_work', 'Pemasangan X-Frame', 'Instalasi X-Frame Feeder', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (131, 6, 'civil_work', 'Pemasangan X-Frame', 'Instalasi X-Frame Distribusi', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (132, 6, 'civil_work', 'Instal ODP', 'Pemasangan ODP', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (133, 6, 'civil_work', 'Aksesoris KU Distribusi', 'Clamp Ring', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (134, 6, 'civil_work', 'Aksesoris KU Distribusi', 'Clamp S', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (135, 6, 'civil_work', 'Aksesoris KU Feeder', 'Clamp A', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (136, 6, 'civil_work', 'Aksesoris KU Feeder', 'Dead End', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (137, 6, 'civil_work', 'Pulling Precon', 'Pulling Precon 50', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (138, 6, 'civil_work', 'Pulling Precon', 'Pulling Precon 100', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (139, 6, 'civil_work', 'Pulling Precon', 'Pulling Precon 150', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (140, 6, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 50', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (141, 6, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 100', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (142, 6, 'civil_work', 'Pemeriksaan Precon', 'Pemeriksaan Precon 150', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (143, 6, 'electrical_work', 'Electrical Work', 'Splicing Core', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
INSERT INTO `installation_tasks` (`id`, `installation_id`, `stage`, `task_group`, `task_name`, `status`, `file_path`, `latitude`, `longitude`, `notes`, `details`, `completed_at`, `created_at`, `updated_at`) VALUES (144, 6, 'electrical_work', 'Electrical Work', 'Testing Sinyal', 'pending', NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-18 21:25:48', '2026-03-18 21:25:48');
COMMIT;

-- ----------------------------
-- Table structure for installations
-- ----------------------------
DROP TABLE IF EXISTS `installations`;
CREATE TABLE `installations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` bigint unsigned NOT NULL,
  `id_waspang` bigint unsigned NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `no_po` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` int DEFAULT NULL,
  `realisasi` int DEFAULT NULL,
  `status` enum('pending','in_progress','completed','on_hold','canceled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `installations_job_code_unique` (`job_code`),
  KEY `installations_admin_id_foreign` (`admin_id`),
  KEY `installations_id_waspang_foreign` (`id_waspang`),
  CONSTRAINT `installations_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `installations_ibfk_2` FOREIGN KEY (`id_waspang`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of installations
-- ----------------------------
BEGIN;
INSERT INTO `installations` (`id`, `job_code`, `title`, `admin_id`, `id_waspang`, `description`, `no_po`, `target`, `realisasi`, `status`, `created_at`, `updated_at`) VALUES (1, 'JOB-1773402906', 'Test Installasi', 1, 4, 'adfaf', 'A1', 500, 200, 'pending', '2026-03-13 11:55:06', '2026-03-13 11:55:06');
INSERT INTO `installations` (`id`, `job_code`, `title`, `admin_id`, `id_waspang`, `description`, `no_po`, `target`, `realisasi`, `status`, `created_at`, `updated_at`) VALUES (3, 'JOB-1773669064', 'Tawang', 1, 4, 'afafdaf', 'A2', 2000, 900, 'pending', '2026-03-16 13:51:04', '2026-03-31 14:17:41');
INSERT INTO `installations` (`id`, `job_code`, `title`, `admin_id`, `id_waspang`, `description`, `no_po`, `target`, `realisasi`, `status`, `created_at`, `updated_at`) VALUES (6, 'JOB-1773869148', 'aa', 1, 5, 'afa', 'afd3', 200, 180, 'pending', '2026-03-18 21:25:48', '2026-03-18 22:26:24');
COMMIT;

-- ----------------------------
-- Table structure for job_batches
-- ----------------------------
DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of job_batches
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for jobs
-- ----------------------------
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of jobs
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for login_histories
-- ----------------------------
DROP TABLE IF EXISTS `login_histories`;
CREATE TABLE `login_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `device` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_at` timestamp NOT NULL,
  `logout_at` timestamp NULL DEFAULT NULL,
  `status` enum('success','failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'success',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_histories_user_id_index` (`user_id`),
  KEY `login_histories_login_at_index` (`login_at`),
  CONSTRAINT `login_histories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of login_histories
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
BEGIN;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1, '0001_01_01_000000_create_users_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (2, '0001_01_01_000001_create_cache_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (3, '0001_01_01_000002_create_jobs_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (4, '2026_01_31_134155_create_login_histories_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (5, '2026_02_10_110810_create_attendance_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (6, '2026_02_11_150528_create_sop_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (7, '2026_02_13_074430_create_sales_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (8, '2026_02_16_024543_create_teknisi_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (9, '2026_02_16_030528_create_sales_activities', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (10, '2026_02_16_033834_create_customer_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (11, '2026_02_17_111633_create_schedules_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (12, '2026_02_17_124152_create_schedule_technician', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (13, '2026_03_03_132344_create_installations_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (14, '2026_03_03_163412_create_installation_coordinates_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (15, '2026_03_05_014643_create_installation_tasks_table', 1);
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (16, '2026_03_05_020000_add_details_to_installation_tasks_table', 1);
COMMIT;

-- ----------------------------
-- Table structure for password_reset_tokens
-- ----------------------------
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of password_reset_tokens
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sales
-- ----------------------------
DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nik` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_hp` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_user_id_foreign` (`user_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sales
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sales_activities
-- ----------------------------
DROP TABLE IF EXISTS `sales_activities`;
CREATE TABLE `sales_activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `location_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('promosi','penjajakan','deal','failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'promosi',
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `photo_evidence` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_activities_user_id_foreign` (`user_id`),
  CONSTRAINT `sales_activities_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sales_activities
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for schedule_technician
-- ----------------------------
DROP TABLE IF EXISTS `schedule_technician`;
CREATE TABLE `schedule_technician` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` bigint unsigned NOT NULL,
  `technician_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedule_technician_schedule_id_foreign` (`schedule_id`),
  KEY `schedule_technician_technician_id_foreign` (`technician_id`),
  CONSTRAINT `schedule_technician_ibfk_1` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedule_technician_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of schedule_technician
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for schedules
-- ----------------------------
DROP TABLE IF EXISTS `schedules`;
CREATE TABLE `schedules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned NOT NULL,
  `admin_id` bigint unsigned NOT NULL,
  `team_leader_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_type` enum('pemasangan','maintenance','perbaikan') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pemasangan',
  `work_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `scheduled_at` datetime NOT NULL,
  `start_at` datetime DEFAULT NULL,
  `end_at` datetime DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `status` enum('pending','in_progress','on_hold','completed','canceled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `hold_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedules_customer_id_foreign` (`customer_id`),
  KEY `schedules_admin_id_foreign` (`admin_id`),
  KEY `schedules_team_leader_id_foreign` (`team_leader_id`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedules_ibfk_3` FOREIGN KEY (`team_leader_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of schedules
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sessions
-- ----------------------------
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sessions
-- ----------------------------
BEGIN;
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES ('4Otyie4rVqh6R70whCGoTy6Ys7OUpD3GZkn5AxDR', NULL, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:150.0) Gecko/20100101 Firefox/150.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiWmxYMTcxTW9CRHhzdVJtRTFkT1ZZMldEOWJwWE1oMXVOVU12aUdMQiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cDovL2xvY2FsaG9zdDo4MDAwL3dhc3BhbmcvcmVwb3J0Ijt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1775440795);
COMMIT;

-- ----------------------------
-- Table structure for sop
-- ----------------------------
DROP TABLE IF EXISTS `sop`;
CREATE TABLE `sop` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('teknisi','sales','waspang') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of sop
-- ----------------------------
BEGIN;
INSERT INTO `sop` (`id`, `title`, `content`, `role`, `created_at`, `updated_at`) VALUES (1, 'SOP Sales', 'Konten SOP Sales', 'sales', '2026-03-13 23:01:06', '2026-03-13 23:01:06');
INSERT INTO `sop` (`id`, `title`, `content`, `role`, `created_at`, `updated_at`) VALUES (2, 'SOP Teknisi', 'Konten SOP Teknisi', 'teknisi', '2026-03-13 23:01:27', '2026-03-13 23:01:27');
INSERT INTO `sop` (`id`, `title`, `content`, `role`, `created_at`, `updated_at`) VALUES (3, 'SOP Installasi', 'Konten Installasi SOP Waspang', 'waspang', '2026-03-14 07:20:28', '2026-03-16 13:57:53');
COMMIT;

-- ----------------------------
-- Table structure for teknisi
-- ----------------------------
DROP TABLE IF EXISTS `teknisi`;
CREATE TABLE `teknisi` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of teknisi
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','teknisi','sales','waspang') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES (1, 'admin', 'admin@gmail.com', '2026-03-13 11:51:58', '$2y$12$2D0yPPZEZ7qbHz4sg.IvG.E2qctVD4ecsxHFFGMa1rsm0POM.7bv2', 'admin', 'n3Lv9upFAQ5z6puru6I232LhMmPI3igbUo0Ljo5q6cTkEEfDcvq3Y2nSDfbd', '2026-03-13 11:51:58', '2026-03-13 11:51:58');
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES (2, 'teknisi', 'teknisi@gmail.com', '2026-03-13 11:51:58', '$2y$12$OWBb3iCR1ZH/OhxdACyzhuc9SwVxhXiED6KdTRrAZTCjdHzVzEXI.', 'teknisi', 'GUD37dIzvjgIvqDLQiT3q1zrzx444b7k7s9dYwJdHUWKOkizlL452K03CcbH', '2026-03-13 11:51:58', '2026-03-13 11:51:58');
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES (3, 'sales', 'sales@sales.com', '2026-03-13 11:51:58', '$2y$12$znMnh0OeLTyvPLewRWhSPukfhxutvu8euGvvr1zDGLueyp1IcmW8u', 'sales', 'CYH8OCAECi', '2026-03-13 11:51:58', '2026-03-13 11:51:58');
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES (4, 'waspang', 'waspang@gmail.com', '2026-03-13 11:51:58', '$2y$12$BLKIMUcrBOSQGSFvCisgD.BEBoKpuc0ZR7T4gnDnYcJ.X2UkQJqtS', 'waspang', '5ctvne9Bc18lARlVwobG0KclO4xnKovO69FgIj2mRiQPhnQfvHUtZRwBps2A', '2026-03-13 11:51:59', '2026-03-13 11:51:59');
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES (5, 'Waspang 1', 'waspang1@gmail.com', NULL, '$2y$12$uGA7EO6SUbDQPxrrlb8HmOeoTuT2QUoTKJFLdelV.d/1dzFTp6Fuu', 'waspang', NULL, '2026-03-18 13:14:43', '2026-03-18 13:14:43');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
