<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('installation_tasks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('installation_id')->constrained('installations')->onDelete('cascade');
            $table->enum('stage', ['prepare_work', 'civil_work', 'electrical_work']);
            $table->string('task_group');
            $table->string('task_name');
            $table->enum('status', ['pending', 'completed'])->default('pending');
            $table->string('file_path')->nullable();
            $table->text('notes')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('installation_tasks');
    }
};
