<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('installation_tasks', function (Blueprint $table) {
            $table->decimal('latitude', 10, 7)->nullable()->after('file_path');
            $table->decimal('longitude', 10, 7)->nullable()->after('latitude');
            $table->json('details')->nullable()->after('notes');
        });
    }

    public function down(): void
    {
        Schema::table('installation_tasks', function (Blueprint $table) {
            $table->dropColumn(['latitude', 'longitude', 'details']);
        });
    }
};
