<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained('customer')->onDelete('cascade');
            $table->foreignId('admin_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('team_leader_id')->nullable()->constrained('users')->onDelete('set null');
            $table->string('title');
            $table->enum('task_type', ['pemasangan', 'maintenance', 'perbaikan'])->default('pemasangan');
            $table->text('work_note')->nullable();
            $table->dateTime('scheduled_at');
            $table->dateTime('start_at')->nullable();
            $table->dateTime('end_at')->nullable();
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->enum('status', ['pending', 'in_progress', 'on_hold', 'completed', 'canceled'])->default('pending');
            $table->text('hold_reason')->nullable();            
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('schedules');
    }
};
