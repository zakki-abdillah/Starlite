<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('schedule_technician', function (Blueprint $table) {
            $table->id();
            $table->foreignId('schedule_id')->constrained('schedules')->onDelete('cascade');
            $table->foreignId('technician_id')->constrained('users')->onDelete('cascade'); // Merujuk ke tabel users
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('schedule_technician');
    }
};
