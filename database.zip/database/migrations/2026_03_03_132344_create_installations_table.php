<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('installations', function (Blueprint $table) {
            $table->id();
            $table->string('job_code')->unique();
            $table->string('title');
            $table->foreignId('admin_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('id_waspang')->constrained('users')->onDelete('cascade');
            $table->text('description')->nullable();
            $table->string('no_po');
            $table->integer('target');
            $table->integer('realisasi');
            $table->enum('status', ['pending', 'in_progress', 'completed', 'on_hold', 'canceled'])->default('pending');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('installations');
    }
};
