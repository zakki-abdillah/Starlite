<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('customer', function (Blueprint $table) {
            $table->id();
            $table->foreignId('activity_id')->nullable()->constrained('sales_activities')->onDelete('set null');
            $table->string('name');
            $table->string('address');
            $table->string('nik');
            $table->string('photo_path');
            $table->string('no_hp');
            $table->string('status_langganan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('customer');
    }
};
