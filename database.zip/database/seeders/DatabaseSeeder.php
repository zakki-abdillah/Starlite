<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'admin',
            'email' => 'admin@gmail.com',
            'password' => '123',
            'role'=>'admin'
        ]);
        User::factory()->create([
            'name' => 'teknisi',
            'email' => 'teknisi@gmail.com',
            'password' => '123',
            'role'=>'teknisi'
        ]);
        User::factory()->create([
            'name' => 'sales',
            'email' => 'sales@sales.com',
            'password' => '123',
            'role'=>'sales'
        ]);
        User::factory()->create([
            'name' => 'waspang',
            'email' => 'waspang@gmail.com',
            'password' => '123',
            'role' => 'waspang'
        ]);
    }
}
